package ca.odell.glazedlists.jfreechart;

/**
 * A ValueSegment represents a stable value within a segment of
 * {@link Comparable} values. For example, instances could represent the
 * average temperature each hour of the day. The start and end values of the
 * {@link ValueSegment} would be the Timestamps of the start and end of the
 * hour and the value would be the Float representing the average temperature
 * for that hour.
 *
 * <p><strong><font color="#FF0000">Note:</font></strong> {@link ValueSegment}s
 * must be immutable objects.
 *
 * @author James Lemieux
 */
public interface ValueSegment extends Comparable {
    
    /**
     * Returns the value marking the start of this segment.
     */
    public Comparable getStart();
    
    /**
     * Returns the value marking the end of this segment.
     */
    public Comparable getEnd();
    
    /**
     * Returns the value observed within this segment.
     */
    public Comparable getValue();
}
