package ca.odell.glazedlists.jfreechart;

import ca.odell.glazedlists.GlazedLists;

/**
 * The default implementation of the {@link ValueSegment} interface.
 *
 * <p><strong><font color="#FF0000">Note:</font></strong>
 * {@link DefaultValueSegment}s must be immutable objects. Callers are strongly
 * encouraged to construct {@link DefaultValueSegment}s with defensive copies
 * of the start, end, and value arguments if they are not themselves immutable.
 *
 * @author James Lemieux
 */
public class DefaultValueSegment implements ValueSegment {
    
    /**
     * The value marking the start of the segment. 
     */
    private final Comparable start;
    
    /**
     * The value marking the end of the segment. 
     */
    private final Comparable end;
    
    /**
     * The value to report for the segment described. 
     */
    private final Comparable value;
    
    /**
     * Create a DefaultValueSegment indicating the <code>value</code> exists
     * between the <code>start</code> and <code>end</code> on some continuum of
     * {@link Comparable} objects.
     *
     * @param start the beginning of the segment
     * @param end the end of the segment
     * @param value the value observed between <code>start</code> and
     *      <code>end</code>
     * @throws IllegalArgumentException if <code>start</code> or
     *      <code>end</code> is <code>null</code>
     */
    public DefaultValueSegment(Comparable start, Comparable end, Comparable value) {
        super();
        if (start == null) throw new IllegalArgumentException("start may not be null");
        if (end == null) throw new IllegalArgumentException("end may not be null");
        this.start = start;
        this.end = end;
        this.value = value;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Comparable getStart() {
        return start;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Comparable getEnd() {
        return end;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Comparable getValue() {
        return value;
    }
    
    /**
     * DefaultValueSegments are compared by value, then by segment start,
     * then by segment end.
     */
    public int compareTo(Object x0) {
        ValueSegment o = (ValueSegment)x0;
        final int valueComparison = GlazedLists.comparableComparator().compare(value, o.getValue());
        if (valueComparison != 0) return valueComparison;
        final int startComparison = start.compareTo(o.getStart());
        if (startComparison != 0) return startComparison;
        return end.compareTo(o.getEnd());
    }
    
    /**
     * {@inheritDoc} 
     */
    public String toString() {
        return "(" + start + ", " + end + ")";
    }
    /*missing*/
}
