package ca.odell.glazedlists.impl;

import ca.odell.glazedlists.*;
import java.util.*;

/**
 * Returns the List itself for a List of Lists.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ListCollectionListModel implements CollectionList.Model {
    
    public ListCollectionListModel() {
        super();
    }
    
    public List getChildren(Object x0) {
        List parent = (List)x0;
        if (parent == null) return Collections.EMPTY_LIST;
        return parent;
    }
    /*missing*/
}
