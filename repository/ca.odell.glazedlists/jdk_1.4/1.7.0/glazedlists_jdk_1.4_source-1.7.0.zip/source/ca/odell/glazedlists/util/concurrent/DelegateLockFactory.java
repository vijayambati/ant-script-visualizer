package ca.odell.glazedlists.util.concurrent;

/**
 * An implementation of {@link LockFactory} that detects and delegates to
 * a JVM specific LockFactory implementation optimized for the current JVM.
 */
class DelegateLockFactory implements LockFactory {
    
    /**
     * The true JVM specific LockFactory to which we delegate. 
     */
    private LockFactory delegate;
    
    DelegateLockFactory() {
        super();
        try {
            Class.forName("java.util.concurrent.locks.ReadWriteLock");
            this.delegate = (LockFactory)(LockFactory)Class.forName("ca.odell.glazedlists.impl.java15.J2SE50LockFactory").newInstance();
        } catch (Exception e) {
            this.delegate = new J2SE12LockFactory();
        }
    }
    
    public ReadWriteLock createReadWriteLock() {
        return this.delegate.createReadWriteLock();
    }
    
    public Lock createLock() {
        return this.delegate.createLock();
    }
}
