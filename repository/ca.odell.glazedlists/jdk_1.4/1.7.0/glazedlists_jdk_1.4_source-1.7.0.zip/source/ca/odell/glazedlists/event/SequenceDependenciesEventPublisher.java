package ca.odell.glazedlists.event;

import ca.odell.glazedlists.impl.adt.IdentityMultimap;
import ca.odell.glazedlists.EventList;
import java.util.*;

/**
 * Manage listeners, firing events, and making sure that events arrive in order.
 *
 * <p>This manages listeners across multiple objects in a pipeline of observables
 * and their listeners. It implements Martin Fowler's
 * <a href="http://www.martinfowler.com/eaaDev/EventAggregator.html">EventAggregator</a>
 * design.
 *
 * <p>To guarantee a safe notification order, this class makes sure that all an
 * object's dependencies have been notified of a particular event before that
 * object is itself notified. This is tricky because it requires us to interrupt
 * the event flow and control its flow. In this class, event flow is controlled
 * by queueing events and not necessarily firing them during the {@link #fireEvent}
 * method.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
final class SequenceDependenciesEventPublisher implements ListEventPublisher {
    
    SequenceDependenciesEventPublisher() {
        super();
    }
    
    /**
     * keep track of how many times the fireEvent() method is on the stack 
     */
    private int reentrantFireEventCount = 0;
    
    /**
     * subject to cleanup when this event is completely distributed 
     */
    private Map subjectsToCleanUp = new IdentityHashMap();
    
    /**
     * for proper dependency management, when a listener and subject aren't the same identity 
     */
    private Map listenersToRelatedSubjects = new IdentityHashMap();
    
    /**
     * the last listener notified, the next one will be beyond it in the list 
     */
    private int nextToNotify;
    
    /**
     * A mix of different subjects and listeners pairs in a deliberate order.
     * We should be careful not to make changes to this list directly and instead
     * create a copy as necessary
     */
    private List subjectAndListeners = Collections.EMPTY_LIST;
    
    /**
     * We use copy-on-write on the listeners list. This is a copy of the
     * listeners list as it looked immediately before the current change
     * started. If there is no change going on (reentrantFireEventCount == 0),
     * then this should be null.
     */
    private List subjectsAndListenersForCurrentEvent = null;
    
    /**
     * Rebuild the subject and listeners list so that all required invariants
     * are met with respect to notification order. That is, for any listener
     * T, all of the subjects S that T listens to have been updated before T
     * receives a change event from any S.
     *
     * <p>This implementation still has some problems and work left to do:
     *  <li>it's big! Can we optimize it? Perhaps shortcutting all the graph
     *     work for simple cases (the 99% case)
     *  <li>it's complex! Can we simplify it?
     *  <li>could we keep the datastructures around? it may be wasteful to
     *     reconstruct them every single time a listener is added
     */
    private List orderSubjectsAndListeners(List subjectsAndListeners) {
        List result = new ArrayList();
        IdentityMultimap sourceToPairs = new IdentityMultimap();
        IdentityMultimap targetToPairs = new IdentityMultimap();
        Map satisfied = new IdentityHashMap();
        List satisfiedToDo = new ArrayList();
        for (int i = 0, size = subjectsAndListeners.size(); i < size; i++) {
            SubjectAndListener subjectAndListener = (SequenceDependenciesEventPublisher.SubjectAndListener)subjectsAndListeners.get(i);
            Object source = subjectAndListener.subject;
            Object target = getRelatedSubject(subjectAndListener.listener);
            sourceToPairs.addValue(source, subjectAndListener);
            targetToPairs.addValue(target, subjectAndListener);
            satisfied.remove(target);
            if (targetToPairs.count(source) == 0) {
                satisfied.put(source, Boolean.TRUE);
            }
        }
        satisfiedToDo.addAll(satisfied.keySet());
        while (!satisfiedToDo.isEmpty()) {
            Object subject = satisfiedToDo.remove(0);
            List sourceTargets = (List)sourceToPairs.get(subject);
            tryEachTarget: for (int t = 0, targetsSize = sourceTargets.size(); t < targetsSize; t++) {
                Object sourceTarget = getRelatedSubject(((SequenceDependenciesEventPublisher.SubjectAndListener)sourceTargets.get(t)).listener);
                List allSourcesForSourceTarget = (List)targetToPairs.get(sourceTarget);
                if (allSourcesForSourceTarget.size() == 0) continue;
                for (int s = 0, sourcesSize = allSourcesForSourceTarget.size(); s < sourcesSize; s++) {
                    SubjectAndListener sourceAndTarget = (SequenceDependenciesEventPublisher.SubjectAndListener)allSourcesForSourceTarget.get(s);
                    if (!satisfied.containsKey(sourceAndTarget.subject)) {
                        continue tryEachTarget;
                    }
                }
                result.addAll(allSourcesForSourceTarget);
                targetToPairs.remove(sourceTarget);
                satisfiedToDo.add(sourceTarget);
                satisfied.put(sourceTarget, Boolean.TRUE);
            }
        }
        if (!targetToPairs.isEmpty()) {
            throw new IllegalStateException("Listener cycle detected, " + targetToPairs.values());
        }
        return result;
    }
    
    private Object getRelatedSubject(Object listener) {
        Object subject = listenersToRelatedSubjects.get(listener);
        if (subject == null) return listener;
        return subject;
    }
    
    /**
     * Register the specified listener to receive events from the specified
     * subject whenever they are fired.
     */
    public synchronized void addListener(Object subject, Object listener, EventFormat eventFormat) {
        List unordered = updateListEventListeners(subject, listener, null, eventFormat);
        subjectAndListeners = orderSubjectsAndListeners(unordered);
    }
    
    /**
     * Deregister the specified listener from recieving events from the specified
     * subject.
     */
    public synchronized void removeListener(Object subject, Object listener) {
        subjectAndListeners = updateListEventListeners(subject, null, listener, null);
    }
    
    /**
     * Support method for adding and removing listeners, that also cleans up
     * stale listeners, such as those from weak references.
     *
     * @param listenerToAdd a listener to be added, or <code>null</code>
     * @param listenerToRemove a listener to be removed, or <code>null</code>
     */
    private List updateListEventListeners(Object subject, Object listenerToAdd, Object listenerToRemove, EventFormat eventFormat) {
        int anticipatedSize = this.subjectAndListeners.size() + (listenerToAdd == null ? -1 : 1);
        List result = new ArrayList(anticipatedSize);
        for (int i = 0; i < subjectAndListeners.size(); i++) {
            final SubjectAndListener originalSubjectAndListener = (SequenceDependenciesEventPublisher.SubjectAndListener)subjectAndListeners.get(i);
            if (originalSubjectAndListener.listener == listenerToRemove && originalSubjectAndListener.subject == subject) {
                listenerToRemove = null;
                continue;
            }
            if (originalSubjectAndListener.eventFormat.isStale(originalSubjectAndListener.subject, originalSubjectAndListener.listener)) {
                continue;
            }
            result.add(originalSubjectAndListener);
        }
        if (listenerToRemove != null) {
            throw new IllegalArgumentException("Cannot remove nonexistent listener " + listenerToRemove);
        }
        if (listenerToAdd != null) {
            result.add(new SubjectAndListener(subject, listenerToAdd, eventFormat));
        }
        return result;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void setRelatedListener(Object subject, Object relatedListener) {
        addListener(relatedListener, subject, NoOpEventFormat.INSTANCE);
    }
    
    /**
     * {@inheritDoc} 
     */
    public void clearRelatedListener(Object subject, Object relatedListener) {
        removeListener(relatedListener, subject);
    }
    
    /**
     * {@inheritDoc} 
     */
    public void addDependency(EventList dependency, ListEventListener listener) {
    }
    
    /**
     * {@inheritDoc} 
     */
    public void removeDependency(EventList dependency, ListEventListener listener) {
    }
    
    /**
     * {@inheritDoc} 
     */
    public void setRelatedSubject(Object listener, Object relatedSubject) {
        if (relatedSubject != null) {
            listenersToRelatedSubjects.put(listener, relatedSubject);
        } else {
            listenersToRelatedSubjects.remove(listener);
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public void clearRelatedSubject(Object listener) {
        listenersToRelatedSubjects.remove(listener);
    }
    
    /**
     * Get all listeners of the specified object.
     */
    public List getListeners(Object subject) {
        List result = new ArrayList();
        for (int i = 0, size = subjectAndListeners.size(); i < size; i++) {
            SubjectAndListener subjectAndListener = (SequenceDependenciesEventPublisher.SubjectAndListener)subjectAndListeners.get(i);
            if (subjectAndListener.subject != subject) continue;
            result.add(subjectAndListener.listener);
        }
        return result;
    }
    
    /**
     * Notify all listeners of the specified subject of the specified event.
     *
     * @param subject the event's source
     * @param event the event to send to all listeners
     * @param eventFormat the mechanism to notify listeners of the event, also
     *     used for a callback when this event is complete
     */
    public void fireEvent(Object subject, Object event, EventFormat eventFormat) {
        if (reentrantFireEventCount == 0) {
            subjectsAndListenersForCurrentEvent = subjectAndListeners;
            nextToNotify = Integer.MAX_VALUE;
        }
        reentrantFireEventCount++;
        try {
            EventFormat previous = (SequenceDependenciesEventPublisher.EventFormat)subjectsToCleanUp.put(subject, eventFormat);
            if (previous != null) throw new IllegalStateException("Reentrant fireEvent() by \"" + subject + "\"");
            int subjectAndListenersSize = subjectsAndListenersForCurrentEvent.size();
            for (int i = 0; i < subjectAndListenersSize; i++) {
                SubjectAndListener subjectAndListener = (SequenceDependenciesEventPublisher.SubjectAndListener)subjectsAndListenersForCurrentEvent.get(i);
                if (subjectAndListener.subject != subject) continue;
                if (i < nextToNotify) nextToNotify = i;
                subjectAndListener.addPendingEvent(event);
            }
            if (reentrantFireEventCount != 1) return;
            RuntimeException toRethrow = null;
            while (true) {
                SubjectAndListener nextToFire = null;
                for (int i = nextToNotify; i < subjectAndListenersSize; i++) {
                    SubjectAndListener subjectAndListener = (SequenceDependenciesEventPublisher.SubjectAndListener)subjectsAndListenersForCurrentEvent.get(i);
                    if (subjectAndListener.hasPendingEvent()) {
                        nextToFire = subjectAndListener;
                        nextToNotify = i + 1;
                        break;
                    }
                }
                if (nextToFire == null) break;
                try {
                    nextToFire.firePendingEvent();
                } catch (RuntimeException e) {
                    if (toRethrow == null) toRethrow = e;
                }
            }
            for (Iterator i = subjectsToCleanUp.entrySet().iterator(); i.hasNext(); ) {
                Map.Entry subjectAndEventFormat = (Map.Entry)i.next();
                try {
                    ((SequenceDependenciesEventPublisher.EventFormat)subjectAndEventFormat.getValue()).postEvent(subjectAndEventFormat.getKey());
                } catch (RuntimeException e) {
                    if (toRethrow == null) toRethrow = e;
                }
            }
            subjectsToCleanUp.clear();
            subjectsAndListenersForCurrentEvent = null;
            if (toRethrow != null) throw toRethrow;
        } finally {
            reentrantFireEventCount--;
        }
    }
    
    /**
     * Adapt any observer-style interface to a common format.
     */
    public interface EventFormat {
        
        /**
         * Fire the specified event to the specified listener.
         */
        void fire(Object subject, Object event, Object listener);
        
        /**
         * A callback made only after all listeners of the specified subject
         * have been notified of the specified event. This can be used as
         * a hook to clean up temporary datastructures for that event.
         */
        void postEvent(Object subject);
        
        /**
         * Whether the listener is still valid. Usually a listener becomes stale
         * when a weak reference goes out of scope. If this method returns true,
         * the listener will be silently removed and no longer receive events.
         */
        boolean isStale(Object subject, Object listener);
    }
    
    /**
     * An EventFormat used to specify explicit dependencies, but that doesn't
     * actually fire events.
     *
     * @see {@link ListEventPublisher#setRelatedListener}
     */
    private static class NoOpEventFormat implements SequenceDependenciesEventPublisher.EventFormat {
        
        private NoOpEventFormat() {
            super();
        }
        public static final SequenceDependenciesEventPublisher.EventFormat INSTANCE = new NoOpEventFormat();
        
        public void fire(Object subject, Object event, Object listener) {
            throw new UnsupportedOperationException();
        }
        
        public void postEvent(Object subject) {
            throw new UnsupportedOperationException();
        }
        
        public boolean isStale(Object subject, Object listener) {
            return false;
        }
    }
    
    /**
     * Manage a subject/listener pair, plus a possible event that is queued to
     * be fired to the listener from the subject.
     */
    private static class SubjectAndListener {
        private final Object subject;
        private final Object listener;
        private final EventFormat eventFormat;
        private Object pendingEvent;
        
        public SubjectAndListener(Object subject, Object listener, EventFormat eventFormat) {
            super();
            this.subject = subject;
            this.listener = listener;
            this.eventFormat = eventFormat;
        }
        
        public boolean hasPendingEvent() {
            return pendingEvent != null;
        }
        
        public void addPendingEvent(Object pendingEvent) {
            if (this.pendingEvent != null) throw new IllegalStateException();
            if (pendingEvent == null) throw new IllegalStateException();
            this.pendingEvent = pendingEvent;
        }
        
        public void firePendingEvent() {
            assert (pendingEvent != null);
            try {
                eventFormat.fire(subject, pendingEvent, listener);
            } finally {
                pendingEvent = null;
            }
        }
        
        public String toString() {
            String separator = hasPendingEvent() ? ">>>" : "-->";
            return subject + separator + listener;
        }
    }
}
