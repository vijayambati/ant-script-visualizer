package ca.odell.glazedlists.util.concurrent;

/**
 * This factory provides an implementation of {@link Lock} that is optimized
 * for the current Java Virtual Machine.
 *
 * @author <a "mailto:rob@starlight-systems.com">Rob Eden</a>
 * @author James Lemieux
 */
public interface LockFactory {
    
    /**
     * The Lock factory for this JVM. 
     */
    public static final LockFactory DEFAULT = new DelegateLockFactory();
    
    /**
     * Create a {@link ReadWriteLock}.
     */
    public ReadWriteLock createReadWriteLock();
    
    /**
     * Create a {@link Lock}.
     */
    public Lock createLock();
}
