package ca.odell.glazedlists.gui;

/**
 * Specifies how to check table elements.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public interface CheckableTableFormat extends TableFormat {
    
    /**
     * Sets the specified object as checked.
     */
    public void setChecked(Object baseObject, boolean checked);
    
    /**
     * Gets whether the specified object is checked.
     */
    public boolean getChecked(Object baseObject);
}
