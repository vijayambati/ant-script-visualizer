package ca.odell.glazedlists.impl.ctp;

import ca.odell.glazedlists.impl.nio.*;
import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * A OpenConnection models a desired connection. It is a temporary object used
 * by the connection manager to be passed between threads.
 *
 * <p>A OpenConnection is created for each call to the connect() method, and
 * queued until it can be processed by the CTP thread.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
class OpenConnection implements Runnable {
    
    /**
     * the place to connect to 
     */
    private CTPConnectionManager connectionManager;
    private String host;
    private int port;
    private CTPHandler handler;
    
    /**
     * Create a new CTPConnectionToEstablish.
     */
    public OpenConnection(CTPConnectionManager connectionManager, CTPHandler handler, String host, int port) {
        super();
        this.connectionManager = connectionManager;
        this.handler = handler;
        this.host = host;
        this.port = port;
    }
    
    /**
     * Establish the connection. This creates a CTPProtocol for the client and
     * registers it with the selector.
     */
    public void run() {
        CTPConnection client = null;
        try {
            InetSocketAddress address = new InetSocketAddress(host, port);
            SocketChannel channel = SocketChannel.open();
            channel.configureBlocking(false);
            SelectionKey selectionKey = channel.register(connectionManager.getNIODaemon().getSelector(), SelectionKey.OP_CONNECT);
            client = CTPConnection.client(host, selectionKey, handler, connectionManager);
            selectionKey.attach(client);
            channel.connect(address);
        } catch (IOException e) {
            handler.connectionClosed(client, e);
        }
    }
}
