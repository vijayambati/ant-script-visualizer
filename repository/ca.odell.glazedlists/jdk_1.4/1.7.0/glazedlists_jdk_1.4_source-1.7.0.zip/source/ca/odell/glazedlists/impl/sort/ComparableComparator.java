package ca.odell.glazedlists.impl.sort;

import java.util.Comparator;

/**
 * A trivial comparator that requires that compared objects implement
 * the comparable interface.
 *
 * <p>When this finds <code>null</code> objects, it orders them before all
 * other objects.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class ComparableComparator implements Comparator {
    
    public ComparableComparator() {
        super();
    }
    
    /**
     * Compares object alpha to object beta by casting object one
     * to Comparable, and calling its compareTo method.
     */
    public int compare(Object x0, Object x1) {
        Comparable alpha = (Comparable)x0;
        Comparable beta = (Comparable)x1;
        if (alpha != null && beta != null) {
            return alpha.compareTo(beta);
        }
        if (alpha == null) {
            if (beta == null) return 0;
            return -1;
        } else {
            return 1;
        }
    }
    
    /**
     * This is equal to another comparator if it is a ComparableComparable.
     */
    public boolean equals(Object other) {
        return (other instanceof ComparableComparator);
    }
    /*missing*/
}
