package ca.odell.glazedlists.impl.ctp;

import ca.odell.glazedlists.impl.nio.*;
import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * A task that starts the CTP Connection manager.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
class StartServer implements Runnable {
    
    /**
     * logging 
     */
    private static Logger logger = Logger.getLogger(StartServer.class.toString());
    
    /**
     * the I/O event queue daemon 
     */
    private CTPConnectionManager connectionManager = null;
    
    /**
     * port to listen for incoming connections 
     */
    private int listenPort = -1;
    
    /**
     * Create a new CTPStartUp that starts a server using the specified
     * NIODaemon.
     */
    public StartServer(CTPConnectionManager connectionManager, int listenPort) {
        super();
        this.connectionManager = connectionManager;
        this.listenPort = listenPort;
    }
    
    /**
     * Runs the specified task.
     *
     * @param selector the selector being shared by all connections.
     * @return true unless the server shall shutdown due to a shutdown request or
     *      an unrecoverable failure.
     */
    public void run() {
        try {
            ServerSocketChannel serverChannel = ServerSocketChannel.open();
            ServerSocket serverSocket = serverChannel.socket();
            serverSocket.setReuseAddress(false);
            InetSocketAddress listenAddress = new InetSocketAddress(listenPort);
            serverSocket.bind(listenAddress);
            serverChannel.configureBlocking(false);
            serverChannel.register(connectionManager.getNIODaemon().getSelector(), SelectionKey.OP_ACCEPT);
            connectionManager.getNIODaemon().setServer(connectionManager);
            logger.info("Connection Manager ready, listening on " + listenAddress);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
