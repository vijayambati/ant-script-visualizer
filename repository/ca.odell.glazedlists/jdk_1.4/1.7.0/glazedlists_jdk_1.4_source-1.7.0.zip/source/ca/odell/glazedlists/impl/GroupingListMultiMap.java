package ca.odell.glazedlists.impl;

import ca.odell.glazedlists.*;
import ca.odell.glazedlists.event.ListEventListener;
import ca.odell.glazedlists.event.ListEvent;
import java.util.*;

/**
 * This multimap implementation sits atop an {@link EventList} and makes it
 * accessible via the convenient {@link Map} interface. It is constructed with
 * a {@link FunctionList.Function} which is used to create the keys of the map.
 * The values of the map are the lists of values from the {@link EventList}
 * which all map to a common key.
 *
 * <p>For example, a list containing
 *
 * <pre>
 * {Cherry, Plum, Cranberry, Pineapple, Banana, Prune}
 * </pre>
 *
 * paired with a Function that returns the first letter of the fruit name
 * produces the multi map:
 *
 * <pre>
 * "B" -> {Banana}
 * "C" -> {Cherry, Cranberry}
 * "P" -> {Plum, Pineapple, Prune}
 * </pre>
 *
 * @author James Lemieux
 */
public class GroupingListMultiMap implements Map, ListEventListener {
    
    /**
     * The raw values of this Map in an {@link EventList}. 
     */
    private final GroupingList groupingList;
    
    /**
     * The polished values of this Map in an {@link EventList}. 
     */
    private final FunctionList valueList;
    
    /**
     * The keys of this Map (used to remove entries from the {@link #delegate}) 
     */
    private final List keyList;
    
    /**
     * The keys of this Map made to look like a Set (it is build lazily in {@link #keySet()}) 
     */
    private Set keySet;
    
    /**
     * The function which produces keys for this multimap. 
     */
    private final FunctionList.Function keyFunction;
    
    /**
     * The delegate Map which is kept in synch with {@link #groupingList} changes. 
     */
    private final Map delegate;
    
    /**
     * The set of Map.Entry objects in this Map (it is build lazily in {@link #entrySet()}) 
     */
    private Set entrySet;
    
    /**
     * Construct a multimap which maps the keys produced by the
     * <code>keyFunction</code>, to groups of values from <code>source</code>
     * that agree on their keys.
     *
     * @param source the raw data which has not yet been grouped
     * @param keyFunction the function capable of producing the keys of this
     *      {@link Map}; the keys themselves are {@link Comparable} and thus
     *      also determine the content of the {@link List}s which are the
     *      values of this {@link Map}.
     */
    public GroupingListMultiMap(EventList source, FunctionList.Function keyFunction) {
        super();
        this.keyFunction = keyFunction;
        this.groupingList = new GroupingList(source, new FunctionComparator(keyFunction));
        this.valueList = new FunctionList(this.groupingList, new ValueListFunction());
        this.valueList.addListEventListener(this);
        this.keyList = new BasicEventList(this.groupingList.size());
        this.delegate = new HashMap(this.groupingList.size());
        for (Iterator i = this.valueList.iterator(); i.hasNext(); ) {
            final List value = (List)i.next();
            final Comparable key = key(value);
            this.keyList.add(key);
            this.delegate.put(key, value);
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public int size() {
        return this.delegate.size();
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean isEmpty() {
        return this.delegate.isEmpty();
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean containsKey(Object key) {
        return this.delegate.containsKey(key);
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean containsValue(Object value) {
        return this.delegate.containsValue(value);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object get(Object x0) {
        Object key = (Object)x0;
        return (List)this.delegate.get(key);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object put(Object x0, Object x1) {
        Comparable key = (Comparable)x0;
        List value = (List)x1;
        this.checkKeyValueAgreement(key, value);
        final List removed = (List)this.remove(key);
        this.groupingList.add(value);
        return removed;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void putAll(Map m) {
        for (Iterator i = m.entrySet().iterator(); i.hasNext(); ) {
            final Entry entry = (Map.Entry)i.next();
            final Comparable key = (Comparable)entry.getKey();
            final List value = (List)entry.getValue();
            this.checkKeyValueAgreement(key, value);
        }
        for (Iterator i = m.keySet().iterator(); i.hasNext(); ) this.remove(i.next());
        this.groupingList.addAll(m.values());
    }
    
    /**
     * This convenience method ensures that the <code>key</code> matches the
     * key values produced by each of the <code>value</code> objects. If a
     * mismatch is found, an {@link IllegalArgumentException} is thrown.
     *
     * @param key the expected key value of each value object
     * @param value the value objects which should produce the given key when
     *      run through the key function
     */
    private void checkKeyValueAgreement(Comparable key, Collection value) {
        for (Iterator i = value.iterator(); i.hasNext(); ) checkKeyValueAgreement(key, i.next());
    }
    
    /**
     * This convenience method ensures that the <code>key</code> matches the
     * key value produced for the <code>value</code> object. If a
     * mismatch is found, an {@link IllegalArgumentException} is thrown.
     *
     * @param key the expected key value of each value object
     * @param value the value object which should produce the given key when
     *      run through the key function
     */
    private void checkKeyValueAgreement(Comparable key, Object value) {
        final Comparable k = key(value);
        if (!GlazedListsImpl.equal(key, k)) throw new IllegalArgumentException("The calculated key for the given value (" + k + ") does not match the given key (" + key + ")");
    }
    
    /**
     * {@inheritDoc} 
     */
    public void clear() {
        this.groupingList.clear();
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object remove(Object x0) {
        Object key = (Object)x0;
        final int index = this.keyList.indexOf(key);
        return index == -1 ? null : this.groupingList.remove(index);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Collection values() {
        return this.groupingList;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Set keySet() {
        if (this.keySet == null) this.keySet = new KeySet();
        return this.keySet;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Set entrySet() {
        if (this.entrySet == null) this.entrySet = new EntrySet();
        return this.entrySet;
    }
    
    /**
     * Updates this MultiMap datastructure to reflect changes in the underlying
     * {@link GroupingList}. Specifically, new entries are added to this
     * MultiMap by calculating a key using key function this MultiMap was
     * constructed with.
     *
     * @param listChanges an event describing the changes in the GroupingList
     */
    public void listChanged(ListEvent listChanges) {
        while (listChanges.next()) {
            final int changeIndex = listChanges.getIndex();
            final int changeType = listChanges.getType();
            if (changeType == ListEvent.INSERT) {
                final List inserted = (List)(List)listChanges.getSourceList().get(changeIndex);
                final Comparable key = key(inserted);
                this.keyList.add(changeIndex, key);
                this.delegate.put(key, inserted);
            } else if (changeType == ListEvent.DELETE) {
                final Comparable deleted = (Comparable)keyList.remove(changeIndex);
                this.delegate.remove(deleted);
            }
        }
    }
    
    /**
     * Uses the key function to return the key for a given list of values.
     *
     * @param values a non-empty list of values from the source
     *      {@link GroupingList} which share the same key value
     * @return the shared key which maps to each of the given values
     */
    private Comparable key(List values) {
        return key(values.get(0));
    }
    
    /**
     * Uses the key function to return the key for a given value.
     *
     * @param value a single value from the source list
     * @return the key which maps to the given value
     */
    private Comparable key(Object value) {
        return (Comparable)this.keyFunction.evaluate(value);
    }
    
    /**
     * This private {@link Set} implementation represents the {@link Map.Entry}
     * objects within this MultiMap. All mutating methods are implemented to
     * "write through" to the backing {@link EventList} which ensures that both
     * the {@link EventList} and this MultiMap always remain in sync.
     */
    private class EntrySet extends AbstractSet {
        
        private EntrySet() {
            super();
        }
        
        /**
         * {@inheritDoc} 
         */
        public int size() {
            return keyList.size();
        }
        
        /**
         * {@inheritDoc} 
         */
        public Iterator iterator() {
            return new EntrySetIterator(keyList.listIterator());
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry)) return false;
            final Entry e = (Entry)(Map.Entry)o;
            final Comparable key = (Comparable)e.getKey();
            final List value = (List)e.getValue();
            final List mapValue = (List)GroupingListMultiMap.this.get(key);
            return GlazedListsImpl.equal(value, mapValue);
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean remove(Object o) {
            if (!contains(o)) return false;
            GroupingListMultiMap.this.remove(((Map.Entry)(Map.Entry)o).getKey());
            return true;
        }
        
        /**
         * {@inheritDoc} 
         */
        public void clear() {
            GroupingListMultiMap.this.clear();
        }
    }
    
    /**
     * This private {@link Iterator} implementation iterates the {@link Set} of
     * {@link Map.Entry} objects within this MultiMap. All mutating methods are
     * implemented to "write through" to the backing {@link EventList} which
     * ensures that both the {@link EventList} and this MultiMap always remain
     * in sync.
     *
     * <p>Note: This implementation returns a <strong>new</strong>
     * {@link Map.Entry} object each time {@link #next} is called. Identity is
     * not preserved.
     */
    private class EntrySetIterator implements Iterator {
        
        /**
         * The delegate Iterator walks a List of keys for the MultiMap. 
         */
        private final ListIterator keyIter;
        
        /**
         * Construct a new EntrySetIterator using a delegate Iterator that
         * walks the keys of the MultMap.
         *
         * @param keyIter a {@link ListIterator} that walks the keys of the MultiMap
         */
        EntrySetIterator(ListIterator keyIter) {
            super();
            this.keyIter = keyIter;
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean hasNext() {
            return keyIter.hasNext();
        }
        
        /**
         * Returns a new {@link Map.Entry} each time this method is called.
         */
        public Object next() {
            final Comparable key = (Comparable)keyIter.next();
            return new MultiMapEntry(key, (List)get(key));
        }
        
        /**
         * {@inheritDoc} 
         */
        public void remove() {
            final int index = keyIter.previousIndex();
            if (index == -1) throw new IllegalStateException("Cannot remove() without a prior call to next()");
            groupingList.remove(index);
        }
        /*missing*/
    }
    
    /**
     * This is an implementation of the {@link Map.Entry} interface that is
     * appropriate for this MultiMap. All mutating methods are implemented to
     * "write through" to the backing {@link EventList} which ensures that
     * both the {@link EventList} and this MultiMap always remain in sync.
     */
    private class MultiMapEntry implements Map.Entry {
        
        /**
         * The MultiMap key for this Entry object. 
         */
        private final Comparable key;
        
        /**
         * The MultiMap value for this Entry object. 
         */
        private List value;
        
        /**
         * Constructs a new MultiMapEntry with the given <code>key</code> and
         * initial <code>value</code>.
         */
        MultiMapEntry(Comparable key, List value) {
            super();
            if (value == null) throw new IllegalArgumentException("value cannot be null");
            this.value = value;
            this.key = key;
        }
        
        /**
         * {@inheritDoc} 
         */
        public Object getKey() {
            return key;
        }
        
        /**
         * {@inheritDoc} 
         */
        public Object getValue() {
            return value;
        }
        
        /**
         * Since {@link GroupingList} is particular about the identity of the
         * Lists it contains, and this MultiMap uses those <strong>same</strong>
         * Lists as its values, this method is implemented to simply
         * <strong>replace</strong> the contents of the List with the contents
         * of the given <code>newValue</code>. So, the data is changed, but the
         * identity of the List in the MultiMap and {@link GroupingList} is not.
         *
         * @param newValue the new values use as elements of the value List
         * @return the old value List of this Entry
         */
        public Object setValue(Object x0) {
            List newValue = (List)x0;
            checkKeyValueAgreement((Comparable)getKey(), newValue);
            final List oldValue = new ArrayList(value);
            value.addAll(newValue);
            value.removeAll(oldValue);
            return oldValue;
        }
        
        /**
         * Two MultiMapEntry entry objects are equal iff their keys and values
         * are equal.
         */
        public boolean equals(Object o) {
            if (!(o instanceof Map.Entry)) return false;
            Map.Entry e = (Map.Entry)(Map.Entry)o;
            final boolean keysEqual = GlazedListsImpl.equal(getKey(), e.getKey());
            return keysEqual && GlazedListsImpl.equal(getValue(), e.getValue());
        }
        
        /**
         * {@inheritDoc} 
         */
        public int hashCode() {
            return (key == null ? 0 : key.hashCode()) ^ value.hashCode();
        }
        
        /**
         * {@inheritDoc} 
         */
        public String toString() {
            return getKey() + "=" + getValue();
        }
        /*missing*/
        /*missing*/
        /*missing*/
    }
    
    /**
     * This private {@link Set} implementation represents the keys within this
     * MultiMap. All mutating methods are implemented to "write through" to the
     * backing {@link EventList} which ensures that both the {@link EventList}
     * and this MultiMap always remain in sync.
     */
    private class KeySet extends AbstractSet {
        
        private KeySet() {
            super();
        }
        
        /**
         * {@inheritDoc} 
         */
        public int size() {
            return keyList.size();
        }
        
        /**
         * {@inheritDoc} 
         */
        public Iterator iterator() {
            return new KeySetIterator(keyList.listIterator());
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean contains(Object o) {
            return GroupingListMultiMap.this.containsKey(o);
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean remove(Object o) {
            return GroupingListMultiMap.this.remove(o) != null;
        }
        
        /**
         * {@inheritDoc} 
         */
        public void clear() {
            GroupingListMultiMap.this.clear();
        }
    }
    
    /**
     * This private {@link Iterator} implementation iterates the {@link Set} of
     * keys within this MultiMap. All mutating methods are implemented to
     * "write through" to the backing {@link EventList} which ensures that both
     * the {@link EventList} and this MultiMap always remain in sync.
     */
    private class KeySetIterator implements Iterator {
        
        /**
         * The delegate Iterator walks a List of keys for the MultiMap. 
         */
        private final ListIterator keyIter;
        
        /**
         * Construct a new KeySetIterator using a delegate Iterator that walks
         * the list of unique keys of the MultMap.
         *
         * @param keyIter a {@link ListIterator} that walks the keys of the MultiMap
         */
        KeySetIterator(ListIterator keyIter) {
            super();
            this.keyIter = keyIter;
        }
        
        /**
         * {@inheritDoc} 
         */
        public boolean hasNext() {
            return keyIter.hasNext();
        }
        
        /**
         * {@inheritDoc} 
         */
        public Object next() {
            return (Comparable)keyIter.next();
        }
        
        /**
         * {@inheritDoc} 
         */
        public void remove() {
            final int index = keyIter.previousIndex();
            if (index == -1) throw new IllegalStateException("Cannot remove() without a prior call to next()");
            groupingList.remove(index);
        }
        /*missing*/
    }
    
    /**
     * This Comparator first runs each value through a
     * {@link FunctionList.Function} to produce {@link Comparable} objects
     * which are then compared to determine a relative ordering.
     */
    private final class FunctionComparator implements Comparator {
        
        /**
         * A Comparator that orders {@link Comparable} objects. 
         */
        private final Comparator delegate = GlazedLists.comparableComparator();
        
        /**
         * A function that extracts {@link Comparable} values from given objects. 
         */
        private final FunctionList.Function function;
        
        /**
         * Construct a new FunctionComparator that uses the given
         * <code>function</code> to extract {@link Comparable} values from
         * given objects.
         */
        FunctionComparator(FunctionList.Function function) {
            super();
            if (function == null) throw new IllegalArgumentException("function may not be null");
            this.function = function;
        }
        
        /**
         * {@inheritDoc} 
         */
        public int compare(Object o1, Object o2) {
            final Comparable c1 = (Comparable)function.evaluate(o1);
            final Comparable c2 = (Comparable)function.evaluate(o2);
            return delegate.compare(c1, c2);
        }
    }
    
    /**
     * This Function wraps each List produced by the GroupingList with a layer
     * that ensures that mutations to it don't violate the keyFunction
     * constraints required by this MultiMap.
     */
    private final class ValueListFunction implements FunctionList.Function {
        
        private ValueListFunction() {
            super();
        }
        
        public Object evaluate(Object x0) {
            List sourceValue = (List)x0;
            return new ValueList(sourceValue);
        }
        /*missing*/
    }
    
    /**
     * This class wraps each element of the GroupingList with a layer of
     * checking to ensure that mutations to it don't violate the keyFunction
     * constraints required by this MultiMap.
     */
    private final class ValueList implements List {
        
        /**
         * The List that actually implements the List operations 
         */
        private final List delegate;
        
        /**
         * The key that all values in this List must share. 
         */
        private final Comparable key;
        
        public ValueList(List delegate) {
            super();
            this.delegate = delegate;
            this.key = key(delegate.get(0));
        }
        
        public int size() {
            return delegate.size();
        }
        
        public boolean isEmpty() {
            return delegate.isEmpty();
        }
        
        public boolean contains(Object o) {
            return delegate.contains(o);
        }
        
        public Iterator iterator() {
            return delegate.iterator();
        }
        
        public Object[] toArray() {
            return delegate.toArray();
        }
        
        public Object[] toArray(Object[] a) {
            return delegate.toArray(a);
        }
        
        public boolean add(Object o) {
            checkKeyValueAgreement(this.key, o);
            return delegate.add(o);
        }
        
        public boolean addAll(Collection c) {
            checkKeyValueAgreement(this.key, c);
            return delegate.addAll(c);
        }
        
        public boolean addAll(int index, Collection c) {
            checkKeyValueAgreement(this.key, c);
            return delegate.addAll(index, c);
        }
        
        public void add(int index, Object element) {
            checkKeyValueAgreement(this.key, element);
            delegate.add(index, element);
        }
        
        public Object set(int index, Object element) {
            checkKeyValueAgreement(this.key, element);
            return delegate.set(index, element);
        }
        
        public List subList(int fromIndex, int toIndex) {
            return new ValueList(delegate.subList(fromIndex, toIndex));
        }
        
        public ListIterator listIterator() {
            return new ValueListIterator(delegate.listIterator());
        }
        
        public ListIterator listIterator(int index) {
            return new ValueListIterator(delegate.listIterator(index));
        }
        
        public boolean remove(Object o) {
            return delegate.remove(o);
        }
        
        public boolean containsAll(Collection c) {
            return delegate.containsAll(c);
        }
        
        public boolean removeAll(Collection c) {
            return delegate.removeAll(c);
        }
        
        public boolean retainAll(Collection c) {
            return delegate.retainAll(c);
        }
        
        public void clear() {
            delegate.clear();
        }
        
        public boolean equals(Object o) {
            return delegate.equals(o);
        }
        
        public int hashCode() {
            return delegate.hashCode();
        }
        
        public Object get(int index) {
            return delegate.get(index);
        }
        
        public Object remove(int index) {
            return delegate.remove(index);
        }
        
        public int indexOf(Object o) {
            return delegate.indexOf(o);
        }
        
        public int lastIndexOf(Object o) {
            return delegate.lastIndexOf(o);
        }
        
        public String toString() {
            return delegate.toString();
        }
        
        /**
         * This class wraps the normal ListIterator returned by the GroupingList
         * elements with extra checking to ensure mutations to it don't violate
         * the keyFunction constraints required by this MultiMap.
         */
        private final class ValueListIterator implements ListIterator {
            private final ListIterator delegate;
            
            public ValueListIterator(ListIterator delegate) {
                super();
                this.delegate = delegate;
            }
            
            public void set(Object o) {
                checkKeyValueAgreement(key, o);
                delegate.set(o);
            }
            
            public void add(Object o) {
                checkKeyValueAgreement(key, o);
                delegate.add(o);
            }
            
            public boolean hasNext() {
                return delegate.hasNext();
            }
            
            public Object next() {
                return delegate.next();
            }
            
            public boolean hasPrevious() {
                return delegate.hasPrevious();
            }
            
            public Object previous() {
                return delegate.previous();
            }
            
            public int nextIndex() {
                return delegate.nextIndex();
            }
            
            public void remove() {
                delegate.remove();
            }
            
            public int previousIndex() {
                return delegate.previousIndex();
            }
        }
    }
    /*missing*/
    /*missing*/
    /*missing*/
}
