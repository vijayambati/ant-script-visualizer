package ca.odell.glazedlists.impl;

import java.util.*;
import ca.odell.glazedlists.event.*;
import ca.odell.glazedlists.*;

/**
 * This {@link ListEventListener} updates a plain old {@link List} so that
 * its contents match those of a source {@link EventList}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SyncListener implements ListEventListener {
    
    /**
     * the list to sync against the {@link EventList}. 
     */
    private List target;
    
    /**
     * remember sync list size to attempt to detect drifts 
     */
    private int targetSize;
    
    /**
     * Create a {@link SyncListener} that listens for changes on the
     * specified source {@link EventList} and copies its data to the
     * specified target {@link List}.
     */
    public SyncListener(EventList source, List target) {
        super();
        this.target = target;
        target.clear();
        target.addAll(source);
        targetSize = target.size();
        source.addListEventListener(this);
    }
    
    /**
     * {@inheritDoc} 
     */
    public void listChanged(ListEvent listChanges) {
        EventList source = listChanges.getSourceList();
        if (target.size() != targetSize) {
            throw new IllegalStateException("Synchronize EventList target has been modified");
        }
        while (listChanges.next()) {
            int index = listChanges.getIndex();
            int type = listChanges.getType();
            if (type == ListEvent.INSERT) {
                target.add(index, source.get(index));
                targetSize++;
            } else if (type == ListEvent.UPDATE) {
                target.set(index, source.get(index));
            } else if (type == ListEvent.DELETE) {
                target.remove(index);
                targetSize--;
            }
        }
    }
}
