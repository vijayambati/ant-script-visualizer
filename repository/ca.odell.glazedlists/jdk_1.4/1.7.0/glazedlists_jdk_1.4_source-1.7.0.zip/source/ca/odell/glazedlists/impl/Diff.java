package ca.odell.glazedlists.impl;

import ca.odell.glazedlists.EventList;
import java.util.*;

/**
 * Implementation of Eugene W. Myer's paper, "An O(ND) Difference Algorithm and
 * Its Variations", the same algorithm found in GNU diff.
 *
 * <p>Note that this is a cleanroom implementation of this popular algorithm
 * that is particularly suited for the Java programmer. The variable names are
 * descriptive and the approach is more object-oriented than Myer's sample
 * algorithm.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class Diff {
    
    public Diff() {
        super();
    }
    
    /**
     * Convenience method for {@link #replaceAll(EventList,List,boolean,Comparator)
     * replaceAll()} that uses {@link Object#equals(Object)} to determine
     * equality.
     */
    public static void replaceAll(EventList target, List source, boolean updates) {
        replaceAll(target, source, updates, new EqualsComparator());
    }
    
    /**
     * Replace the complete contents of the target {@link EventList} with the
     * complete contents of the source {@link EventList} while making as few
     * list changes as possible.
     *
     * @param comparator a {@link Comparator} to use to test only for equality.
     *      This comparator shall return 0 to signal that two elements are
     *      equal, and nonzero otherwise.
     * @param updates whether to fire update events for Objects that are equal
     *      in both {@link List}s.
     */
    public static void replaceAll(EventList target, List source, boolean updates, Comparator comparator) {
        DiffMatcher listDiffMatcher = new ListDiffMatcher(target, source, comparator);
        List editScript = shortestEditScript(listDiffMatcher);
        int targetIndex = 0;
        int sourceIndex = 0;
        Point previousPoint = null;
        for (Iterator i = editScript.iterator(); i.hasNext(); ) {
            Point currentPoint = (Diff.Point)i.next();
            if (previousPoint == null) {
                previousPoint = currentPoint;
                continue;
            }
            int deltaX = currentPoint.getX() - previousPoint.getX();
            int deltaY = currentPoint.getY() - previousPoint.getY();
            if (deltaX == deltaY) {
                if (updates) {
                    for (int u = 0; u < deltaX; u++) {
                        target.set(targetIndex + u, source.get(sourceIndex + u));
                    }
                }
                targetIndex += deltaX;
                sourceIndex += deltaY;
            } else if (deltaX == 1 && deltaY == 0) {
                target.remove(targetIndex);
            } else if (deltaX == 0 && deltaY == 1) {
                target.add(targetIndex, source.get(sourceIndex));
                sourceIndex++;
                targetIndex++;
            } else {
                throw new IllegalStateException();
            }
            previousPoint = currentPoint;
        }
    }
    
    /**
     * Calculate the length of the longest common subsequence for the specified
     * input.
     */
    private static List shortestEditScript(DiffMatcher input) {
        int N = input.getAlphaLength();
        int M = input.getBetaLength();
        Point maxPoint = new Point(N, M);
        int maxSteps = N + M;
        Map furthestReachingPoints = new HashMap();
        for (int D = 0; D <= maxSteps; D++) {
            for (int k = -D; k <= D; k += 2) {
                Point belowLeft = (Diff.Point)furthestReachingPoints.get(new Integer(k - 1));
                Point aboveRight = (Diff.Point)furthestReachingPoints.get(new Integer(k + 1));
                Point point;
                if (furthestReachingPoints.isEmpty()) {
                    point = new Point(0, 0);
                } else if (k == -D || (k != D && belowLeft.getX() < aboveRight.getX())) {
                    point = aboveRight.createDeltaPoint(0, 1);
                } else {
                    point = belowLeft.createDeltaPoint(1, 0);
                }
                while (point.isLessThan(maxPoint) && input.matchPair(point.getX(), point.getY())) {
                    point = point.incrementDiagonally();
                }
                furthestReachingPoints.put(new Integer(k), point);
                if (point.isEqualToOrGreaterThan(maxPoint)) {
                    return point.trail();
                }
            }
        }
        throw new IllegalStateException();
    }
    
    /**
     * Models an X and Y point in a path. The top-left corner of the axis is the point (0,
     * 0). This is the lowest point in both the x and y dimensions. Negative points are
     * not allowed.
     */
    private static class Point {
        private int x = 0;
        private int y = 0;
        private Point predecessor = null;
        
        /**
         * Create a new point with the specified coordinates and no predecessor.
         */
        public Point(int x, int y) {
            super();
            this.x = x;
            this.y = y;
        }
        
        /**
         * Creates a new point from this point by shifting its values as specified. The
         * new point keeps a reference to its source in order to create a path later.
         */
        public Point createDeltaPoint(int deltaX, int deltaY) {
            Point result = new Point(x + deltaX, y + deltaY);
            result.predecessor = this;
            return result;
        }
        
        /**
         * Shifts <code>x</code> and <code>y</code> values down and to the
         * right by one.
         */
        public Point incrementDiagonally() {
            Point result = createDeltaPoint(1, 1);
            if (predecessor != null) {
                int deltaX = result.x - predecessor.x;
                int deltaY = result.y - predecessor.y;
                if (deltaX == deltaY) {
                    result.predecessor = this.predecessor;
                }
            }
            return result;
        }
        
        public int getX() {
            return x;
        }
        
        public int getY() {
            return y;
        }
        
        public boolean isLessThan(Point other) {
            return x < other.x && y < other.y;
        }
        
        public boolean isEqualToOrGreaterThan(Point other) {
            return x >= other.x && y >= other.y;
        }
        
        public String toString() {
            return "(" + x + "," + y + ")";
        }
        
        /**
         * Get a trail from the original point to this point. This is a list of
         * all points created via a series of {@link #createDeltaPoint(int,int)}
         * calls.
         */
        public List trail() {
            List reverse = new ArrayList();
            Point current = this;
            while (current != null) {
                reverse.add(current);
                current = current.predecessor;
            }
            Collections.reverse(reverse);
            return reverse;
        }
    }
    
    /**
     * Determines if the values at the specified points match or not.
     *
     * <p>This class specifies that each element should specify a character value.
     * This is for testing and debugging only and it is safe for implementing
     * classes to throw {@link UnsupportedOperationException} for both the
     * {@link #alphaAt(int)} and {@link #betaAt(int)} methods.
     */
    interface DiffMatcher {
        
        public int getAlphaLength();
        
        public int getBetaLength();
        
        public boolean matchPair(int alphaIndex, int betaIndex);
        
        /**
         * Output a character representing the specified element, for
         * the convenience of testing.
         */
        public char alphaAt(int index);
        
        public char betaAt(int index);
    }
    
    /**
     * Matcher for Lists.
     */
    static class ListDiffMatcher implements DiffMatcher {
        private List alpha;
        private List beta;
        private Comparator comparator;
        
        public ListDiffMatcher(List alpha, List beta, Comparator comparator) {
            super();
            this.alpha = alpha;
            this.beta = beta;
            this.comparator = comparator;
        }
        
        public int getAlphaLength() {
            return alpha.size();
        }
        
        public char alphaAt(int index) {
            return alpha.get(index).toString().charAt(0);
        }
        
        public char betaAt(int index) {
            return beta.get(index).toString().charAt(0);
        }
        
        public int getBetaLength() {
            return beta.size();
        }
        
        public boolean matchPair(int alphaIndex, int betaIndex) {
            return (comparator.compare(alpha.get(alphaIndex), beta.get(betaIndex)) == 0);
        }
    }
    
    /**
     * This non-symmetric comparator returns 0 if two Objects are equal as
     * specified by {@link Object#equals(Object)}, or 1 otherwise.
     */
    private static class EqualsComparator implements Comparator {
        
        private EqualsComparator() {
            super();
        }
        
        public int compare(Object alpha, Object beta) {
            boolean equal = alpha == null ? beta == null : alpha.equals(beta);
            return equal ? 0 : 1;
        }
    }
}
