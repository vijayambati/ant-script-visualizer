package ca.odell.glazedlists.impl.adt.barcode2;

import java.util.AbstractList;

/**
 * Adapt a {@link FourColorTree} for use as a {@link List}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class FourColorTreeAsList extends AbstractList {
    private final FourColorTree tree;
    private final byte colors;
    
    /**
     * the color of inserted or added elements 
     */
    private final byte color;
    
    /**
     * Create a new {@link FourColorTreeAsList} adapting the specified tree.
     */
    public FourColorTreeAsList(FourColorTree tree) {
        this(tree, tree.getCoder().colorsToByte(tree.getCoder().getColors()), (byte)1);
    }
    
    /**
     * Create a new {@link FourColorTreeAsList}, adapting the specified colors subset
     * of the specified tree. Inserted elements via {@link #add} will be of the
     * specified color.
     */
    public FourColorTreeAsList(FourColorTree tree, byte colors, byte color) {
        super();
        this.tree = tree;
        this.colors = colors;
        this.color = color;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object get(int index) {
        return tree.get(index, colors).get();
    }
    
    /**
     * {@inheritDoc} 
     */
    public void add(int index, Object element) {
        tree.add(index, colors, color, element, 1);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object set(int index, Object element) {
        Object replaced = get(index);
        tree.set(index, colors, color, element, 1);
        return replaced;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object remove(int index) {
        Object removed = get(index);
        tree.remove(index, colors, 1);
        return removed;
    }
    
    /**
     * {@inheritDoc} 
     */
    public int size() {
        return tree.size(colors);
    }
}
