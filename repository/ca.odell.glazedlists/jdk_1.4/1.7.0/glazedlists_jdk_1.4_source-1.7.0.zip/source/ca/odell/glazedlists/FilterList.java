package ca.odell.glazedlists;

import ca.odell.glazedlists.event.*;
import ca.odell.glazedlists.matchers.*;
import ca.odell.glazedlists.impl.adt.*;

/**
 * An {@link EventList} that shows a subset of the elements of a source
 * {@link EventList}. This subset is composed of all elements of the source
 * {@link EventList} that match the filter.
 *
 * <p>The filter can be static or dynamic. Changing the behaviour of the filter
 * will change which elements of the source list are included.
 *
 * <p><strong><font color="#FF0000">Warning:</font></strong> This class
 * breaks the contract required by {@link java.util.List}. See {@link EventList}
 * for an example.
 *
 * <p><table border="1" width="100%" cellpadding="3" cellspacing="0">
 * <tr class="TableHeadingColor"><td colspan=2><font size="+2"><b>EventList Overview</b></font></td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Writable:</b></td><td>yes</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Concurrency:</b></td><td>thread ready, not thread safe</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Performance:</b></td><td>reads: O(log N), writes O(log N), filter changes O(N)</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Memory:</b></td><td>0 to 26 bytes per element</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Unit Tests:</b></td><td>N/A</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Issues:</b></td><td>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=1">1</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=2">2</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=7">7</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=46">46</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=187">187</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=254">254</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=312">312</a>
 * </td></tr>
 * </table>
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 * @author James Lemieux
 */
public final class FilterList extends TransformedList {
    
    /**
     * the flag list contains Barcode.BLACK for items that match the current filter and Barcode.WHITE for others 
     */
    private Barcode flagList = new Barcode();
    
    /**
     * the matcher determines whether elements get filtered in or out 
     */
    private Matcher currentMatcher = Matchers.trueMatcher();
    
    /**
     * the editor changes the matcher and fires events 
     */
    private MatcherEditor currentEditor = null;
    
    /**
     * listener handles changes to the matcher 
     */
    private final MatcherEditor.Listener listener = new PrivateMatcherEditorListener();
    
    /**
     * Creates a {@link FilterList} that includes a subset of the specified
     * source {@link EventList}.
     */
    public FilterList(EventList source) {
        super(source);
        flagList.addBlack(0, source.size());
        source.addListEventListener(this);
    }
    
    /**
     * Convenience constructor for creating a {@link FilterList} and setting its
     * {@link Matcher}.
     */
    public FilterList(EventList source, Matcher matcher) {
        this(source);
        if (matcher == null) return;
        currentMatcher = matcher;
        changed();
    }
    
    /**
     * Convenience constructor for creating a {@link FilterList} and setting its
     * {@link MatcherEditor}.
     */
    public FilterList(EventList source, MatcherEditor matcherEditor) {
        this(source);
        if (matcherEditor == null) return;
        currentEditor = matcherEditor;
        currentEditor.addMatcherEditorListener(listener);
        currentMatcher = currentEditor.getMatcher();
        changed();
    }
    
    /**
     * Set the {@link Matcher} which specifies which elements shall be filtered.
     *
     * <p>This will remove the current {@link Matcher} or {@link MatcherEditor}
     * and refilter the entire list.
     */
    public void setMatcher(Matcher matcher) {
        if (currentEditor != null) {
            currentEditor.removeMatcherEditorListener(listener);
            currentEditor = null;
        }
        if (matcher != null) changeMatcherWithLocks(currentEditor, matcher, MatcherEditor.Event.CHANGED); else changeMatcherWithLocks(currentEditor, null, MatcherEditor.Event.MATCH_ALL);
    }
    
    /**
     * Set the {@link MatcherEditor} which provides a dynamic {@link Matcher}
     * to determine which elements shall be filtered.
     *
     * <p>This will remove the current {@link Matcher} or {@link MatcherEditor}
     * and refilter the entire list.
     */
    public void setMatcherEditor(MatcherEditor editor) {
        if (currentEditor != null) currentEditor.removeMatcherEditorListener(listener);
        currentEditor = editor;
        if (currentEditor != null) {
            currentEditor.addMatcherEditorListener(listener);
            changeMatcherWithLocks(currentEditor, currentEditor.getMatcher(), MatcherEditor.Event.CHANGED);
        } else {
            changeMatcherWithLocks(currentEditor, null, MatcherEditor.Event.MATCH_ALL);
        }
    }
    
    /**
     * @inheritDoc 
     */
    public void dispose() {
        super.dispose();
        if (currentEditor != null) {
            currentEditor.removeMatcherEditorListener(listener);
            currentEditor = null;
        }
        currentMatcher = null;
    }
    
    /**
     * {@inheritDoc} 
     */
    public final void listChanged(ListEvent listChanges) {
        updates.beginEvent();
        if (listChanges.isReordering()) {
            int[] sourceReorderMap = listChanges.getReorderMap();
            int[] filterReorderMap = new int[flagList.blackSize()];
            Barcode previousFlagList = flagList;
            flagList = new Barcode();
            for (int i = 0; i < sourceReorderMap.length; i++) {
                Object flag = previousFlagList.get(sourceReorderMap[i]);
                flagList.add(i, flag, 1);
                if (flag != Barcode.WHITE) filterReorderMap[flagList.getBlackIndex(i)] = previousFlagList.getBlackIndex(sourceReorderMap[i]);
            }
            updates.reorder(filterReorderMap);
        } else {
            while (listChanges.next()) {
                int sourceIndex = listChanges.getIndex();
                int changeType = listChanges.getType();
                if (changeType == ListEvent.DELETE) {
                    int filteredIndex = flagList.getBlackIndex(sourceIndex);
                    if (filteredIndex != -1) {
                        updates.addDelete(filteredIndex);
                    }
                    flagList.remove(sourceIndex, 1);
                } else if (changeType == ListEvent.INSERT) {
                    boolean include = currentMatcher.matches(source.get(sourceIndex));
                    if (include) {
                        flagList.addBlack(sourceIndex, 1);
                        int filteredIndex = flagList.getBlackIndex(sourceIndex);
                        updates.addInsert(filteredIndex);
                    } else {
                        flagList.addWhite(sourceIndex, 1);
                    }
                } else if (changeType == ListEvent.UPDATE) {
                    int filteredIndex = flagList.getBlackIndex(sourceIndex);
                    boolean wasIncluded = filteredIndex != -1;
                    boolean include = currentMatcher.matches(source.get(sourceIndex));
                    if (wasIncluded && !include) {
                        flagList.setWhite(sourceIndex, 1);
                        updates.addDelete(filteredIndex);
                    } else if (!wasIncluded && include) {
                        flagList.setBlack(sourceIndex, 1);
                        updates.addInsert(flagList.getBlackIndex(sourceIndex));
                    } else if (wasIncluded && include) {
                        updates.addUpdate(filteredIndex);
                    }
                }
            }
        }
        updates.commitEvent();
    }
    
    /**
     * This method acquires the write lock for the FilterList and then selects
     * an appropriate delegate method to perform the correct work for each of
     * the possible <code>changeType</code>s.
     */
    private void changeMatcherWithLocks(MatcherEditor matcherEditor, Matcher matcher, int changeType) {
        getReadWriteLock().writeLock().lock();
        try {
            changeMatcher(matcherEditor, matcher, changeType);
        } finally {
            getReadWriteLock().writeLock().unlock();
        }
    }
    
    /**
     * This method selects an appropriate delegate method to perform the
     * correct work for each of the possible <code>changeType</code>s. This
     * method does <strong>NOT</strong> acquire any locks and is thus used
     * during initialization of FilterList.
     */
    private void changeMatcher(MatcherEditor matcherEditor, Matcher matcher, int changeType) {
        if (currentEditor != matcherEditor) throw new IllegalStateException();
        switch (changeType) {
        case MatcherEditor.Event.CONSTRAINED: 
            currentMatcher = matcher;
            this.constrained();
            break;
        
        case MatcherEditor.Event.RELAXED: 
            currentMatcher = matcher;
            this.relaxed();
            break;
        
        case MatcherEditor.Event.CHANGED: 
            currentMatcher = matcher;
            this.changed();
            break;
        
        case MatcherEditor.Event.MATCH_ALL: 
            currentMatcher = Matchers.trueMatcher();
            this.matchAll();
            break;
        
        case MatcherEditor.Event.MATCH_NONE: 
            currentMatcher = Matchers.falseMatcher();
            this.matchNone();
            break;
        
        }
    }
    
    /**
     * Handles a constraining of the filter to a degree that guarantees no
     * values can be matched. That is, the filter list will act as a total
     * filter and not match any of the elements of the wrapped source list.
     */
    private void matchNone() {
        updates.beginEvent();
        if (size() > 0) updates.addDelete(0, size() - 1);
        flagList.clear();
        flagList.addWhite(0, source.size());
        updates.commitEvent();
    }
    
    /**
     * Handles a clearing of the filter. That is, the filter list will act as
     * a passthrough and not discriminate any of the elements of the wrapped
     * source list.
     */
    private void matchAll() {
        updates.beginEvent();
        for (BarcodeIterator i = flagList.iterator(); i.hasNextWhite(); ) {
            i.nextWhite();
            updates.addInsert(i.getIndex());
        }
        flagList.clear();
        flagList.addBlack(0, source.size());
        updates.commitEvent();
    }
    
    /**
     * Handles a relaxing or widening of the filter. This may change the
     * contents of this {@link EventList} as filtered elements are unfiltered
     * due to the relaxation of the filter.
     */
    private void relaxed() {
        updates.beginEvent();
        for (BarcodeIterator i = flagList.iterator(); i.hasNextWhite(); ) {
            i.nextWhite();
            if (currentMatcher.matches(source.get(i.getIndex()))) {
                updates.addInsert(i.setBlack());
            }
        }
        updates.commitEvent();
    }
    
    /**
     * Handles a constraining or narrowing of the filter. This may change the
     * contents of this {@link EventList} as elements are further filtered due
     * to the constraining of the filter.
     */
    private void constrained() {
        updates.beginEvent();
        for (BarcodeIterator i = flagList.iterator(); i.hasNextBlack(); ) {
            i.nextBlack();
            if (!currentMatcher.matches(source.get(i.getIndex()))) {
                int blackIndex = i.getBlackIndex();
                i.setWhite();
                updates.addDelete(blackIndex);
            }
        }
        updates.commitEvent();
    }
    
    /**
     * Handles changes to the behavior of the filter. This may change the contents
     * of this {@link EventList} as elements are filtered and unfiltered.
     */
    private void changed() {
        updates.beginEvent();
        for (BarcodeIterator i = flagList.iterator(); i.hasNext(); ) {
            i.next();
            int filteredIndex = i.getBlackIndex();
            boolean wasIncluded = filteredIndex != -1;
            boolean include = currentMatcher.matches(source.get(i.getIndex()));
            if (wasIncluded && !include) {
                i.setWhite();
                updates.addDelete(filteredIndex);
            } else if (!wasIncluded && include) {
                updates.addInsert(i.setBlack());
            }
        }
        updates.commitEvent();
    }
    
    /**
     * Listens to changes from the current {@link MatcherEditor} and handles them.
     */
    private class PrivateMatcherEditorListener implements MatcherEditor.Listener {
        
        private PrivateMatcherEditorListener() {
            super();
        }
        
        /**
         * This method changes the current Matcher controlling the filtering on
         * the FilterList. It does so in a thread-safe manner by acquiring the
         * write lock.
         *
         * @param matcherEvent a MatcherEvent describing the change in the
         *      Matcher produced by the MatcherEditor
         */
        public void changedMatcher(MatcherEditor.Event matcherEvent) {
            final MatcherEditor matcherEditor = matcherEvent.getMatcherEditor();
            final Matcher matcher = matcherEvent.getMatcher();
            final int changeType = matcherEvent.getType();
            changeMatcherWithLocks(matcherEditor, matcher, changeType);
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public final int size() {
        return flagList.blackSize();
    }
    
    /**
     * {@inheritDoc} 
     */
    protected final int getSourceIndex(int mutationIndex) {
        return flagList.getIndex(mutationIndex, Barcode.BLACK);
    }
    
    /**
     * {@inheritDoc} 
     */
    protected boolean isWritable() {
        return true;
    }
}
