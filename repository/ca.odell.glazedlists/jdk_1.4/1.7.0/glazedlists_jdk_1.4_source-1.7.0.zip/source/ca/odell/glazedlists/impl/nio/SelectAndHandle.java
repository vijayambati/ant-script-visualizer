package ca.odell.glazedlists.impl.nio;

import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * The SelectAndHandle selects ready keys and handles them.
 */
class SelectAndHandle implements Runnable {
    
    /**
     * logging 
     */
    private static Logger logger = Logger.getLogger(SelectAndHandle.class.toString());
    
    /**
     * the I/O event queue daemon 
     */
    private NIODaemon nioDaemon = null;
    
    /**
     * Create a new SelectorHandler for the specified NIO Daemon.
     */
    public SelectAndHandle(NIODaemon nioDaemon) {
        super();
        this.nioDaemon = nioDaemon;
    }
    
    /**
     * Select and handle.
     */
    public void run() {
        select();
        handle();
    }
    
    /**
     * Selects keys which are ready to be processed.
     */
    void select() {
        try {
            nioDaemon.getSelector().select();
        } catch (IOException e) {
            logger.log(Level.WARNING, e.getMessage(), e);
        }
    }
    
    /**
     * Handles all keys which are ready to be processed.
     */
    void handle() {
        for (Iterator i = nioDaemon.getSelector().selectedKeys().iterator(); i.hasNext(); ) {
            SelectionKey key = (SelectionKey)(SelectionKey)i.next();
            i.remove();
            if (key.isValid() && key.isAcceptable()) {
                nioDaemon.getServer().handleAccept(key, nioDaemon.getSelector());
            }
            if (key.isValid() && key.isConnectable()) {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.handleConnect();
            }
            if (key.isValid() && key.isReadable()) {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.handleRead();
            }
            if (key.isValid() && key.isWritable()) {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.handleWrite();
            }
            if (!key.isValid()) {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.close(new IOException("Connection closed"));
            }
        }
    }
}
