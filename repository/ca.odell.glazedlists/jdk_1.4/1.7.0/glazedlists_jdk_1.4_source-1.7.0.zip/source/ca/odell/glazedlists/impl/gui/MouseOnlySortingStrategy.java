package ca.odell.glazedlists.impl.gui;

import java.util.List;
import java.util.Iterator;

/**
 * @see ca.odell.glazedlists.gui.AbstractTableComparatorChooser.SINGLE_COLUMN
 * @see ca.odell.glazedlists.gui.AbstractTableComparatorChooser.MULTIPLE_COLUMN_MOUSE
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class MouseOnlySortingStrategy implements SortingStrategy {
    
    /**
     * if false, other sorting columns will be cleared before a click takes effect 
     */
    private final boolean multipleColumnSort;
    
    /**
     * Create a new {@link ca.odell.glazedlists.impl.gui.MouseOnlySortingStrategy}, sorting multiple
     * columns or not as specified.
     */
    public MouseOnlySortingStrategy(boolean multipleColumnSort) {
        super();
        this.multipleColumnSort = multipleColumnSort;
    }
    
    /**
     * Adjust the sorting state based on receiving the specified clicks.
     */
    public void columnClicked(SortingState sortingState, int column, int clicks, boolean shift, boolean control) {
        SortingState.SortingColumn clickedColumn = (SortingState.SortingColumn)sortingState.getColumns().get(column);
        if (clickedColumn.getComparators().isEmpty()) return;
        List recentlyClickedColumns = sortingState.getRecentlyClickedColumns();
        if (clicks == 2) {
            for (Iterator i = recentlyClickedColumns.iterator(); i.hasNext(); ) {
                SortingState.SortingColumn sortingColumn = (SortingState.SortingColumn)i.next();
                sortingColumn.clear();
            }
            recentlyClickedColumns.clear();
        } else if (!multipleColumnSort) {
            for (Iterator i = recentlyClickedColumns.iterator(); i.hasNext(); ) {
                SortingState.SortingColumn sortingColumn = (SortingState.SortingColumn)i.next();
                if (sortingColumn != clickedColumn) {
                    sortingColumn.clear();
                }
            }
            recentlyClickedColumns.clear();
        }
        int netClicks = 1 + clickedColumn.getComparatorIndex() * 2 + (clickedColumn.isReverse() ? 1 : 0);
        clickedColumn.setComparatorIndex((netClicks / 2) % clickedColumn.getComparators().size());
        clickedColumn.setReverse(netClicks % 2 == 1);
        if (!recentlyClickedColumns.contains(clickedColumn)) {
            recentlyClickedColumns.add(clickedColumn);
        }
        sortingState.fireSortingChanged();
    }
}
