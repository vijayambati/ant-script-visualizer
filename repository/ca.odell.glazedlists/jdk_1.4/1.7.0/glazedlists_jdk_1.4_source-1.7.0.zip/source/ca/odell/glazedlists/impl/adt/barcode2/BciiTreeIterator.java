package ca.odell.glazedlists.impl.adt.barcode2;

import java.util.NoSuchElementException;

/**
 * Iterate through a {@link BciiTree}, one element at a time.
 *
 * <p>We should consider adding the following enhancements to this class:
 * <li>writing methods, such as <code>set()</code> and <code>remove()</code>.
 * <li>a default color, specified at construction time, that shall always be
 *     used as the implicit parameter to overloaded versions of {@link #hasNext}
 *     and {@link #next}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class BciiTreeIterator {
    int count1;
    int count2;
    int count4;
    private BciiTree tree;
    private BciiNode node;
    private int index;
    
    public BciiTreeIterator(BciiTree tree) {
        this(tree, 0, (byte)0);
    }
    
    /**
     * Create an iterator starting at the specified index.
     *
     * @param tree the tree to iterate
     * @param nextIndex the index to be returned after calling {@link #next next()}.
     * @param nextIndexColors the colors to interpret nextIndex in terms of
     */
    public BciiTreeIterator(BciiTree tree, int nextIndex, byte nextIndexColors) {
        super();
        this.tree = tree;
        if (nextIndex != 0) {
            int currentIndex = nextIndex - 1;
            this.node = (BciiNode)(BciiNode)tree.get(currentIndex, nextIndexColors);
            count1 = tree.convertIndexColor(currentIndex, nextIndexColors, (byte)1) + (node.color == 1 ? 0 : 1);
            count2 = tree.convertIndexColor(currentIndex, nextIndexColors, (byte)2) + (node.color == 2 ? 0 : 1);
            count4 = tree.convertIndexColor(currentIndex, nextIndexColors, (byte)4) + (node.color == 4 ? 0 : 1);
            if (node.color == 1) this.index = count1 - tree.indexOfNode(this.node, (byte)1);
            if (node.color == 2) this.index = count2 - tree.indexOfNode(this.node, (byte)2);
            if (node.color == 4) this.index = count4 - tree.indexOfNode(this.node, (byte)4);
        } else {
            this.node = null;
            this.index = 0;
        }
    }
    
    /**
     * Create a {@link BciiTreeIterator} exactly the same as this one.
     * The iterators will be backed by the same tree but maintain
     * separate cursors into the tree.
     */
    public BciiTreeIterator copy() {
        BciiTreeIterator result = new BciiTreeIterator(tree);
        result.count1 = this.count1;
        result.count2 = this.count2;
        result.count4 = this.count4;
        result.node = node;
        result.index = index;
        return result;
    }
    
    /**
     * @return <code>true</code> if there's an element of the specified color in
     *     this tree following the current element.
     */
    public boolean hasNext(byte colors) {
        if (node == null) {
            return tree.size(colors) > 0;
        } else if ((colors & node.color) != 0) {
            return index(colors) < tree.size(colors) - 1;
        } else {
            return index(colors) < tree.size(colors);
        }
    }
    
    /**
     * @return <code>true</code> if there's a node of the specified color in this
     *      tree following the current node.
     */
    public boolean hasNextNode(byte colors) {
        if (node == null) {
            return tree.size(colors) > 0;
        } else {
            return nodeEndIndex(colors) < tree.size(colors);
        }
    }
    
    /**
     * Step to the next element.
     */
    public void next(byte colors) {
        if (!hasNext(colors)) {
            throw new NoSuchElementException();
        }
        if (node == null) {
            node = tree.firstNode();
            index = 0;
            if ((node.color & colors) != 0) return;
        } else if ((node.color & colors) != 0 && index < node.size - 1) {
            if (node.color == 1) count1++;
            if (node.color == 2) count2++;
            if (node.color == 4) count4++;
            index++;
            return;
        }
        while (true) {
            if (node.color == 1) count1 += node.size - index;
            if (node.color == 2) count2 += node.size - index;
            if (node.color == 4) count4 += node.size - index;
            node = BciiTree.next(node);
            index = 0;
            if ((node.color & colors) != 0) break;
        }
    }
    
    /**
     * Step to the next node.
     */
    public void nextNode(byte colors) {
        if (!hasNextNode(colors)) {
            throw new NoSuchElementException();
        }
        if (node == null) {
            node = tree.firstNode();
            index = 0;
            if ((node.color & colors) != 0) return;
        }
        while (true) {
            if (node.color == 1) count1 += node.size - index;
            if (node.color == 2) count2 += node.size - index;
            if (node.color == 4) count4 += node.size - index;
            node = BciiTree.next(node);
            index = 0;
            if ((node.color & colors) != 0) break;
        }
    }
    
    /**
     * Get the size of the current node, or 0 if it's color doesn't match those
     * specified.
     */
    public int nodeSize(byte colors) {
        if ((node.color & colors) != 0) {
            return node.size;
        } else {
            return 0;
        }
    }
    
    /**
     * The color of the current element.
     */
    public byte color() {
        if (node == null) throw new IllegalStateException();
        return node.color;
    }
    
    /**
     * Expected values for index should be in the range  ( 0, size() - 1 )
     */
    public int index(byte colors) {
        if (node == null) throw new NoSuchElementException();
        int result = 0;
        if ((colors & 1) != 0) result += count1;
        if ((colors & 2) != 0) result += count2;
        if ((colors & 4) != 0) result += count4;
        return result;
    }
    
    /**
     * Get the index of the current node's start.
     */
    public int nodeStartIndex(byte colors) {
        if (node == null) throw new NoSuchElementException();
        int result = 0;
        if ((colors & 1) != 0) result += count1;
        if ((colors & 2) != 0) result += count2;
        if ((colors & 4) != 0) result += count4;
        if ((node.color & colors) != 0) {
            result -= index;
        }
        return result;
    }
    
    /**
     * Get the index of the node immediately following the current. Expected
     * values are in the range ( 1, size() )
     */
    public int nodeEndIndex(byte colors) {
        if (node == null) throw new NoSuchElementException();
        return nodeStartIndex(colors) + nodeSize(colors);
    }
    
    public Object value() {
        if (node == null) throw new IllegalStateException();
        return node.get();
    }
    
    public Element node() {
        if (node == null) throw new IllegalStateException();
        return node;
    }
}
