package ca.odell.glazedlists.impl.matchers;

import ca.odell.glazedlists.matchers.Matcher;

/**
 * A simple {@link Matcher} implementation that inverts the result of another
 * {@link Matcher Matcher's} {@link Matcher#matches(Object)} method.
 *
 * @author <a href="mailto:rob@starlight-systems.com">Rob Eden</a>
 */
public class NotMatcher implements Matcher {
    private Matcher parent;
    
    public NotMatcher(Matcher parent) {
        super();
        if (parent == null) throw new IllegalArgumentException("parent cannot be null");
        this.parent = parent;
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean matches(Object item) {
        return !parent.matches(item);
    }
    
    /**
     * {@inheritDoc} 
     */
    public String toString() {
        return "[NotMatcher parent:" + parent + "]";
    }
}
