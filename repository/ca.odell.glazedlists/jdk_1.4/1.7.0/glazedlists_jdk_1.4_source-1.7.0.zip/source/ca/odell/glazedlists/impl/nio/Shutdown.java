package ca.odell.glazedlists.impl.nio;

import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * A task that gracefully shuts down the NIO daemon.
 */
class Shutdown implements Runnable {
    
    /**
     * logging 
     */
    private static Logger logger = Logger.getLogger(Shutdown.class.toString());
    
    /**
     * the I/O event queue daemon 
     */
    private NIODaemon nioDaemon = null;
    
    /**
     * Create a new NIOShutdown that shuts down a server using the specified
     * NIODaemon.
     */
    public Shutdown(NIODaemon nioDaemon) {
        super();
        this.nioDaemon = nioDaemon;
    }
    
    /**
     * Runs the specified task.
     *
     * @param selector the selector being shared by all connections.
     * @return true unless the server shall shutdown due to a shutdown request or
     *      an unrecoverable failure.
     */
    public void run() {
        logger.info("Cleaning up listening socket and closing " + (nioDaemon.getSelector().keys().size() - 1) + " connections");
        for (Iterator k = nioDaemon.getSelector().keys().iterator(); k.hasNext(); ) {
            SelectionKey key = (SelectionKey)(SelectionKey)k.next();
            if (!key.isValid()) {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.close(new IOException("Connection closed"));
            } else if ((key.interestOps() & SelectionKey.OP_ACCEPT) != 0) {
                try {
                    ServerSocketChannel server = (ServerSocketChannel)(ServerSocketChannel)key.channel();
                    server.close();
                    key.cancel();
                } catch (IOException e) {
                    logger.warning("Error closing server socket, " + e.getMessage());
                }
            } else {
                NIOAttachment attachment = (NIOAttachment)(NIOAttachment)key.attachment();
                attachment.close(new ServerShutdownException());
            }
        }
    }
}
