package ca.odell.glazedlists;

import ca.odell.glazedlists.util.concurrent.*;
import ca.odell.glazedlists.event.ListEventListener;
import ca.odell.glazedlists.event.ListEventPublisher;
import java.util.*;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

/**
 * An {@link EventList} that wraps any simple {@link List}, such as {@link ArrayList}
 * or {@link LinkedList}.
 *
 * <p>Unlike most {@link EventList}s, this class is {@link Serializable}. When
 * {@link BasicEventList} is serialized, all of its elements are serialized
 * <i>and</i> all of its listeners that implement {@link Serializable}. Upon
 * deserialization, the new copy uses a different {@link #getReadWriteLock() lock}
 * than its source {@link BasicEventList}.
 *
 * <p><table border="1" width="100%" cellpadding="3" cellspacing="0">
 * <tr class="TableHeadingColor"><td colspan=2><font size="+2"><b>EventList Overview</b></font></td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Writable:</b></td><td>yes</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Concurrency:</b></td><td>thread ready, not thread safe</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Performance:</b></td><td>reads: O(1), writes O(1) amortized</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Memory:</b></td><td>O(N)</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Unit Tests:</b></td><td>N/A</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Issues:</b></td><td>N/A</td></tr>
 * </table>
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class BasicEventList extends AbstractEventList implements Serializable {
    
    /**
     * For versioning as a {@link Serializable} 
     */
    private static final long serialVersionUID = 4883958173323072345L;
    
    /**
     * the underlying data list 
     */
    private List data;
    
    /**
     * Creates a {@link BasicEventList}.
     */
    public BasicEventList() {
        this(LockFactory.DEFAULT.createReadWriteLock());
    }
    
    /**
     * Creates a {@link BasicEventList} that uses the specified {@link ReadWriteLock}
     * for concurrent access.
     */
    public BasicEventList(ReadWriteLock readWriteLock) {
        super(null);
        this.data = new ArrayList();
        this.readWriteLock = readWriteLock;
    }
    
    /**
     * Creates an empty {@link BasicEventList} with the given
     * <code>initialCapacity</code>.
     */
    public BasicEventList(int initalCapacity) {
        super(null);
        this.data = new ArrayList(initalCapacity);
        this.readWriteLock = LockFactory.DEFAULT.createReadWriteLock();
    }
    
    /**
     * Creates a {@link BasicEventList} that uses the specified {@link List} as
     * the underlying implementation.
     *
     * <p><strong><font color="#FF0000">Warning:</font></strong> all editing to
     * the specified {@link List} <strong>must</strong> be done through via this
     * {@link BasicEventList} interface. Otherwise this {@link BasicEventList} will
     * become out of sync and operations will fail.
     *
     * @deprecated As of 2005/03/06, this constructor has been declared unsafe
     *     because the source list is exposed. This allows it to be modified without
     *     the required events being fired. This constructor has been replaced by
     *     the factory method {@link GlazedLists#eventList(Collection)}.
     */
    public BasicEventList(List list) {
        super(null);
        this.data = list;
        this.readWriteLock = LockFactory.DEFAULT.createReadWriteLock();
    }
    
    /**
     * Creates a {@link BasicEventList} using the specified
     * {@link ListEventPublisher} and {@link ReadWriteLock}.
     *
     * @since 2006-June-12
     */
    public BasicEventList(ListEventPublisher publisher, ReadWriteLock readWriteLock) {
        super(publisher);
        this.data = new ArrayList();
        this.readWriteLock = readWriteLock;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void add(int index, Object element) {
        updates.beginEvent();
        updates.addInsert(index);
        data.add(index, element);
        updates.commitEvent();
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean add(Object element) {
        updates.beginEvent();
        updates.addInsert(size());
        boolean result = data.add(element);
        updates.commitEvent();
        return result;
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean addAll(Collection collection) {
        return addAll(size(), collection);
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean addAll(int index, Collection collection) {
        if (collection.size() == 0) return false;
        updates.beginEvent();
        updates.addInsert(index, index + collection.size() - 1);
        boolean result = data.addAll(index, collection);
        updates.commitEvent();
        return result;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object remove(int index) {
        updates.beginEvent();
        updates.addDelete(index);
        Object removed = data.remove(index);
        updates.commitEvent();
        return removed;
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean remove(Object element) {
        int index = data.indexOf(element);
        if (index == -1) return false;
        remove(index);
        return true;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void clear() {
        if (isEmpty()) return;
        updates.beginEvent();
        updates.addDelete(0, size() - 1);
        data.clear();
        updates.commitEvent();
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object set(int index, Object element) {
        updates.beginEvent();
        updates.addUpdate(index);
        Object previous = data.set(index, element);
        updates.commitEvent();
        return previous;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object get(int index) {
        return data.get(index);
    }
    
    /**
     * {@inheritDoc} 
     */
    public int size() {
        return data.size();
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean removeAll(Collection collection) {
        boolean changed = false;
        updates.beginEvent();
        for (Iterator i = collection.iterator(); i.hasNext(); ) {
            Object value = i.next();
            int index = -1;
            while ((index = indexOf(value)) != -1) {
                updates.addDelete(index);
                data.remove(index);
                changed = true;
            }
        }
        updates.commitEvent();
        return changed;
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean retainAll(Collection collection) {
        boolean changed = false;
        updates.beginEvent();
        int index = 0;
        while (index < data.size()) {
            if (collection.contains(data.get(index))) {
                index++;
            } else {
                updates.addDelete(index);
                data.remove(index);
                changed = true;
            }
        }
        updates.commitEvent();
        return changed;
    }
    
    /**
     * Although {@link EventList}s are not in general, {@link BasicEventList} is
     * {@link Serializable}. All of the {@link ListEventListener}s that are themselves
     * {@link Serializable} will be serialized, but others will not. Note that there
     * is <strong>no</strong> easy way to access the {@link ListEventListener}s of
     * an {@link EventList}, particularly after it has been serialized.
     *
     * <p>As of October 3, 2005, this is the wire format of serialized
     * {@link BasicEventList}s:
     * <li>An <code>Object[]</code> containing each of the list's elements
     * <li>A <code>ListEventListener[]</code> containing <strong>only</strong> the
     *     listeners that themselves implement {@link Serializable}. Those that
     *     do not will not be serialized. Note that {@link TransformedList}s
     *     such as {@link FilterList} are not {@link Serializable} and will not
     *     be serialized.
     */
    private void writeObject(ObjectOutputStream out) throws IOException {
        Object[] elements = (Object[])data.toArray(new Object[size()]);
        List serializableListeners = new ArrayList(1);
        for (Iterator i = updates.getListEventListeners().iterator(); i.hasNext(); ) {
            ListEventListener listener = (ListEventListener)i.next();
            if (!(listener instanceof Serializable)) continue;
            serializableListeners.add(listener);
        }
        ListEventListener[] listeners = (ListEventListener[])serializableListeners.toArray(new ListEventListener[serializableListeners.size()]);
        out.writeObject(elements);
        out.writeObject(listeners);
    }
    
    /**
     * Peer method to {@link #writeObject(ObjectOutputStream)}. Note that this
     * is functionally equivalent to a constructor and should validate that
     * everything is in place including locks, etc.
     */
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        this.readWriteLock = LockFactory.DEFAULT.createReadWriteLock();
        Object[] elements = (Object[])(Object[])in.readObject();
        ListEventListener[] listeners = (ListEventListener[])(ListEventListener[])in.readObject();
        this.data = new ArrayList();
        this.data.addAll(Arrays.asList(elements));
        for (int i = 0; i < listeners.length; i++) {
            this.updates.addListEventListener(listeners[i]);
        }
    }
}
