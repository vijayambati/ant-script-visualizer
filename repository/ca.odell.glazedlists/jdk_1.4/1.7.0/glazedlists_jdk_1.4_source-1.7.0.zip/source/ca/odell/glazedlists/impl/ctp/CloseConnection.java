package ca.odell.glazedlists.impl.ctp;

import ca.odell.glazedlists.impl.nio.*;
import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * Closes a connection on the NIO thread.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
class CloseConnection implements Runnable {
    
    /**
     * logging 
     */
    private static Logger logger = Logger.getLogger(CloseConnection.class.toString());
    
    /**
     * the target connection 
     */
    private CTPConnection connection;
    
    /**
     * the reason for the connection to be closed 
     */
    private Exception reason;
    
    /**
     * Creates a CTPConnectionToClose that closes the specified connection.
     */
    public CloseConnection(CTPConnection connection, Exception reason) {
        super();
        this.connection = connection;
        this.reason = reason;
    }
    
    /**
     * Runs this task.
     */
    public void run() {
        if (connection.state == CTPConnection.STATE_CLOSED_PERMANENTLY) return;
        if (reason == null || !(reason instanceof IOException)) {
            if (connection.state == CTPConnection.STATE_SERVER_AWAITING_REQUEST) {
                connection.state = CTPConnection.STATE_SERVER_CONSTRUCTING_RESPONSE;
                connection.sendResponse(CTPConnection.RESPONSE_ERROR, Collections.EMPTY_MAP);
            } else if (connection.state == CTPConnection.STATE_READY) {
                connection.sendChunk(null);
            }
        }
        try {
            connection.writer.writeToChannel(connection.socketChannel, connection.selectionKey);
        } catch (IOException e) {
        }
        if (connection.writer.length() > 0) logger.warning("Close proceeding with unsent data");
        try {
            connection.socketChannel.close();
            connection.selectionKey.cancel();
        } catch (IOException e) {
        }
        if (reason != null) {
            logger.log(Level.WARNING, "Closed connection to " + connection + " due to " + reason, reason);
        } else {
            logger.info("Closed connection to " + connection);
        }
        connection.state = CTPConnection.STATE_CLOSED_PERMANENTLY;
        connection.handler.connectionClosed(connection, reason);
    }
}
