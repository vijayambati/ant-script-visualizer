package ca.odell.glazedlists.util.concurrent;

/**
 * A ReadWriteLock that prefers waiting writers over
 * waiting readers when there is contention. This class
 * is adapted from the versions described in CPJ, improving
 * on the ones there a bit by segregating reader and writer
 * wait queues, which is typically more efficient.
 * <p>
 * The locks are <em>NOT</em> reentrant. In particular,
 * even though it may appear to usually work OK,
 * a thread holding a read lock should not attempt to
 * re-acquire it. Doing so risks lockouts when there are
 * also waiting writers.
 * <p>[<a href="http://gee.cs.oswego.edu/dl/classes/EDU/oswego/cs/dl/util/concurrent/intro.html"> Introduction to this package. </a>]
 */
class WriterPreferenceReadWriteLock implements ReadWriteLock {
    
    WriterPreferenceReadWriteLock() {
        super();
    }
    protected long activeReaders_ = 0;
    protected Thread activeWriter_ = null;
    protected long waitingReaders_ = 0;
    protected long waitingWriters_ = 0;
    protected final ReaderLock readerLock_ = new ReaderLock();
    protected final WriterLock writerLock_ = new WriterLock();
    
    public Lock writeLock() {
        return writerLock_;
    }
    
    public Lock readLock() {
        return readerLock_;
    }
    
    protected synchronized void cancelledWaitingReader() {
        --waitingReaders_;
    }
    
    protected synchronized void cancelledWaitingWriter() {
        --waitingWriters_;
    }
    
    /**
     * Override this method to change to reader preference 
     */
    protected boolean allowReader() {
        return activeWriter_ == null && waitingWriters_ == 0;
    }
    
    protected synchronized boolean startRead() {
        boolean allowRead = allowReader();
        if (allowRead) ++activeReaders_;
        return allowRead;
    }
    
    protected synchronized boolean startWrite() {
        boolean allowWrite = (activeWriter_ == null && activeReaders_ == 0);
        if (allowWrite) activeWriter_ = Thread.currentThread();
        return allowWrite;
    }
    
    protected synchronized boolean startReadFromNewReader() {
        boolean pass = startRead();
        if (!pass) ++waitingReaders_;
        return pass;
    }
    
    protected synchronized boolean startWriteFromNewWriter() {
        boolean pass = startWrite();
        if (!pass) ++waitingWriters_;
        return pass;
    }
    
    protected synchronized boolean startReadFromWaitingReader() {
        boolean pass = startRead();
        if (pass) --waitingReaders_;
        return pass;
    }
    
    protected synchronized boolean startWriteFromWaitingWriter() {
        boolean pass = startWrite();
        if (pass) --waitingWriters_;
        return pass;
    }
    
    /**
     * Called upon termination of a read.
     * Returns the object to signal to wake up a waiter, or null if no such
     */
    protected synchronized Signaller endRead() {
        if (--activeReaders_ == 0 && waitingWriters_ > 0) return writerLock_; else return null;
    }
    
    /**
     * Called upon termination of a write.
     * Returns the object to signal to wake up a waiter, or null if no such
     */
    protected synchronized Signaller endWrite() {
        activeWriter_ = null;
        if (waitingReaders_ > 0 && allowReader()) return readerLock_; else if (waitingWriters_ > 0) return writerLock_; else return null;
    }
    
    /**
     * Reader and Writer requests are maintained in two different
     * wait sets, by two different objects. These objects do not
     * know whether the wait sets need notification since they
     * don't know preference rules. So, each supports a
     * method that can be selected by main controlling object
     * to perform the notifications.  This base class simplifies mechanics.
     */
    protected abstract class Signaller {
        
        protected Signaller() {
            super();
        }
        
        abstract void signalWaiters();
    }
    
    protected class ReaderLock extends Signaller implements Lock {
        
        protected ReaderLock() {
            super();
        }
        
        public void lock() {
            InterruptedException ie = null;
            synchronized (this) {
                if (!startReadFromNewReader()) {
                    for (; ; ) {
                        try {
                            ReaderLock.this.wait();
                            if (startReadFromWaitingReader()) return;
                        } catch (InterruptedException ex) {
                            cancelledWaitingReader();
                            ie = ex;
                            break;
                        }
                    }
                }
            }
            if (ie != null) {
                writerLock_.signalWaiters();
                throw new RuntimeException("Lock interrupted, " + ie);
            }
        }
        
        public void unlock() {
            Signaller s = endRead();
            if (s != null) s.signalWaiters();
        }
        
        synchronized void signalWaiters() {
            ReaderLock.this.notifyAll();
        }
        
        public boolean tryLock() {
            long msecs = 0;
            InterruptedException ie = null;
            synchronized (this) {
                if (msecs <= 0) return startRead(); else if (startReadFromNewReader()) return true; else {
                    long waitTime = msecs;
                    long start = System.currentTimeMillis();
                    for (; ; ) {
                        try {
                            ReaderLock.this.wait(waitTime);
                        } catch (InterruptedException ex) {
                            cancelledWaitingReader();
                            ie = ex;
                            break;
                        }
                        if (startReadFromWaitingReader()) return true; else {
                            waitTime = msecs - (System.currentTimeMillis() - start);
                            if (waitTime <= 0) {
                                cancelledWaitingReader();
                                break;
                            }
                        }
                    }
                }
            }
            writerLock_.signalWaiters();
            if (ie != null) throw new RuntimeException("Lock interrupted, " + ie); else return false;
        }
    }
    
    protected class WriterLock extends Signaller implements Lock {
        
        protected WriterLock() {
            super();
        }
        
        public void lock() {
            InterruptedException ie = null;
            synchronized (this) {
                if (!startWriteFromNewWriter()) {
                    for (; ; ) {
                        try {
                            WriterLock.this.wait();
                            if (startWriteFromWaitingWriter()) return;
                        } catch (InterruptedException ex) {
                            cancelledWaitingWriter();
                            WriterLock.this.notify();
                            ie = ex;
                            break;
                        }
                    }
                }
            }
            if (ie != null) {
                readerLock_.signalWaiters();
                throw new RuntimeException("Lock interrupted, " + ie);
            }
        }
        
        public void unlock() {
            Signaller s = endWrite();
            if (s != null) s.signalWaiters();
        }
        
        synchronized void signalWaiters() {
            WriterLock.this.notify();
        }
        
        public boolean tryLock() {
            long msecs = 0;
            InterruptedException ie = null;
            synchronized (this) {
                if (msecs <= 0) return startWrite(); else if (startWriteFromNewWriter()) return true; else {
                    long waitTime = msecs;
                    long start = System.currentTimeMillis();
                    for (; ; ) {
                        try {
                            WriterLock.this.wait(waitTime);
                        } catch (InterruptedException ex) {
                            cancelledWaitingWriter();
                            WriterLock.this.notify();
                            ie = ex;
                            break;
                        }
                        if (startWriteFromWaitingWriter()) return true; else {
                            waitTime = msecs - (System.currentTimeMillis() - start);
                            if (waitTime <= 0) {
                                cancelledWaitingWriter();
                                WriterLock.this.notify();
                                break;
                            }
                        }
                    }
                }
            }
            readerLock_.signalWaiters();
            if (ie != null) throw new RuntimeException("Lock interrupted, " + ie); else return false;
        }
    }
}
