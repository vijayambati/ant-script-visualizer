package ca.odell.glazedlists.impl.filter;

import java.util.Arrays;

/**
 * This implementation of {@link TextSearchStrategy} implements a
 * simple version of the Boyer-Moore text searching algorithm, generally
 * considered to be the fastest known text searching algorithm.
 *
 * @author James Lemieux
 */
public class BoyerMooreCaseInsensitiveTextSearchStrategy implements TextSearchStrategy {
    
    public BoyerMooreCaseInsensitiveTextSearchStrategy() {
        super();
    }
    
    /**
     * The number of characters, starting at 0, to cache. 
     */
    private static final int CHARACTER_CACHE_SIZE = 256;
    
    /**
     * The length of the subtext to locate. 
     */
    private int subtextLength;
    
    /**
     * The last index in the subtext 
     */
    private int lastSubtextIndex;
    
    /**
     * The array of characters comprising the subtext. 
     */
    private char[] subtextCharsUpper;
    private char[] subtextCharsLower;
    
    /**
     * The Boyer-Moore shift table reduced to only 256 elements rather than all 95,221 Unicode 3.2 characters. 
     */
    private int[] shiftTable = new int[CHARACTER_CACHE_SIZE];
    
    /**
     * This method builds a shortened version of the Boyer-Moore shift table.
     * The shift table normally contains an entry for each letter in the
     * text search alphabet. Since this search strategy covers all valid
     * Unicode 3.2 characters, the shift table would normally contain 95,221
     * entries. US-ASCII comprises 99% of the alphabet used for most searched
     * messages, so we exploit this fact by reducing our shift table to just
     * 256 entries to save on initialization time. We convert each character to
     * its shift table index by modding it by 256. This creates the possibility
     * of shift table collisions since more than one Unicode character will map
     * to the same integer in the range [0..255]. Note however, that this only
     * causes the Boyer-Moore algorithm to run suboptimally, not incorrectly.
     * Since the number of collisions encountered is low in practice (based on
     * our assumption that 99% of the alphabet used for most search messages is
     * US-ASCII), it should have little effect on the execution time of
     * {@link #indexOf(String)}.
     *
     * @param subtext the String to locate in {@link #indexOf(String)}
     */
    public void setSubtext(String subtext) {
        this.subtextLength = subtext.length();
        this.lastSubtextIndex = this.subtextLength - 1;
        this.subtextCharsUpper = subtext.toUpperCase().toCharArray();
        this.subtextCharsLower = subtext.toLowerCase().toCharArray();
        Arrays.fill(this.shiftTable, 0, this.shiftTable.length, this.subtextLength);
        for (int i = 0; i < this.lastSubtextIndex; i++) {
            this.shiftTable[this.subtextCharsUpper[i] % CHARACTER_CACHE_SIZE] = this.lastSubtextIndex - i;
            if (this.subtextCharsUpper[i] != this.subtextCharsLower[i]) this.shiftTable[this.subtextCharsLower[i] % CHARACTER_CACHE_SIZE] = this.lastSubtextIndex - i;
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public int indexOf(String text) {
        if (this.subtextCharsUpper == null) {
            throw new IllegalStateException("setSubtext must be called with a valid value before this method can operate");
        }
        int textPosition = this.lastSubtextIndex;
        char textChar = ' ';
        int subtextPosition;
        final int textLength = text.length();
        while (textPosition < textLength) {
            subtextPosition = this.lastSubtextIndex;
            if (subtextPosition >= 0) {
                textChar = text.charAt(textPosition);
                while (subtextPosition >= 0 && (this.subtextCharsLower[subtextPosition] == textChar || this.subtextCharsUpper[subtextPosition] == textChar)) {
                    subtextPosition--;
                    textPosition--;
                    if (textPosition != -1) {
                        textChar = text.charAt(textPosition);
                    }
                }
            }
            if (subtextPosition == -1) {
                return textPosition + 1;
            }
            textPosition += Math.max(this.shiftTable[textChar % CHARACTER_CACHE_SIZE], this.subtextLength - subtextPosition);
        }
        return -1;
    }
}
