package ca.odell.glazedlists.impl.nio;

import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.io.*;
import java.util.logging.*;

/**
 * Handles incoming NIO connections.
 */
public interface NIOServer {
    
    /**
     * Handle an accept-ready selection key.
     */
    public void handleAccept(SelectionKey selectionKey, Selector selector);
}
