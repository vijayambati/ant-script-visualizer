package ca.odell.glazedlists.impl;

import java.util.*;
import ca.odell.glazedlists.*;
import ca.odell.glazedlists.event.*;

/**
 * An {@link EventList} that does not allow writing operations.
 *
 * <p>The {@link ReadOnlyList} is useful for programming defensively. A
 * {@link ReadOnlyList} is useful to supply an unknown class read-only access
 * to your {@link EventList}. 
 *
 * <p>The {@link ReadOnlyList} provides an up-to-date view of its source
 * {@link EventList} so changes to the source {@link EventList} will still be
 * reflected. For a static copy of any {@link EventList} it is necessary to copy
 * the contents of that {@link EventList} into any {@link List}.
 *
 * <p>{@link ReadOnlyList} does not alter the runtime performance
 * characteristics of the source {@link EventList}.
 *
 * <p><strong><font color="#FF0000">Warning:</font></strong> This class is
 * thread ready but not thread safe. See {@link EventList} for an example
 * of thread safe code.
 *
 * @see TransformedList
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class ReadOnlyList extends TransformedList {
    
    /**
     * Creates a {@link ReadOnlyList} to provide a view of an {@link EventList}
     * that does not allow write operations.
     */
    public ReadOnlyList(EventList source) {
        super(source);
        source.addListEventListener(this);
    }
    
    /**
     * {@inheritDoc} 
     */
    public void listChanged(ListEvent listChanges) {
        updates.forwardEvent(listChanges);
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean contains(Object object) {
        return source.contains(object);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object[] toArray() {
        return source.toArray();
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object[] toArray(Object[] array) {
        return source.toArray(array);
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean containsAll(Collection values) {
        return source.containsAll(values);
    }
    
    /**
     * {@inheritDoc} 
     */
    public int indexOf(Object object) {
        return source.indexOf(object);
    }
    
    /**
     * {@inheritDoc} 
     */
    public int lastIndexOf(Object object) {
        return source.lastIndexOf(object);
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean equals(Object object) {
        return source.equals(object);
    }
    
    /**
     * {@inheritDoc} 
     */
    public int hashCode() {
        return source.hashCode();
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean add(Object value) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public void add(int index, Object value) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean addAll(Collection values) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean addAll(int index, Collection values) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public void clear() {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean remove(Object toRemove) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public Object remove(int index) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public boolean retainAll(Collection values) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
    
    /**
     * @throws UnsupportedOperationException since ReadOnlyList cannot be modified 
     */
    public Object set(int index, Object value) {
        throw new UnsupportedOperationException("ReadOnlyList cannot be modified");
    }
}
