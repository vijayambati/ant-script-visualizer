package ca.odell.glazedlists.impl;

import java.util.*;

/**
 * The SimpleTreeIterator is an iterator that allows the user to iterate
 * on a list.
 *
 * @author <a href="mailto:kevin@swank.ca">Kevin Maltby</a>
 */
public class SimpleIterator implements Iterator {
    
    /**
     * the list being iterated 
     */
    private final List source;
    
    /**
     * the index of the next element to view 
     */
    private int nextIndex = 0;
    
    /**
     * Create a new iterator that iterates over the specified source list.
     *
     * @param source the list to iterate
     */
    public SimpleIterator(List source) {
        super();
        this.source = source;
    }
    
    /**
     * Returns true if this iterator has more elements when traversing the
     * list in the forward direction.
     */
    public boolean hasNext() {
        return nextIndex < source.size();
    }
    
    /**
     * Returns the next element in the list.
     */
    public Object next() {
        if (nextIndex == source.size()) throw new NoSuchElementException("Cannot retrieve element " + nextIndex + " on a list of size " + source.size());
        return source.get(nextIndex++);
    }
    
    /**
     * Removes from the list the last element that was returned by next
     * or previous.
     */
    public void remove() {
        if (nextIndex == 0) throw new IllegalStateException("Cannot remove() without a prior call to next() or previous()");
        source.remove(--nextIndex);
    }
}
