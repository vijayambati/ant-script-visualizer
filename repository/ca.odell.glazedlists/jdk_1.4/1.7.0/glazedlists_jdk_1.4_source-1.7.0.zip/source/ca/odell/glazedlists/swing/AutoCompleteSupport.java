package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.*;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.impl.GlazedListsImpl;
import ca.odell.glazedlists.impl.swing.ComboBoxPopupLocationFix;
import ca.odell.glazedlists.impl.filter.TextMatcher;
import ca.odell.glazedlists.matchers.Matcher;
import ca.odell.glazedlists.matchers.Matchers;
import ca.odell.glazedlists.matchers.TextMatcherEditor;
import javax.swing.*;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.ComboPopup;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.Method;
import java.text.Format;
import java.text.ParsePosition;
import java.util.*;
import java.util.List;

/**
 * This class {@link #install}s support for filtering and autocompletion into
 * a standard {@link JComboBox}. It also acts as a factory class for
 * {@link #createTableCellEditor creating autocompleting table cell editors}.
 *
 * <p>All autocompletion behaviour provided is meant to mimic the functionality
 * of the Firefox address field. To be explicit, the following is a list of
 * expected behaviours which are installed:
 *
 * <p><strong>Typing into the ComboBox Editor</strong>
 * <ol>
 *   <li> typing any value into the editor when the popup is invisible causes
 *        the popup to appear and its contents to be filtered according to the
 *        editor's text. It also autocompletes to the first item that is
 *        prefixed with the editor's text and selects that item within the popup.
 *   <li> typing any value into the editor when the popup is visible causes
 *        the popup to be refiltered according to the editor's text and
 *        reselects an appropriate autocompletion item
 *   <li> typing the down or up arrow keys in the editor when the popup is
 *        invisible causes the popup to appear and its contents to be filtered
 *        according to the editor's text. It also autocompletes to the first
 *        item that is prefixed with the editor's text and selects that item
 *        within the popup.
 *   <li> typing the up arrow key when the popup is visible and the selected
 *        element is the first element causes the autocompletion to be cleared
 *        and the popup's selection to be removed
 *   <li> typing the up arrow key when no selection exists causes the last
 *        element of the popup to become selected and used for autocompletion
 *   <li> typing the down arrow key when the popup is visible and the selected
 *        element is the last element causes the autocompletion to be cleared
 *        and the popup's selection to be removed
 *   <li> typing the down arrow key when no selection exists causes the first
 *        element of the popup to become selected and used for autocompletion
 * </ol>
 *
 * <strong>Clicking on the Arrow Button</strong>
 * <ol>
 *   <li> clicking the arrow button when the popup is invisible causes the
 *        popup to appear and its contents to be shown unfiltered
 *   <li> clicking the arrow button when the popup is visible causes the popup
 *        to be hidden
 * </ol>
 *
 * <strong>Sizing the ComboBox Popup</strong>
 * <ol>
 *   <li> the popup is always <strong>at least</strong> as wide as the
 *        autocompleting {@link JComboBox}, but may be wider to accomodate a
 *        {@link JComboBox#getPrototypeDisplayValue() prototype display value}
 *        if a non-null prototype display value exists
 *   <li> as items are filtered in the ComboBoxModel, the popup height is
 *        adjusted to display between 0 and {@link JComboBox#getMaximumRowCount()}
 *        rows before scrolling the popup
 * </ol>
 *
 * <strong>JComboBox ActionEvents</strong>
 * <p>A single {@link ActionEvent} is fired from the JComboBox in these situations:
 * <ol>
 *   <li> the user hits the enter key
 *   <li> the selected item within the popup is changed (which can happen due
 *        to a mouse click, a change in the autocompletion term, or using the
 *        arrow keys)
 *   <li> the JComboBox loses focus and contains a value that does not appear
 *        in the ComboBoxModel
 * </ol>
 *
 * <strong>Null Values in the ComboBoxModel</strong>
 * <p><code>null</code> values located in the ComboBoxModel are considered
 * identical to empty Strings ("") for the purposes of locating autocompletion
 * terms.<br><br></p>
 *
 * <strong>ComboBoxEditor Focus</strong>
 * <p>When the ComboBoxEditor gains focus it selects the text it contains if
 * {@link #getSelectsTextOnFocusGain()} returns <tt>true</tt>; otherwise it
 * does nothing.<br><br></p>
 *
 * <strong>Extracting String Values</strong>
 * <p>Each value in the ComboBoxModel must be converted to a String for many
 * reasons: filtering, setting into the ComboBoxEditor, displaying in the
 * renderer, etc. By default, JComboBox relies on {@link Object#toString()}
 * to map elements to their String equivalents. Sometimes, however, toString()
 * is not a reliable or desirable mechanism to use. To deal with this problem,
 * AutoCompleteSupport provides an install method that takes a {@link Format}
 * object which is used to do all converting back and forth between Strings and
 * ComboBoxModel objects.</p>
 *
 * <p>In order to achieve all of the autocompletion and filtering behaviour,
 * the following occurs when {@link #install} is called:
 *
 * <ul>
 *   <li> the JComboBox will be made editable
 *   <li> the JComboBox will have a custom ComboBoxModel installed on it
 *        containing the given items
 *   <li> the ComboBoxEditor will be wrapped with functionality and set back
 *        into the JComboBox as the editor
 *   <li> the JTextField which is the editor component for the JComboBox
 *        will have a DocumentFilter installed on its backing Document
 * </ul>
 *
 * The strategy of this support class is to alter all of the objects which
 * influence the behaviour of the JComboBox in one single context. With that
 * achieved, it greatly reduces the cross-functional communication required to
 * customize the behaviour of JComboBox for filtering and autocompletion.
 *
 * <p><strong><font color="#FF0000">Warning:</font></strong> This class must be
 * mutated from the Swing Event Dispatch Thread. Failure to do so will result in
 * an {@link IllegalStateException} thrown from any one of:
 *
 * <ul>
 *   <li> {@link #install(JComboBox, EventList)}
 *   <li> {@link #install(JComboBox, EventList, TextFilterator)}
 *   <li> {@link #install(JComboBox, EventList, TextFilterator, Format)}
 *   <li> {@link #uninstall()}
 *   <li> {@link #setCorrectsCase(boolean)}
 *   <li> {@link #setStrict(boolean)}
 *   <li> {@link #setSelectsTextOnFocusGain(boolean)}
 *   <li> {@link #setFilterMode(int)}
 * </ul>
 *
 * @author James Lemieux
 */
public final class AutoCompleteSupport {
    private static final ParsePosition PARSE_POSITION = new ParsePosition(0);
    private static final Class[] VALUE_OF_SIGNATURE = {String.class};
    
    /**
     * <tt>true</tt> if user-specified text is converted into the same case as
     * the autocompletion term. <tt>false</tt> will leave user specified text
     * unaltered.
     */
    private boolean correctsCase = true;
    
    /**
     * <tt>true</tt> if the user can specify values that do not appear in the
     * ComboBoxModel; <tt>false</tt> otherwise.
     */
    private boolean strict = false;
    
    /**
     * <tt>true</tt> if the text in the combobox editor is selected when the
     * editor gains focus; <tt>false</tt> otherwise.
     */
    private boolean selectsTextOnFocusGain = true;
    
    /**
     * The comboBox being decorated with autocomplete functionality. 
     */
    private JComboBox comboBox;
    
    /**
     * The popup menu of the decorated comboBox. 
     */
    private JPopupMenu popupMenu;
    
    /**
     * The popup that wraps the popupMenu of the decorated comboBox. 
     */
    private ComboPopup popup;
    
    /**
     * The arrow button that invokes the popup. 
     */
    protected JButton arrowButton;
    
    /**
     * The model backing the comboBox. 
     */
    private final AutoCompleteComboBoxModel comboBoxModel;
    
    /**
     * The custom renderer installed on the comboBox or <code>null</code> if one is not required. 
     */
    private final ListCellRenderer renderer;
    
    /**
     * The EventList which holds the items present in the comboBoxModel. 
     */
    private final EventList items;
    
    /**
     * The FilterList which filters the items present in the comboBoxModel. 
     */
    private final FilterList filteredItems;
    
    /**
     * The Format capable of producing Strings from ComboBoxModel elements and vice versa. 
     */
    private final Format format;
    
    /**
     * The MatcherEditor driving the FilterList behind the comboBoxModel. 
     */
    private final TextMatcherEditor filterMatcherEditor;
    
    /**
     * The custom ComboBoxEditor that does NOT assume that the text value can
     * be computed using Object.toString(). (i.e. the default ComboBoxEditor
     * *does* assume that, but we decorate it and remove that assumption)
     */
    private FormatComboBoxEditor comboBoxEditor;
    
    /**
     * The textfield which acts as the editor of the comboBox. 
     */
    private JTextField comboBoxEditorComponent;
    
    /**
     * The Document backing the comboBoxEditorComponent. 
     */
    private AbstractDocument document;
    
    /**
     * A DocumentFilter that controls edits to the document. 
     */
    private final AutoCompleteFilter documentFilter = new AutoCompleteFilter();
    
    /**
     * The last prefix specified by the user. 
     */
    private String prefix = "";
    
    /**
     * The Matcher that decides if a ComboBoxModel element is filtered out. 
     */
    private Matcher filterMatcher = Matchers.trueMatcher();
    
    /**
     * Controls the selection behavior of the JComboBox when it is used in a JTable DefaultCellEditor. 
     */
    private boolean isTableCellEditor;
    
    /**
     * The MouseListener which is installed on the {@link #arrowButton} and
     * is responsible for clearing the filter and then showing / hiding the
     * {@link #popup}.
     */
    private ArrowButtonMouseListener arrowButtonMouseListener;
    
    /**
     * A listener which reacts to changes in the ComboBoxModel by
     * resizing the popup appropriately to accomodate the new data.
     */
    private final ListDataListener listDataHandler = new ListDataHandler();
    
    /**
     * We ensure the popup menu is sized correctly each time it is shown.
     * Namely, we respect the prototype display value of the combo box, if
     * it has one. Regardless of the width of the combo box, we attempt to
     * size the popup to accomodate the width of the prototype display value.
     */
    private final PopupMenuListener popupSizerHandler = new PopupSizer();
    
    /**
     * An unfortunately necessary fixer for a misplaced popup.
     */
    private ComboBoxPopupLocationFix popupLocationFix;
    
    /**
     * We ensure that selecting an item from the popup via the mouse never
     * attempts to autocomplete for fear that we will replace the user's
     * newly selected item and the item will effectively be unselectable.
     */
    private final MouseListener popupMouseHandler = new PopupMouseHandler();
    
    /**
     * Handles the special case of the backspace key in strict mode and the enter key. 
     */
    private final KeyListener strictModeBackspaceHandler = new AutoCompleteKeyHandler();
    
    /**
     * Handles selecting the text in the comboBoxEditorComponent when it gains focus. 
     */
    private final FocusListener selectTextOnFocusGainHandler = new SelectTextOnFocusGainHandler();
    
    /**
     * Watches for changes of the Document which backs comboBoxEditorComponent and uninstalls
     * our DocumentFilter from the old Document and reinstalls it on the new.
     */
    private final DocumentWatcher documentWatcher = new DocumentWatcher();
    
    /**
     * Watches for changes of the ComboBoxModel and reports them as violations. 
     */
    private final ModelWatcher modelWatcher = new ModelWatcher();
    
    /**
     * Watches for changes of the ComboBoxUI and reinstalls the autocompletion support. 
     */
    private final UIWatcher uiWatcher = new UIWatcher();
    
    /**
     * <tt>true</tt> indicates document changes should not be post processed
     * (i.e. just commit changes to the Document and do not cause any side-effects). 
     */
    private boolean doNotPostProcessDocumentChanges = false;
    
    /**
     * <tt>true</tt> indicates attempts to filter the ComboBoxModel should be ignored. 
     */
    private boolean doNotFilter = false;
    
    /**
     * <tt>true</tt> indicates attempts to change the document should be ignored. 
     */
    private boolean doNotChangeDocument = false;
    
    /**
     * <tt>true</tt> indicates attempts to select an autocompletion term should be ignored. 
     */
    private boolean doNotAutoComplete = false;
    
    /**
     * <tt>true</tt> indicates attempts to toggle the state of the popup should be ignored.
     * In general, the only time we should toggle the state of a popup is due to a users keystroke
     * (and not programmatically setting the selected item, for example). 
     */
    private boolean doNotTogglePopup = true;
    
    /**
     * <tt>true</tt> indicates attempts to clear the filter when hiding the popup should be ignored.
     * This is because sometimes we hide and reshow a popup in rapid succession and we want to avoid
     * the work to unfiltering/refiltering it.
     */
    private boolean doNotClearFilterOnPopupHide = false;
    
    /**
     * The original setting of the editable field on the comboBox. 
     */
    private final boolean originalComboBoxEditable;
    
    /**
     * The original model installed on the comboBox. 
     */
    private ComboBoxModel originalModel;
    
    /**
     * The original ListCellRenderer installed on the comboBox. 
     */
    private ListCellRenderer originalRenderer;
    
    /**
     * The original Actions associated with the up and down arrow keys. 
     */
    private Action originalSelectNextAction;
    private Action originalSelectPreviousAction;
    private Action originalSelectNext2Action;
    private Action originalSelectPrevious2Action;
    private Action originalAquaSelectNextAction;
    private Action originalAquaSelectPreviousAction;
    
    /**
     * This private constructor creates an AutoCompleteSupport object which adds
     * autocompletion functionality to the given <code>comboBox</code>. In
     * particular, a custom {@link ComboBoxModel} is installed behind the
     * <code>comboBox</code> containing the given <code>items</code>. The
     * <code>filterator</code> is consulted in order to extract searchable
     * text from each of the <code>items</code>. Non-null <code>format</code>
     * objects are used to convert ComboBoxModel elements to Strings and back
     * again for various functions like filtering, editing, and rendering.
     *
     * @param comboBox the {@link JComboBox} to decorate with autocompletion
     * @param items the objects to display in the <code>comboBox</code>
     * @param filterator extracts searchable text strings from each item
     * @param format converts combobox elements into strings and vice versa
     */
    private AutoCompleteSupport(JComboBox comboBox, EventList items, TextFilterator filterator, Format format) {
        super();
        this.comboBox = comboBox;
        this.originalComboBoxEditable = comboBox.isEditable();
        this.originalModel = comboBox.getModel();
        this.items = items;
        this.format = format;
        final boolean defaultRendererInstalled = comboBox.getEditor() instanceof UIResource;
        this.renderer = format == null && defaultRendererInstalled ? null : new StringFunctionRenderer();
        this.isTableCellEditor = Boolean.TRUE.equals(comboBox.getClientProperty("JComboBox.isTableCellEditor"));
        this.filterMatcherEditor = new TextMatcherEditor(filterator == null ? new DefaultTextFilterator() : filterator);
        this.filterMatcherEditor.setMode(TextMatcherEditor.STARTS_WITH);
        this.filteredItems = new FilterList(items, this.filterMatcherEditor);
        this.comboBoxModel = new AutoCompleteComboBoxModel(this.filteredItems);
        this.comboBox.setModel(this.comboBoxModel);
        this.comboBox.setEditable(true);
        decorateCurrentUI();
        this.comboBox.addPropertyChangeListener("UI", this.uiWatcher);
        this.comboBox.addPropertyChangeListener("model", this.modelWatcher);
        this.comboBoxEditorComponent.addPropertyChangeListener("document", this.documentWatcher);
    }
    
    /**
     * A convenience method to ensure {@link AutoCompleteSupport} is being
     * accessed from the Event Dispatch Thread.
     */
    private static void checkAccessThread() {
        if (!SwingUtilities.isEventDispatchThread()) throw new IllegalStateException("AutoCompleteSupport must be accessed from the Swing Event Dispatch Thread, but was called on Thread \"" + Thread.currentThread().getName() + "\"");
    }
    
    /**
     * A convenience method to unregister and return all {@link ActionListener}s
     * currently installed on the given <code>comboBox</code>. This is the only
     * technique we can rely on to prevent the <code>comboBox</code> from
     * broadcasting {@link ActionEvent}s at inappropriate times.
     *
     * This method is the logical inverse of {@link #registerAllActionListeners}.
     */
    private static ActionListener[] unregisterAllActionListeners(JComboBox comboBox) {
        final ActionListener[] listeners = comboBox.getActionListeners();
        for (int i = 0; i < listeners.length; i++) comboBox.removeActionListener(listeners[i]);
        return listeners;
    }
    
    /**
     * A convenience method to register all of the given <code>listeners</code>
     * with the given <code>comboBox</code>.
     *
     * This method is the logical inverse of {@link #unregisterAllActionListeners}.
     */
    private static void registerAllActionListeners(JComboBox comboBox, ActionListener[] listeners) {
        for (int i = 0; i < listeners.length; i++) comboBox.addActionListener(listeners[i]);
    }
    
    /**
     * A convenience method to search through the given JComboBox for the
     * JButton which toggles the popup up open and closed.
     */
    private static JButton findArrowButton(JComboBox c) {
        for (int i = 0, n = c.getComponentCount(); i < n; i++) {
            final Component comp = c.getComponent(i);
            if (comp instanceof JButton) return (JButton)(JButton)comp;
        }
        return null;
    }
    
    /**
     * Decorate all necessary areas of the current UI to install autocompletion
     * support. This method is called in the constructor and when the comboBox's
     * UI delegate is changed.
     */
    private void decorateCurrentUI() {
        this.originalRenderer = comboBox.getRenderer();
        this.popupMenu = (JPopupMenu)(JPopupMenu)comboBox.getUI().getAccessibleChild(comboBox, 0);
        this.popup = (ComboPopup)(ComboPopup)popupMenu;
        this.arrowButton = findArrowButton(comboBox);
        if (this.arrowButton != null) {
            this.arrowButton.removeMouseListener(popup.getMouseListener());
            this.arrowButtonMouseListener = new ArrowButtonMouseListener(popup.getMouseListener());
            this.arrowButton.addMouseListener(arrowButtonMouseListener);
        }
        this.comboBox.getModel().addListDataListener(listDataHandler);
        this.popupMenu.addPopupMenuListener(popupSizerHandler);
        this.popupLocationFix = ComboBoxPopupLocationFix.install(this.comboBox);
        this.popup.getList().addMouseListener(popupMouseHandler);
        final ActionMap actionMap = comboBox.getActionMap();
        this.originalSelectNextAction = actionMap.get("selectNext");
        this.originalSelectPreviousAction = actionMap.get("selectPrevious");
        this.originalSelectNext2Action = actionMap.get("selectNext2");
        this.originalSelectPrevious2Action = actionMap.get("selectPrevious2");
        this.originalAquaSelectNextAction = actionMap.get("aquaSelectNext");
        this.originalAquaSelectPreviousAction = actionMap.get("aquaSelectPrevious");
        final Action upAction = new MoveAction(-1);
        final Action downAction = new MoveAction(1);
        actionMap.put("selectPrevious", upAction);
        actionMap.put("selectNext", downAction);
        actionMap.put("selectPrevious2", upAction);
        actionMap.put("selectNext2", downAction);
        actionMap.put("aquaSelectPrevious", upAction);
        actionMap.put("aquaSelectNext", downAction);
        this.comboBoxEditor = new FormatComboBoxEditor(comboBox.getEditor());
        this.comboBox.setEditor(comboBoxEditor);
        this.comboBoxEditorComponent = (JTextField)(JTextField)comboBox.getEditor().getEditorComponent();
        this.document = (AbstractDocument)(AbstractDocument)comboBoxEditorComponent.getDocument();
        this.document.setDocumentFilter(documentFilter);
        if (this.renderer != null) comboBox.setRenderer(renderer);
        this.comboBoxEditorComponent.addKeyListener(strictModeBackspaceHandler);
        this.comboBoxEditorComponent.addFocusListener(selectTextOnFocusGainHandler);
    }
    
    /**
     * Remove all customizations installed to various areas of the current UI
     * in order to uninstall autocompletion support. This method is invoked
     * after the comboBox's UI delegate is changed.
     */
    private void undecorateOriginalUI() {
        if (this.arrowButton != null) {
            this.arrowButton.removeMouseListener(arrowButtonMouseListener);
            this.arrowButton.addMouseListener(arrowButtonMouseListener.getDecorated());
        }
        this.comboBox.getModel().removeListDataListener(listDataHandler);
        if (this.comboBox.getEditor() == comboBoxEditor) this.comboBox.setEditor(comboBoxEditor.getDelegate());
        this.popupMenu.removePopupMenuListener(popupSizerHandler);
        this.popupLocationFix.uninstall();
        this.popup.getList().removeMouseListener(popupMouseHandler);
        final ActionMap actionMap = comboBox.getActionMap();
        actionMap.put("selectPrevious", originalSelectPreviousAction);
        actionMap.put("selectNext", originalSelectNextAction);
        actionMap.put("selectPrevious2", originalSelectPrevious2Action);
        actionMap.put("selectNext2", originalSelectNext2Action);
        actionMap.put("aquaSelectPrevious", originalAquaSelectPreviousAction);
        actionMap.put("aquaSelectNext", originalAquaSelectNextAction);
        this.document.setDocumentFilter(null);
        this.comboBoxEditorComponent.removeKeyListener(strictModeBackspaceHandler);
        this.comboBoxEditorComponent.removeFocusListener(selectTextOnFocusGainHandler);
        if (this.comboBox.getRenderer() == renderer) this.comboBox.setRenderer(originalRenderer);
        this.originalRenderer = null;
        this.comboBoxEditor = null;
        this.comboBoxEditorComponent = null;
        this.document = null;
        this.popupMenu = null;
        this.popup = null;
        this.arrowButton = null;
    }
    
    /**
     * Installs support for autocompletion into the <code>comboBox</code> and
     * returns the support object that is actually providing those facilities.
     * The support object is returned so that the caller may invoke
     * {@link #uninstall} at some later time to remove the autocompletion
     * features.
     *
     * <p>This method assumes that the <code>items</code> can be converted into
     * reasonable String representations via {@link Object#toString()}.
     *
     * <p>The following must be true in order to successfully install support
     * for autocompletion on a {@link JComboBox}:
     *
     * <ul>
     *   <li> The JComboBox must use a {@link JTextField} as its editor component
     *   <li> The JTextField must use an {@link AbstractDocument} as its model
     * </ul>
     *
     * @param comboBox the {@link JComboBox} to decorate with autocompletion
     * @param items the objects to display in the <code>comboBox</code>
     * @return an instance of the support class providing autocomplete features
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public static AutoCompleteSupport install(JComboBox comboBox, EventList items) {
        return install(comboBox, items, null);
    }
    
    /**
     * Installs support for autocompletion into the <code>comboBox</code> and
     * returns the support object that is actually providing those facilities.
     * The support object is returned so that the caller may invoke
     * {@link #uninstall} at some later time to remove the autocompletion
     * features.
     *
     * <p>This method assumes that the <code>items</code> can be converted into
     * reasonable String representations via {@link Object#toString()}.
     *
     * <p>The <code>filterator</code> will be used to extract searchable text
     * strings from each of the <code>items</code>. A <code>null</code>
     * filterator implies the item's toString() method should be used when
     * filtering it.
     *
     * <p>The following must be true in order to successfully install support
     * for autocompletion on a {@link JComboBox}:
     *
     * <ul>
     *   <li> The JComboBox must use a {@link JTextField} as its editor component
     *   <li> The JTextField must use an {@link AbstractDocument} as its model
     * </ul>
     *
     * @param comboBox the {@link JComboBox} to decorate with autocompletion
     * @param items the objects to display in the <code>comboBox</code>
     * @param filterator extracts searchable text strings from each item;
     *      <code>null</code> implies the item's toString() method should be
     *      used when filtering it
     * @return an instance of the support class providing autocomplete features
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public static AutoCompleteSupport install(JComboBox comboBox, EventList items, TextFilterator filterator) {
        return install(comboBox, items, filterator, null);
    }
    
    /**
     * Installs support for autocompletion into the <code>comboBox</code> and
     * returns the support object that is actually providing those facilities.
     * The support object is returned so that the caller may invoke
     * {@link #uninstall} at some later time to remove the autocompletion
     * features.
     *
     * <p>This method uses the given <code>format</code> to convert the
     * given <code>items</code> into Strings and back again. In other words,
     * this method does <strong>NOT</strong> rely on {@link Object#toString()}
     * to produce a reasonable String representation of each item. Likewise,
     * it does not rely on the existence of a valueOf(String) method for
     * creating items out of Strings as is the default behaviour of JComboBox.
     *
     * <p>It can be assumed that the only methods called on the given <code>format</code> are:
     * <ul>
     *   <li>{@link Format#format(Object)}
     *   <li>{@link Format#parseObject(String, ParsePosition)}
     * </ul>
     *
     * <p>As a convenience, this method will install a custom
     * {@link ListCellRenderer} on the <code>comboBox</code> that displays the
     * String value returned by the <code>format</code>. Though this is only
     * done if the given <code>format</code> is not <code>null</code> and if
     * the <code>comboBox</code> does not already use a custom renderer.
     *
     * <p>The <code>filterator</code> will be used to extract searchable text
     * strings from each of the <code>items</code>. A <code>null</code>
     * filterator implies one of two default strategies will be used. If the
     * <code>format</code> is not null then the String value returned from the
     * <code>format</code> object will be used when filtering a given item.
     * Otherwise, the item's toString() method will be used when it is filtered.
     *
     * <p>The following must be true in order to successfully install support
     * for autocompletion on a {@link JComboBox}:
     *
     * <ul>
     *   <li> The JComboBox must use a {@link JTextField} as its editor component
     *   <li> The JTextField must use an {@link AbstractDocument} as its model
     * </ul>
     *
     * @param comboBox the {@link JComboBox} to decorate with autocompletion
     * @param items the objects to display in the <code>comboBox</code>
     * @param filterator extracts searchable text strings from each item. If the
     *      <code>format</code> is not null then the String value returned from
     *      the <code>format</code> object will be used when filtering a given
     *      item. Otherwise, the item's toString() method will be used when it
     *      is filtered.
     * @param format a Format object capable of converting <code>items</code>
     *      into Strings and back. <code>null</code> indicates the standard
     *      JComboBox methods of converting are acceptable.
     * @return an instance of the support class providing autocomplete features
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public static AutoCompleteSupport install(JComboBox comboBox, EventList items, TextFilterator filterator, Format format) {
        checkAccessThread();
        final Component editorComponent = comboBox.getEditor().getEditorComponent();
        if (!(editorComponent instanceof JTextField)) throw new IllegalArgumentException("comboBox must use a JTextField as its editor component");
        if (!(((JTextField)(JTextField)editorComponent).getDocument() instanceof AbstractDocument)) throw new IllegalArgumentException("comboBox must use a JTextField backed by an AbstractDocument as its editor component");
        if (comboBox.getModel().getClass() == AutoCompleteSupport.AutoCompleteComboBoxModel.class) throw new IllegalArgumentException("comboBox is already configured for autocompletion");
        return new AutoCompleteSupport(comboBox, items, filterator, format);
    }
    
    /**
     * This method is used to report environmental invariants which are
     * violated when the user adjusts the combo box in a way that is
     * incompatible with the requirements for autocompletion. A message can be
     * specified which will be included in the {@link IllegalStateException}
     * that is throw out of this method after the autocompletion support is
     * uninstalled.
     *
     * @param message a message to the programmer explaining the environmental
     *      invariant that was violated
     */
    private void throwIllegalStateException(String message) {
        final String exceptionMsg = message + "\n" + "In order for AutoCompleteSupport to continue to " + "work, the following invariants must be maintained after " + "AutoCompleteSupport.install() has been called:\n" + "* the ComboBoxModel may not be removed\n" + "* the AbstractDocument behind the JTextField can be changed but must be changed to some subclass of AbstractDocument\n" + "* the DocumentFilter on the AbstractDocument behind the JTextField may not be removed\n";
        uninstall();
        throw new IllegalStateException(exceptionMsg);
    }
    
    /**
     * A convenience method to produce a String from the given
     * <code>comboBoxElement</code>.
     */
    private String convertToString(Object comboBoxElement) {
        if (format != null) return format.format(comboBoxElement);
        return comboBoxElement == null ? "" : comboBoxElement.toString();
    }
    
    /**
     * Returns the autocompleting {@link JComboBox} or <code>null</code> if
     * {@link AutoCompleteSupport} has been {@link #uninstall}ed.
     */
    public JComboBox getComboBox() {
        return this.comboBox;
    }
    
    /**
     * Returns the {@link TextFilterator} that extracts searchable strings from
     * each item in the {@link ComboBoxModel}.
     */
    public TextFilterator getTextFilterator() {
        return this.filterMatcherEditor.getFilterator();
    }
    
    /**
     * Returns the filtered {@link EventList} of items which backs the
     * {@link ComboBoxModel} of the autocompleting {@link JComboBox}.
     */
    public EventList getItemList() {
        return this.filteredItems;
    }
    
    /**
     * Returns <tt>true</tt> if user specified strings are converted to the
     * case of the autocompletion term they match; <tt>false</tt> otherwise.
     */
    public boolean getCorrectsCase() {
        return correctsCase;
    }
    
    /**
     * If <code>correctCase</code> is <tt>true</tt>, user specified strings
     * will be converted to the case of the element they match. Otherwise
     * they will be left unaltered.
     *
     * <p>Note: this flag only has meeting when strict mode is turned off.
     * When strict mode is on, case is corrected regardless of this setting.
     *
     * @see #setStrict(boolean)
     *
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public void setCorrectsCase(boolean correctCase) {
        checkAccessThread();
        this.correctsCase = correctCase;
    }
    
    /**
     * Returns <tt>true</tt> if the user is able to specify values which do not
     * appear in the popup list of suggestions; <tt>false</tt> otherwise.
     */
    public boolean isStrict() {
        return strict;
    }
    
    /**
     * If <code>strict</code> is <tt>true</tt>, the user can specify values not
     * appearing within the ComboBoxModel. If it is <tt>false</tt> each
     * keystroke must continue to match some value in the ComboBoxModel or it
     * will be discarded.
     *
     * <p>Note: When strict mode is enabled, all user input is corrected to the
     * case of the autocompletion term, regardless of the correctsCase setting.
     *
     * @see #setCorrectsCase(boolean)
     *
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public void setStrict(boolean strict) {
        checkAccessThread();
        if (this.strict == strict) return;
        this.strict = strict;
        if (strict) {
            final String value = comboBoxEditorComponent.getText();
            String strictValue = findAutoCompleteTerm(value);
            if (value.equals(strictValue)) return;
            if (strictValue == null && !items.isEmpty()) strictValue = convertToString(items.get(0));
            applyFilter("");
            doNotFilter = true;
            try {
                comboBoxEditorComponent.setText(strictValue);
            } finally {
                doNotFilter = false;
            }
        }
    }
    
    /**
     * Returns <tt>true</tt> if the combo box editor text is selected when it
     * gains focus; <tt>false</tt> otherwise.
     */
    public boolean getSelectsTextOnFocusGain() {
        return selectsTextOnFocusGain;
    }
    
    /**
     * If <code>selectsTextOnFocusGain</code> is <tt>true</tt>, all text in the
     * editor is selected when the combo box editor gains focus. If it is
     * <tt>false</tt> the selection state of the editor is not effected by
     * focus changes.
     *
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public void setSelectsTextOnFocusGain(boolean selectsTextOnFocusGain) {
        checkAccessThread();
        this.selectsTextOnFocusGain = selectsTextOnFocusGain;
    }
    
    /**
     * Returns the manner in which the contents of the {@link ComboBoxModel}
     * are filtered. This method will return one of
     * {@link TextMatcherEditor#CONTAINS} or {@link TextMatcherEditor#STARTS_WITH}.
     *
     * <p>{@link TextMatcherEditor#CONTAINS} indicates elements of the
     * {@link ComboBoxModel} are matched when they contain the text entered by
     * the user.
     *
     * <p>{@link TextMatcherEditor#STARTS_WITH} indicates elements of the
     * {@link ComboBoxModel} are matched when they start with the text entered
     * by the user.
     *
     * <p>In both modes, autocompletion only occurs when a given item starts
     * with user-specified text. The filter mode only affects the filtering
     * aspect of autocomplete support.
     */
    public int getFilterMode() {
        return filterMatcherEditor.getMode();
    }
    
    /**
     * Sets the manner in which the contents of the {@link ComboBoxModel} are
     * filtered. The given <code>mode</code> must be one of
     * {@link TextMatcherEditor#CONTAINS} or {@link TextMatcherEditor#STARTS_WITH}.
     *
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     *
     * @see #getFilterMode()
     */
    public void setFilterMode(int mode) {
        checkAccessThread();
        doNotChangeDocument = true;
        try {
            filterMatcherEditor.setMode(mode);
        } finally {
            doNotChangeDocument = false;
        }
    }
    
    /**
     * This method removes autocompletion support from the {@link JComboBox}
     * it was installed on. This method is useful when the {@link EventList} of
     * items that backs the combo box must outlive the combo box itself.
     * Calling this method will return the combo box to its original state
     * before autocompletion was installed, and it will be available for
     * garbage collection independently of the {@link EventList} of items.
     *
     * @throws IllegalStateException if this method is called from any Thread
     *      other than the Swing Event Dispatch Thread
     */
    public void uninstall() {
        checkAccessThread();
        if (this.comboBox == null) throw new IllegalStateException("This AutoCompleteSupport has already been uninstalled");
        this.comboBox.removePropertyChangeListener("UI", this.uiWatcher);
        this.comboBox.removePropertyChangeListener("model", this.modelWatcher);
        this.comboBoxEditorComponent.removePropertyChangeListener("document", this.documentWatcher);
        this.undecorateOriginalUI();
        this.comboBox.setModel(originalModel);
        this.originalModel = null;
        this.comboBox.setEditable(originalComboBoxEditable);
        this.comboBoxModel.dispose();
        this.filteredItems.dispose();
        this.comboBox = null;
    }
    
    /**
     * This method updates the value which filters the items in the
     * ComboBoxModel.
     *
     * @param newFilter the new value by which to filter the item
     */
    private void applyFilter(String newFilter) {
        if (doNotFilter) return;
        doNotChangeDocument = true;
        final ActionListener[] listeners = unregisterAllActionListeners(comboBox);
        try {
            filterMatcherEditor.setFilterText(new String[]{newFilter});
        } finally {
            registerAllActionListeners(comboBox, listeners);
            doNotChangeDocument = false;
        }
    }
    
    /**
     * This method updates the {@link #prefix} to be the current value in the
     * ComboBoxEditor.
     */
    private void updateFilter() {
        prefix = comboBoxEditorComponent.getText();
        if (prefix.length() == 0) filterMatcher = Matchers.trueMatcher(); else filterMatcher = new TextMatcher(new String[]{prefix}, GlazedLists.toStringTextFilterator(), TextMatcherEditor.STARTS_WITH);
    }
    
    /**
     * A small convenience method to try showing the ComboBoxPopup.
     */
    private void togglePopup() {
        if (doNotTogglePopup) return;
        if (comboBoxModel.getSize() == 0) comboBox.hidePopup(); else if (comboBox.isShowing() && !comboBox.isPopupVisible()) comboBox.showPopup();
    }
    
    /**
     * Returns <tt>true</tt> if the list of all possible values in the
     * ComboBoxModel includes one which meets the criteria to be the
     * autocompletion term for the given <code>value</code>.
     */
    private String findAutoCompleteTerm(String value) {
        final boolean prefixIsEmpty = "".equals(value);
        final Matcher valueMatcher = new TextMatcher(new String[]{value}, GlazedLists.toStringTextFilterator(), TextMatcherEditor.STARTS_WITH);
        for (int i = 0, n = items.size(); i < n; i++) {
            final String itemString = convertToString(items.get(i));
            if (prefixIsEmpty ? "".equals(itemString) : valueMatcher.matches(itemString)) return itemString;
        }
        return null;
    }
    
    /**
     * This special version of EventComboBoxModel simply marks a flag to
     * indicate the items in the ComboBoxModel should not be filtered as a
     * side-effect of setting the selected item.
     */
    private class AutoCompleteComboBoxModel extends EventComboBoxModel {
        
        public AutoCompleteComboBoxModel(EventList source) {
            super(source);
        }
        
        public void setSelectedItem(Object selected) {
            doNotFilter = true;
            final ActionListener[] listeners = unregisterAllActionListeners(comboBox);
            try {
                super.setSelectedItem(selected);
                final int caretPos = comboBoxEditorComponent.getCaretPosition();
                comboBoxEditorComponent.select(caretPos, caretPos);
            } finally {
                registerAllActionListeners(comboBox, listeners);
                doNotFilter = false;
            }
        }
    }
    
    /**
     * This class is the crux of the entire solution. This custom DocumentFilter
     * controls all edits which are attempted against the Document of the
     * ComboBoxEditor component. It is our hook to either control when to respect
     * edits as well as the side-effects the edit has on autocompletion and
     * filtering.
     */
    private class AutoCompleteFilter extends DocumentFilter {
        
        private AutoCompleteFilter() {
            super();
        }
        
        public void replace(FilterBypass filterBypass, int offset, int length, String string, AttributeSet attributeSet) throws BadLocationException {
            if (doNotChangeDocument) return;
            final String valueBeforeEdit = comboBoxEditorComponent.getText();
            final int selectionStart = comboBoxEditorComponent.getSelectionStart();
            final int selectionEnd = comboBoxEditorComponent.getSelectionEnd();
            final boolean isReplacingAllText = offset == 0 && document.getLength() == length;
            if (isReplacingAllText && valueBeforeEdit.equals(string)) return;
            super.replace(filterBypass, offset, length, string, attributeSet);
            postProcessDocumentChange(filterBypass, attributeSet, valueBeforeEdit, selectionStart, selectionEnd);
        }
        
        public void insertString(FilterBypass filterBypass, int offset, String string, AttributeSet attributeSet) throws BadLocationException {
            if (doNotChangeDocument) return;
            final String valueBeforeEdit = comboBoxEditorComponent.getText();
            final int selectionStart = comboBoxEditorComponent.getSelectionStart();
            final int selectionEnd = comboBoxEditorComponent.getSelectionEnd();
            super.insertString(filterBypass, offset, string, attributeSet);
            postProcessDocumentChange(filterBypass, attributeSet, valueBeforeEdit, selectionStart, selectionEnd);
        }
        
        public void remove(FilterBypass filterBypass, int offset, int length) throws BadLocationException {
            if (doNotChangeDocument) return;
            final String valueBeforeEdit = comboBoxEditorComponent.getText();
            final int selectionStart = comboBoxEditorComponent.getSelectionStart();
            final int selectionEnd = comboBoxEditorComponent.getSelectionEnd();
            super.remove(filterBypass, offset, length);
            doNotAutoComplete = !isStrict();
            try {
                postProcessDocumentChange(filterBypass, null, valueBeforeEdit, selectionStart, selectionEnd);
            } finally {
                doNotAutoComplete = false;
            }
        }
        
        /**
         * This method generically post processes changes to the ComboBox
         * editor's Document. The generic algorithm, regardless of the type of
         * change, is as follows:
         *
         * <ol>
         *   <li> save the prefix as the user has entered it
         *   <li> filter the combo box items against the prefix
         *   <li> update the text in the combo box editor with an autocomplete suggestion
         *   <li> try to show the popup, if possible
         * </ol>
         */
        private void postProcessDocumentChange(FilterBypass filterBypass, AttributeSet attributeSet, String valueBeforeEdit, int selectionStart, int selectionEnd) throws BadLocationException {
            if (doNotPostProcessDocumentChanges) return;
            final String valueAfterEdit = comboBoxEditorComponent.getText();
            if (isStrict() && findAutoCompleteTerm(valueAfterEdit) == null) {
                UIManager.getLookAndFeel().provideErrorFeedback(comboBoxEditorComponent);
                doNotPostProcessDocumentChanges = true;
                try {
                    comboBoxEditorComponent.setText(valueBeforeEdit);
                } finally {
                    doNotPostProcessDocumentChanges = false;
                }
                comboBoxEditorComponent.select(selectionStart, selectionEnd);
                return;
            }
            final Object selectedItemBeforeEdit = comboBox.getSelectedItem();
            updateFilter();
            applyFilter(prefix);
            selectAutoCompleteTerm(filterBypass, attributeSet, selectedItemBeforeEdit);
            togglePopup();
        }
        
        /**
         * This method will attempt to locate a reasonable autocomplete item
         * from all combo box items and select it. It will also populate the
         * combo box editor with the remaining text which matches the
         * autocomplete item and select it. If the selection changes and the
         * JComboBox is not a Table Cell Editor, an ActionEvent will be
         * broadcast from the combo box.
         */
        private void selectAutoCompleteTerm(FilterBypass filterBypass, AttributeSet attributeSet, Object selectedItemBeforeEdit) throws BadLocationException {
            if (doNotAutoComplete) return;
            final boolean prefixIsEmpty = "".equals(prefix);
            for (int i = 0, n = comboBoxModel.getSize(); i < n; i++) {
                final String itemString = convertToString(comboBoxModel.getElementAt(i));
                if (prefixIsEmpty ? !"".equals(itemString) : !filterMatcher.matches(itemString)) continue;
                if (getCorrectsCase() || isStrict()) {
                    filterBypass.replace(0, prefix.length(), itemString, attributeSet);
                } else {
                    final String itemSuffix = itemString.substring(prefix.length());
                    filterBypass.insertString(prefix.length(), itemSuffix, attributeSet);
                }
                final boolean silently = isTableCellEditor || GlazedListsImpl.equal(selectedItemBeforeEdit, itemString);
                selectItem(i, silently);
                comboBoxEditorComponent.select(prefix.length(), document.getLength());
                return;
            }
            final boolean silently = isTableCellEditor || selectedItemBeforeEdit == null;
            selectItem(-1, silently);
        }
        
        /**
         * Select the item at the given <code>index</code>. If
         * <code>silent</code> is <tt>true</tt>, the JComboBox will not
         * broadcast an ActionEvent.
         */
        private void selectItem(int index, boolean silently) {
            final Object valueToSelect = index == -1 ? null : comboBoxModel.getElementAt(index);
            if (GlazedListsImpl.equal(comboBoxModel.getSelectedItem(), valueToSelect)) return;
            doNotChangeDocument = true;
            try {
                if (silently) comboBoxModel.setSelectedItem(valueToSelect); else comboBox.setSelectedItem(valueToSelect);
            } finally {
                doNotChangeDocument = false;
            }
        }
    }
    
    /**
     * Select the item at the given <code>index</code>. This method behaves
     * differently in strict mode vs. non-strict mode.
     *
     * <p>In strict mode, the selected index must always be valid, so using the
     * down arrow key on the last item or the up arrow key on the first item
     * simply wraps the selection to the opposite end of the model.
     *
     * <p>In non-strict mode, the selected index can be -1 (no selection), so we
     * allow -1 to mean "adjust the value of the ComboBoxEditor to be the users
     * text" and only wrap to the end of the model when -2 is reached. In short,
     * <code>-1</code> is interpreted as "clear the selected item".
     * <code>-2</code> is interpreted as "the last element".
     */
    private void selectPossibleValue(int index) {
        if (isStrict()) {
            if (index < 0) index = comboBox.getModel().getSize() - 1;
            if (index > comboBox.getModel().getSize() - 1) index = 0;
        } else {
            if (index == -2) index = comboBox.getModel().getSize() - 1;
        }
        final boolean validIndex = index >= 0 && index < comboBox.getModel().getSize();
        if (!validIndex) index = -1;
        doNotPostProcessDocumentChanges = true;
        try {
            if (isTableCellEditor) {
                final ActionListener[] listeners = unregisterAllActionListeners(comboBox);
                try {
                    comboBox.setSelectedIndex(index);
                } finally {
                    registerAllActionListeners(comboBox, listeners);
                }
            } else {
                comboBox.setSelectedIndex(index);
            }
            if (!validIndex) {
                comboBoxEditorComponent.setText(prefix);
                doNotClearFilterOnPopupHide = true;
                try {
                    comboBox.setPopupVisible(false);
                } finally {
                    doNotClearFilterOnPopupHide = false;
                }
                comboBox.setPopupVisible(true);
            }
        } finally {
            doNotPostProcessDocumentChanges = false;
        }
        final String newSelection = comboBoxEditorComponent.getText();
        if (filterMatcher.matches(newSelection)) comboBoxEditorComponent.select(prefix.length(), newSelection.length());
    }
    
    /**
     * The action invoked by hitting the up or down arrow key.
     */
    private class MoveAction extends AbstractAction {
        private final int offset;
        
        public MoveAction(int offset) {
            super();
            this.offset = offset;
        }
        
        public void actionPerformed(ActionEvent e) {
            if (comboBox.isShowing()) {
                if (comboBox.isPopupVisible()) {
                    selectPossibleValue(comboBox.getSelectedIndex() + offset);
                } else {
                    applyFilter(prefix);
                    comboBox.setPopupVisible(true);
                }
            }
        }
    }
    
    /**
     * This class listens to the ComboBoxModel and redraws the popup if it
     * must grow or shrink to accomodate the latest list of items.
     */
    private class ListDataHandler implements ListDataListener {
        
        private ListDataHandler() {
            super();
        }
        private int previousItemCount = -1;
        
        public void contentsChanged(ListDataEvent e) {
            final int newItemCount = comboBox.getItemCount();
            if (previousItemCount == newItemCount) return;
            final int maxPopupItemCount = comboBox.getMaximumRowCount();
            if (popupMenu.isShowing()) {
                if (newItemCount < maxPopupItemCount || previousItemCount < maxPopupItemCount) {
                    doNotClearFilterOnPopupHide = true;
                    try {
                        comboBox.setPopupVisible(false);
                    } finally {
                        doNotClearFilterOnPopupHide = false;
                    }
                    comboBox.setPopupVisible(true);
                }
            }
            previousItemCount = newItemCount;
        }
        
        public void intervalAdded(ListDataEvent e) {
            contentsChanged(e);
        }
        
        public void intervalRemoved(ListDataEvent e) {
            contentsChanged(e);
        }
    }
    
    /**
     * This class sizes the popup menu of the combo box immediately before
     * it is shown on the screen. In particular, it will adjust the width
     * of the popup to accomodate a prototype display value if the combo
     * box contains one.
     */
    private class PopupSizer implements PopupMenuListener {
        
        private PopupSizer() {
            super();
        }
        
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
            final Object prototypeValue = comboBox.getPrototypeDisplayValue();
            if (prototypeValue == null) return;
            final JComponent popupComponent = (JComponent)(JComponent)e.getSource();
            if (popupComponent.getComponent(0) instanceof JScrollPane) {
                final JScrollPane scroller = (JScrollPane)(JScrollPane)popupComponent.getComponent(0);
                final Dimension scrollerSize = scroller.getPreferredSize();
                final Dimension prototypeSize = getPrototypeSize(prototypeValue);
                prototypeSize.width += scroller.getVerticalScrollBar().getPreferredSize().width;
                if (prototypeSize.width > scrollerSize.width) {
                    scrollerSize.width = prototypeSize.width;
                    scroller.setMaximumSize(scrollerSize);
                    scroller.setPreferredSize(scrollerSize);
                    scroller.setMinimumSize(scrollerSize);
                }
            }
        }
        
        private Dimension getPrototypeSize(Object prototypeValue) {
            ListCellRenderer renderer = comboBox.getRenderer();
            if (renderer == null) renderer = new DefaultListCellRenderer();
            final Component comp = renderer.getListCellRendererComponent(popup.getList(), prototypeValue, -1, false, false);
            comp.setFont(comboBox.getFont());
            return comp.getPreferredSize();
        }
        
        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            if (doNotClearFilterOnPopupHide) return;
            applyFilter("");
        }
        
        public void popupMenuCanceled(PopupMenuEvent e) {
        }
    }
    
    /**
     * When the user selects a value from the popup with the mouse, we want to
     * honour their selection *without* attempting to autocomplete it to a new
     * term. Otherwise, it is possible that selections which are prefixes for
     * values that appear higher in the ComboBoxModel cannot be selected by the
     * mouse since they can always be successfully autocompleted to another
     * term.
     */
    private class PopupMouseHandler extends MouseAdapter {
        
        private PopupMouseHandler() {
            super();
        }
        
        public void mousePressed(MouseEvent e) {
            doNotAutoComplete = true;
        }
        
        public void mouseReleased(MouseEvent e) {
            doNotAutoComplete = false;
        }
    }
    
    /**
     * When the user clicks on the arrow button, we always clear the
     * filtering from the model to emulate Firefox style autocompletion.
     */
    private class ArrowButtonMouseListener implements MouseListener {
        private final MouseListener decorated;
        
        public ArrowButtonMouseListener(MouseListener decorated) {
            super();
            this.decorated = decorated;
        }
        
        public void mousePressed(MouseEvent e) {
            applyFilter("");
            decorated.mousePressed(e);
        }
        
        public MouseListener getDecorated() {
            return decorated;
        }
        
        public void mouseClicked(MouseEvent e) {
            decorated.mouseClicked(e);
        }
        
        public void mouseReleased(MouseEvent e) {
            decorated.mouseReleased(e);
        }
        
        public void mouseEntered(MouseEvent e) {
            decorated.mouseEntered(e);
        }
        
        public void mouseExited(MouseEvent e) {
            decorated.mouseExited(e);
        }
    }
    
    /**
     * This KeyListener handles the case when the user hits the backspace key
     * and the {@link AutoCompleteSupport} is strict. Normally backspace would
     * delete the selected text, if it existed, or delete the character
     * immediately preceding the cursor. In strict mode the ComboBoxEditor must
     * always contain a value from the ComboBoxModel, so the backspace key
     * <strong>NEVER</strong> alters the Document. Rather, it alters the
     * text selection to include one more character to the left. This is a nice
     * compromise, since the editor continues to retain a valid value from the
     * ComboBoxModel, but the user may type a key at any point to replace the
     * selection with another valid entry.
     *
     * This KeyListener also makes up for a bug in normal JComboBox when
     * handling the enter key. Specifically, hitting enter in an stock
     * JComboBox that is editable produces <strong>TWO</strong> ActionEvents.
     * When the enter key is detected we actually unregister all
     * ActionListeners, process the keystroke as normal, then reregister the
     * listeners and broadcast an event to them, producing a single ActionEvent.
     */
    private class AutoCompleteKeyHandler extends KeyAdapter {
        
        private AutoCompleteKeyHandler() {
            super();
        }
        private ActionListener[] actionListeners;
        
        public void keyPressed(KeyEvent e) {
            doNotTogglePopup = false;
            if (e.getKeyChar() == KeyEvent.VK_ENTER) {
                doNotChangeDocument = true;
                this.actionListeners = unregisterAllActionListeners(comboBox);
            }
            if (isTrigger(e)) doNotChangeDocument = true;
        }
        
        public void keyTyped(KeyEvent e) {
            if (isTrigger(e)) {
                if (comboBoxEditorComponent.getText().length() == 0) return;
                int selectionStart = Math.min(comboBoxEditorComponent.getSelectionStart(), comboBoxEditorComponent.getSelectionEnd());
                if (selectionStart == 0) {
                    UIManager.getLookAndFeel().provideErrorFeedback(comboBoxEditorComponent);
                    return;
                }
                selectionStart--;
                comboBoxEditorComponent.setCaretPosition(comboBoxEditorComponent.getText().length());
                comboBoxEditorComponent.moveCaretPosition(selectionStart);
            }
        }
        
        public void keyReleased(KeyEvent e) {
            if (isTrigger(e)) doNotChangeDocument = false;
            if (e.getKeyChar() == KeyEvent.VK_ENTER) {
                updateFilter();
                registerAllActionListeners(comboBox, this.actionListeners);
                comboBox.actionPerformed(new ActionEvent(e.getSource(), e.getID(), null));
                this.actionListeners = null;
                doNotChangeDocument = false;
            }
            doNotTogglePopup = true;
        }
        
        private boolean isTrigger(KeyEvent e) {
            return isStrict() && e.getKeyChar() == KeyEvent.VK_BACK_SPACE;
        }
    }
    
    /**
     * To emulate Firefox behaviour, all text in the ComboBoxEditor is selected
     * from beginning to end when the ComboBoxEditor gains focus if the value
     * returned from {@link AutoCompleteSupport#getSelectsTextOnFocusGain()}
     * allows this behaviour.
     */
    private class SelectTextOnFocusGainHandler extends FocusAdapter {
        
        private SelectTextOnFocusGainHandler() {
            super();
        }
        
        public void focusGained(FocusEvent e) {
            if (getSelectsTextOnFocusGain()) comboBoxEditorComponent.select(0, comboBoxEditorComponent.getText().length());
        }
    }
    
    /**
     * Watch for a change of the ComboBoxUI and reinstall the necessary
     * behaviour customizations.
     */
    private class UIWatcher implements PropertyChangeListener {
        
        private UIWatcher() {
            super();
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
            undecorateOriginalUI();
            decorateCurrentUI();
        }
    }
    
    /**
     * Watch for a change of the ComboBoxModel and report it as a violation.
     */
    private class ModelWatcher implements PropertyChangeListener {
        
        private ModelWatcher() {
            super();
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
            throwIllegalStateException("The ComboBoxModel cannot be changed. It was changed to: " + evt.getNewValue());
        }
    }
    
    /**
     * Watch the Document behind the editor component in case it changes. If a
     * new Document is swapped in, uninstall our DocumentFilter from the old
     * Document and install it on the new.
     */
    private class DocumentWatcher implements PropertyChangeListener {
        
        private DocumentWatcher() {
            super();
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
            final Document newDocument = (Document)(Document)evt.getNewValue();
            if (!(newDocument instanceof AbstractDocument)) throwIllegalStateException("The Document behind the JTextField was changed to no longer be an AbstractDocument. It was changed to: " + newDocument);
            document.setDocumentFilter(null);
            document = (AbstractDocument)(AbstractDocument)newDocument;
            document.setDocumentFilter(documentFilter);
        }
    }
    
    /**
     * A custom renderer which honours the custom Format given by the user when
     * they invoked the install method.
     */
    private class StringFunctionRenderer extends DefaultListCellRenderer {
        
        private StringFunctionRenderer() {
            super();
        }
        
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            final String string = convertToString(value);
            return super.getListCellRendererComponent(list, string, index, isSelected, cellHasFocus);
        }
    }
    
    /**
     * A decorated version of the ComboBoxEditor that does NOT assume that
     * Object.toString() is the proper way to convert values from the
     * ComboBoxModel into Strings for the ComboBoxEditor's component. It uses
     * convertToString(E) instead.
     *
     * We implement the UIResource interface here so that changes in the UI
     * delegate of the JComboBox will *replace* this ComboBoxEditor with one
     * that is correct for the new L&F. We will then react to the change of UI
     * delegate by installing a new FormatComboBoxEditor overtop of the
     * UI Delegate's default ComboBoxEditor.
     */
    private class FormatComboBoxEditor implements ComboBoxEditor, UIResource {
        
        /**
         * This is the ComboBoxEditor installed by the current UI Delegate of the JComboBox. 
         */
        private final ComboBoxEditor delegate;
        private Object oldValue;
        
        public FormatComboBoxEditor(ComboBoxEditor delegate) {
            super();
            this.delegate = delegate;
        }
        
        public ComboBoxEditor getDelegate() {
            return delegate;
        }
        
        /**
         * BasicComboBoxEditor defines this method to call:
         *
         * editor.setText(anObject.toString());
         *
         * we intercept and replace it with our own String conversion logic
         * to remain consistent throughout.
         */
        public void setItem(Object anObject) {
            oldValue = anObject;
            ((JTextField)(JTextField)getEditorComponent()).setText(convertToString(anObject));
        }
        
        /**
         * BasicComboBoxEditor defines this method to use reflection to try
         * finding a method called valueOf(String) in order to return the
         * item. We attempt to find a user-supplied Format before
         * resorting to the valueOf(String) call.
         */
        public Object getItem() {
            final String oldValueString = convertToString(oldValue);
            final String currentString = ((JTextField)(JTextField)getEditorComponent()).getText();
            if (GlazedListsImpl.equal(oldValueString, currentString)) return oldValue;
            if (format != null) return format.parseObject(currentString, PARSE_POSITION);
            if (oldValue != null && !(oldValue instanceof String)) {
                try {
                    final Method method = oldValue.getClass().getMethod("valueOf", VALUE_OF_SIGNATURE);
                    return method.invoke(oldValue, new Object[]{currentString});
                } catch (Exception ex) {
                }
            }
            return currentString;
        }
        
        public Component getEditorComponent() {
            return delegate.getEditorComponent();
        }
        
        public void selectAll() {
            delegate.selectAll();
        }
        
        public void addActionListener(ActionListener l) {
            delegate.addActionListener(l);
        }
        
        public void removeActionListener(ActionListener l) {
            delegate.removeActionListener(l);
        }
    }
    
    /**
     * This default implementation of the TextFilterator interface uses the
     * same strategy for producing Strings from ComboBoxModel objects as the
     * renderer and editor.
     */
    class DefaultTextFilterator implements TextFilterator {
        
        DefaultTextFilterator() {
            super();
        }
        
        public void getFilterStrings(List baseList, Object element) {
            baseList.add(convertToString(element));
        }
    }
    
    /**
     * This factory method creates and returns a {@link DefaultCellEditor}
     * which adapts an autocompleting {@link JComboBox} for use as a Table
     * Cell Editor. The values within the table column are used as
     * autocompletion terms within the {@link ComboBoxModel}.
     *
     * <p>This version of <code>createTableCellEditor</code> assumes that the
     * values stored in the TableModel at the given <code>columnIndex</code>
     * are all {@link Comparable}, and that the natural ordering defined by
     * those {@link Comparable} values also determines which are duplicates
     * (and thus can safely be removed) and which are unique (and thus must
     * remain in the {@link ComboBoxModel}).
     *
     * <p>Note that this factory method is only appropriate for use when the
     * values in the {@link ComboBoxModel} should be the unique set of values
     * in a table column. If some other list of values will be used, do not use
     * this factory method and create the {@link DefaultCellEditor} directly
     * with code similar to this: <p>
     *
     * <pre>
     * EventList comboBoxModelValues = ...
     * JComboBox comboBox = new JComboBox();
     * DefaultCellEditor cellEditor = new DefaultCellEditor(comboBox);
     * AutoCompleteSupport.install(comboBox, comboBoxModelValues);
     * </pre>
     *
     * <p>If the appearance or function of the autocompleting {@link JComboBox}
     * is to be customized, it can be retrieved using
     * {@link DefaultCellEditor#getComponent()}.
     *
     * @param tableFormat specifies how each row object within a table is
     *      broken apart into column values
     * @param tableData the {@link EventList} backing the TableModel
     * @param columnIndex the index of the column for which to return a
     *      {@link DefaultCellEditor}
     * @return a {@link DefaultCellEditor} which contains an autocompleting
     *      combobox whose contents remain consistent with the data in the
     *      table column at the given <code>columnIndex</code>
     */
    public static DefaultCellEditor createTableCellEditor(TableFormat tableFormat, EventList tableData, int columnIndex) {
        return createTableCellEditor(GlazedLists.comparableComparator(), tableFormat, tableData, columnIndex);
    }
    
    /**
     * This factory method creates and returns a {@link DefaultCellEditor}
     * which adapts an autocompleting {@link JComboBox} for use as a Table
     * Cell Editor. The values within the table column are used as
     * autocompletion terms within the {@link ComboBoxModel}.
     *
     * <p>This version of <code>createTableCellEditor</code> makes no
     * assumption about the values stored in the TableModel at the given
     * <code>columnIndex</code>. Instead, it uses the given
     * <code>uniqueComparator</code> to determine which values are duplicates
     * (and thus can safely be removed) and which are unique (and thus must
     * remain in the {@link ComboBoxModel}).
     *
     * <p>Note that this factory method is only appropriate for use when the
     * values in the {@link ComboBoxModel} should be the unique set of values
     * in a table column. If some other list of values will be used, do not use
     * this factory method and create the {@link DefaultCellEditor} directly
     * with code similar to this: <p>
     *
     * <pre>
     * EventList comboBoxModelValues = ...
     * JComboBox comboBox = new JComboBox();
     * DefaultCellEditor cellEditor = new DefaultCellEditor(comboBox);
     * AutoCompleteSupport.install(comboBox, comboBoxModelValues);
     * </pre>
     *
     * <p>If the appearance or function of the autocompleting {@link JComboBox}
     * is to be customized, it can be retrieved using
     * {@link DefaultCellEditor#getComponent()}.
     *
     * @param uniqueComparator the {@link Comparator} that strips away
     *      duplicate elements from the {@link ComboBoxModel}
     * @param tableFormat specifies how each row object within a table is
     *      broken apart into column values
     * @param tableData the {@link EventList} backing the TableModel
     * @param columnIndex the index of the column for which to return a
     *      {@link DefaultCellEditor}
     * @return a {@link DefaultCellEditor} which contains an autocompleting
     *      combobox whose contents remain consistent with the data in the
     *      table column at the given <code>columnIndex</code>
     */
    public static DefaultCellEditor createTableCellEditor(Comparator uniqueComparator, TableFormat tableFormat, EventList tableData, int columnIndex) {
        final FunctionList.Function columnValueFunction = new TableColumnValueFunction(tableFormat, columnIndex);
        final FunctionList allColumnValues = new FunctionList(tableData, columnValueFunction);
        final EventList uniqueColumnValues = new UniqueList(allColumnValues, uniqueComparator);
        final DefaultCellEditor cellEditor = new DefaultCellEditor(new JComboBox());
        cellEditor.setClickCountToStart(2);
        AutoCompleteSupport.install((JComboBox)(JComboBox)cellEditor.getComponent(), uniqueColumnValues);
        return cellEditor;
    }
    
    /**
     * This function uses a TableFormat and columnIndex to extract all of the
     * values that are displayed in the given table column. These values are
     * used as autocompletion terms when editing a cell within that column.
     */
    private static final class TableColumnValueFunction implements FunctionList.Function {
        private final TableFormat tableFormat;
        private final int columnIndex;
        
        public TableColumnValueFunction(TableFormat tableFormat, int columnIndex) {
            super();
            this.tableFormat = tableFormat;
            this.columnIndex = columnIndex;
        }
        
        public Object evaluate(Object sourceValue) {
            return tableFormat.getColumnValue(sourceValue, columnIndex);
        }
    }
}
