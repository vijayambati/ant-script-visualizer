package ca.odell.glazedlists.impl.matchers;

import ca.odell.glazedlists.*;
import ca.odell.glazedlists.matchers.*;

/**
 * A {@link MatcherEditor} whose {@link Matcher} never changes.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class FixedMatcherEditor extends AbstractMatcherEditor {
    
    /**
     * Create a {@link FixedMatcherEditor} for the specified {@link Matcher}.
     */
    public FixedMatcherEditor(Matcher matcher) {
        super();
        super.fireChanged(matcher);
    }
}
