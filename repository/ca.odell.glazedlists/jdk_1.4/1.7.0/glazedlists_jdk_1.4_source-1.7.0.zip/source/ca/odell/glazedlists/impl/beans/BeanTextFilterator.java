package ca.odell.glazedlists.impl.beans;

import java.util.*;
import ca.odell.glazedlists.TextFilterator;
import ca.odell.glazedlists.Filterator;

/**
 * TextFilterator implementation that uses reflection to be used for any
 * JavaBean-like Object with getProperty() and setProperty() style API.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class BeanTextFilterator implements TextFilterator, Filterator {
    
    /**
     * Java Beans property names 
     */
    private String[] propertyNames;
    
    /**
     * methods for extracting field values 
     */
    private BeanProperty[] beanProperties = null;
    
    /**
     * Create a BeanTextFilterator that uses the specified property names.
     */
    public BeanTextFilterator(String[] propertyNames) {
        super();
        this.propertyNames = propertyNames;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void getFilterStrings(List baseList, Object element) {
        if (element == null) return;
        if (beanProperties == null) loadPropertyDescriptors(element);
        for (int p = 0; p < beanProperties.length; p++) {
            Object propertyValue = beanProperties[p].get(element);
            if (propertyValue == null) continue;
            baseList.add(propertyValue.toString());
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public void getFilterValues(List baseList, Object element) {
        if (element == null) return;
        if (beanProperties == null) loadPropertyDescriptors(element);
        for (int p = 0; p < beanProperties.length; p++) {
            Object propertyValue = beanProperties[p].get(element);
            if (propertyValue == null) continue;
            baseList.add((Object)propertyValue);
        }
    }
    
    /**
     * Loads the property descriptors which are used to invoke property
     * access methods using the property names.
     */
    private void loadPropertyDescriptors(Object beanObject) {
        Class beanClass = (Class)beanObject.getClass();
        beanProperties = new BeanProperty[propertyNames.length];
        for (int p = 0; p < propertyNames.length; p++) {
            beanProperties[p] = new BeanProperty(beanClass, propertyNames[p], true, false);
        }
    }
}
