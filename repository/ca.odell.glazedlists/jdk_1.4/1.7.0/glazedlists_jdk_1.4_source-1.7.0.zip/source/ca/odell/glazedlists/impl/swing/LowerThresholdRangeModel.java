package ca.odell.glazedlists.impl.swing;

import ca.odell.glazedlists.*;
import javax.swing.*;

/**
 * A LowerThresholdRangeModel provides an implementation of a bounded-range
 * model for a slider widget that binds a JSlider to a ThresholdList.  This
 * implementation maps the slider value to the lower threshold of the
 * ThresholdList.
 *
 * @author <a href="mailto:kevin@swank.ca">Kevin Maltby</a>
 */
public class LowerThresholdRangeModel extends DefaultBoundedRangeModel implements BoundedRangeModel {
    
    /**
     * the list to connect a slider widget to 
     */
    private ThresholdList target = null;
    
    /**
     * Creates a new range that controls specified ThresholdList.
     */
    public LowerThresholdRangeModel(ThresholdList target) {
        super();
        this.target = target;
    }
    
    /**
     * Returns the model's maximum.
     */
    public int getMaximum() {
        target.getReadWriteLock().readLock().lock();
        try {
            return target.getUpperThreshold();
        } finally {
            target.getReadWriteLock().readLock().unlock();
        }
    }
    
    /**
     * Returns the model's current value.
     */
    public int getValue() {
        target.getReadWriteLock().readLock().lock();
        try {
            return target.getLowerThreshold();
        } finally {
            target.getReadWriteLock().readLock().unlock();
        }
    }
    
    /**
     * Sets all of the properties for this bounded-range.
     *
     * <p>This is a tweaked version of the setRangeProperties method to be found
     * in the JDK source for DefaultBoundedRangeModel.  Just giving credit where
     * credit is due.
     */
    public void setRangeProperties(int newValue, int newExtent, int newMin, int newMax, boolean adjusting) {
        target.getReadWriteLock().writeLock().lock();
        try {
            if (newMin > newMax) newMin = newMax;
            if (newValue > newMax) newMax = newValue;
            if (newValue < newMin) newMin = newValue;
            boolean changed = (newExtent != getExtent()) || (newMin != getMinimum()) || (adjusting != getValueIsAdjusting());
            if (newValue != getValue()) {
                target.setLowerThreshold(newValue);
                changed = true;
            }
            if (newMax != getMaximum()) {
                target.setUpperThreshold(newMax);
                changed = true;
            }
            if (changed) super.setRangeProperties(newValue, newExtent, newMin, newMax, adjusting);
        } finally {
            target.getReadWriteLock().writeLock().unlock();
        }
    }
}
