package ca.odell.glazedlists.impl.adt.barcode2;

import java.util.AbstractList;

/**
 * Adapt a {@link SimpleTree} for use as a {@link List}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SimpleTreeAsList extends AbstractList {
    private final SimpleTree tree;
    
    /**
     * Create a new {@link SimpleTreeAsList}, adapting the specified colors subset
     * of the specified tree. Inserted elements via {@link #add} will be of the
     * specified color.
     */
    public SimpleTreeAsList(SimpleTree tree) {
        super();
        this.tree = tree;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object get(int index) {
        return tree.get(index).get();
    }
    
    /**
     * {@inheritDoc} 
     */
    public void add(int index, Object element) {
        tree.add(index, element, 1);
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object set(int index, Object element) {
        Object replaced = get(index);
        tree.set(index, element, 1);
        return replaced;
    }
    
    /**
     * {@inheritDoc} 
     */
    public Object remove(int index) {
        Object removed = get(index);
        tree.remove(index, 1);
        return removed;
    }
    
    /**
     * {@inheritDoc} 
     */
    public int size() {
        return tree.size();
    }
}
