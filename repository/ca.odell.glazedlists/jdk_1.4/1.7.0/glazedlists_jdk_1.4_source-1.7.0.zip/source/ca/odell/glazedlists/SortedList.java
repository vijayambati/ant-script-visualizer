package ca.odell.glazedlists;

import ca.odell.glazedlists.impl.adt.barcode2.Element;
import ca.odell.glazedlists.impl.adt.barcode2.SimpleTree;
import ca.odell.glazedlists.impl.adt.barcode2.SimpleTreeIterator;
import ca.odell.glazedlists.impl.GlazedListsImpl;
import ca.odell.glazedlists.event.ListEvent;
import java.util.*;

/**
 * An {@link EventList} that shows its source {@link EventList} in sorted order.
 *
 * <p>The sorting strategy is specified with a {@link Comparator}. If no
 * {@link Comparator} is specified, all of the elements of the source {@link EventList}
 * must implement {@link Comparable}.
 *
 * <p>This {@link EventList} supports all write operations.
 *
 * <p><strong><font color="#FF0000">Warning:</font></strong> This class
 * breaks the contract required by {@link List}. See {@link EventList}
 * for an example.
 *
 * <p><table border="1" width="100%" cellpadding="3" cellspacing="0">
 * <tr class="TableHeadingColor"><td colspan=2><font size="+2"><b>EventList Overview</b></font></td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Writable:</b></td><td>yes</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Concurrency:</b></td><td>thread ready, not thread safe</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Performance:</b></td><td>reads: O(log N), writes O(log N), change comparator O(N log N)</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Memory:</b></td><td>72 bytes per element</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Unit Tests:</b></td><td>N/A</td></tr>
 * <tr><td class="TableSubHeadingColor"><b>Issues:</b></td><td>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=39">39</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=40">40</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=58">58</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=60">60</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=62">62</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=66">66</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=161">161</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=170">170</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=206">206</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=239">239</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=255">255</a>
 *   <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=261">261</a>
 * </td></tr>
 * </table>
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class SortedList extends TransformedList {
    private static final byte ALL_COLORS = 1;
    private static final Element EMPTY_ELEMENT = null;
    
    /**
     * Sorting mode where elements are always in sorted order, even if this
     * requires that elements be moved from one index to another when their
     * value is changed.
     */
    public static final int STRICT_SORT_ORDER = 0;
    
    /**
     * Sorting mode where elements aren't moved when their value is changed,
     * even if this means they are no longer in perfect sorted order. This mode
     * is useful in editable lists and tables because it is annoying
     * for the current element to move if its value changes.
     */
    public static final int AVOID_MOVING_ELEMENTS = 1;
    
    /**
     * a map from the unsorted index to the sorted index 
     */
    private SimpleTree unsorted = null;
    
    /**
     * a map from the sorted index to the unsorted index 
     */
    private SimpleTree sorted = null;
    
    /**
     * the comparator that this list uses for sorting 
     */
    private Comparator comparator = null;
    
    /**
     * one of {@link #STRICT_SORT_ORDER} or {@link #AVOID_MOVING_ELEMENTS}. 
     */
    private int mode = STRICT_SORT_ORDER;
    
    /**
     * Creates a {@link SortedList} that sorts the specified {@link EventList}.
     * Because this constructor takes no {@link Comparator} argument, all
     * elements in the specified {@link EventList} must implement {@link Comparable}
     * or a {@link ClassCastException} will be thrown.
     */
    public SortedList(EventList source) {
        this(source, (Comparator)GlazedLists.comparableComparator());
    }
    
    /**
     * Creates a {@link SortedList} that sorts the specified {@link EventList}
     * using the specified {@link Comparator} to determine sort order. If the
     * specified {@link Comparator} is <code>null</code>, then this {@link List}
     * will be unsorted.
     */
    public SortedList(EventList source, Comparator comparator) {
        super(source);
        setComparator(comparator);
        source.addListEventListener(this);
    }
    
    /**
     * Modify the behaviour of this {@link SortedList} to one of the predefined modes.
     *
     * @param mode either {@link #STRICT_SORT_ORDER} or {@link #AVOID_MOVING_ELEMENTS}.
     */
    public void setMode(int mode) {
        if (mode != STRICT_SORT_ORDER && mode != AVOID_MOVING_ELEMENTS) throw new IllegalArgumentException("Mode must be either SortedList.STRICT_SORT_ORDER or SortedList.AVOID_MOVING_ELEMENTS");
        if (mode == this.mode) return;
        this.mode = mode;
        if (this.mode == STRICT_SORT_ORDER) {
            setComparator(getComparator());
        }
    }
    
    /**
     * Get the behaviour mode for this {@link SortedList}.
     *
     * @return one of {@link #STRICT_SORT_ORDER} (default) or
     *     {@link #AVOID_MOVING_ELEMENTS}.
     */
    public int getMode() {
        return this.mode;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void listChanged(ListEvent listChanges) {
        if (listChanges.isReordering()) {
            int[] sourceReorder = listChanges.getReorderMap();
            int[] previousIndexToSortedIndex = new int[sorted.size()];
            int index = 0;
            for (SimpleTreeIterator i = new SimpleTreeIterator(sorted); i.hasNext(); index++) {
                i.next();
                Element unsortedNode = (Element)i.value();
                int unsortedIndex = unsorted.indexOfNode(unsortedNode, ALL_COLORS);
                previousIndexToSortedIndex[unsortedIndex] = index;
            }
            int[] newIndexToSortedIndex = new int[sorted.size()];
            for (int i = 0; i < previousIndexToSortedIndex.length; i++) {
                newIndexToSortedIndex[i] = previousIndexToSortedIndex[sourceReorder[i]];
            }
            Element[] unsortedNodes = new Element[unsorted.size()];
            index = 0;
            for (SimpleTreeIterator i = new SimpleTreeIterator(unsorted); i.hasNext(); index++) {
                i.next();
                Element unsortedNode = i.node();
                unsortedNodes[index] = unsortedNode;
            }
            Arrays.sort(unsortedNodes, sorted.getComparator());
            int[] reorderMap = new int[sorted.size()];
            boolean indexChanged = false;
            index = 0;
            for (SimpleTreeIterator i = new SimpleTreeIterator(sorted); i.hasNext(); index++) {
                i.next();
                Element sortedNode = i.node();
                Element unsortedNode = unsortedNodes[index];
                sortedNode.set(unsortedNode);
                unsortedNode.set(sortedNode);
                int unsortedIndex = unsorted.indexOfNode(unsortedNode, ALL_COLORS);
                reorderMap[index] = newIndexToSortedIndex[unsortedIndex];
                indexChanged = indexChanged || (index != reorderMap[index]);
            }
            if (indexChanged) {
                updates.beginEvent();
                updates.reorder(reorderMap);
                updates.commitEvent();
            }
            return;
        }
        updates.beginEvent();
        LinkedList insertNodes = new LinkedList();
        List updateNodes = new ArrayList();
        while (listChanges.next()) {
            int unsortedIndex = listChanges.getIndex();
            int changeType = listChanges.getType();
            if (changeType == ListEvent.INSERT) {
                Element unsortedNode = unsorted.add(unsortedIndex, EMPTY_ELEMENT, 1);
                insertNodes.addLast(unsortedNode);
            } else if (changeType == ListEvent.UPDATE) {
                Element unsortedNode = unsorted.get(unsortedIndex);
                Element sortedNode = (Element)unsortedNode.get();
                sortedNode.setSorted(Element.PENDING);
                updateNodes.add(sortedNode);
            } else if (changeType == ListEvent.DELETE) {
                Element unsortedNode = unsorted.get(unsortedIndex);
                unsorted.remove(unsortedNode);
                int deleteSortedIndex = deleteByUnsortedNode(unsortedNode);
                updates.addDelete(deleteSortedIndex);
            }
        }
        for (Iterator i = updateNodes.iterator(); i.hasNext(); ) {
            Element sortedNode = (Element)i.next();
            if (sortedNode.getSorted() != Element.PENDING) continue;
            Element lowerBound = null;
            Element upperBound = null;
            Element firstUnsortedNode = sortedNode;
            for (Element leftNeighbour = sortedNode.previous(); leftNeighbour != null; leftNeighbour = leftNeighbour.previous()) {
                if (leftNeighbour.getSorted() != Element.SORTED) {
                    firstUnsortedNode = leftNeighbour;
                    continue;
                }
                lowerBound = leftNeighbour;
                break;
            }
            for (Element rightNeighbour = sortedNode.next(); rightNeighbour != null; rightNeighbour = rightNeighbour.next()) {
                if (rightNeighbour.getSorted() != Element.SORTED) continue;
                upperBound = rightNeighbour;
                break;
            }
            Comparator nodeComparator = sorted.getComparator();
            for (Element current = firstUnsortedNode; current != upperBound; current = current.next()) {
                if (upperBound != null && nodeComparator.compare(current.get(), upperBound.get()) > 0) {
                    current.setSorted(Element.UNSORTED);
                    continue;
                }
                if (lowerBound != null && nodeComparator.compare(current.get(), lowerBound.get()) < 0) {
                    current.setSorted(Element.UNSORTED);
                    continue;
                }
                current.setSorted(Element.SORTED);
                lowerBound = current;
            }
        }
        for (Iterator i = updateNodes.iterator(); i.hasNext(); ) {
            Element sortedNode = (Element)i.next();
            assert (sortedNode.getSorted() != Element.PENDING);
            int originalIndex = sorted.indexOfNode(sortedNode, ALL_COLORS);
            if (sortedNode.getSorted() == Element.SORTED) {
                updates.addUpdate(originalIndex);
            } else if (mode == AVOID_MOVING_ELEMENTS) {
                updates.addUpdate(originalIndex);
            } else {
                sorted.remove(sortedNode);
                updates.addDelete(originalIndex);
                int insertedIndex = insertByUnsortedNode((Element)sortedNode.get());
                updates.addInsert(insertedIndex);
            }
        }
        while (!insertNodes.isEmpty()) {
            Element insertNode = (Element)insertNodes.removeFirst();
            int insertedIndex = insertByUnsortedNode(insertNode);
            updates.addInsert(insertedIndex);
        }
        updates.commitEvent();
    }
    
    /**
     * Inserts the specified unsorted node as the value in the sorted tree
     * and returns the sorted order.
     *
     * @return the sortIndex of the inserted object.
     */
    private int insertByUnsortedNode(Element unsortedNode) {
        Element sortedNode = sorted.addInSortedOrder(ALL_COLORS, unsortedNode, 1);
        unsortedNode.set(sortedNode);
        return sorted.indexOfNode(sortedNode, ALL_COLORS);
    }
    
    /**
     * Deletes the node in the sorted tree based on the value of the specified
     * unsorted tree node.
     *
     * @return the sortIndex of the deleted object.
     */
    private int deleteByUnsortedNode(Element unsortedNode) {
        Element sortedNode = (Element)(Element)unsortedNode.get();
        int sortedIndex = sorted.indexOfNode(sortedNode, ALL_COLORS);
        sorted.remove(sortedIndex, 1);
        return sortedIndex;
    }
    
    /**
     * {@inheritDoc} 
     */
    protected int getSourceIndex(int mutationIndex) {
        Element sortedNode = sorted.get(mutationIndex);
        Element unsortedNode = (Element)(Element)sortedNode.get();
        return unsorted.indexOfNode(unsortedNode, ALL_COLORS);
    }
    
    /**
     * {@inheritDoc} 
     */
    protected boolean isWritable() {
        return true;
    }
    
    /**
     * Gets the {@link Comparator} that is being used to sort this list.
     *
     * @return the {@link Comparator} in use, or <tt>null</tt> if this list is
     *      currently unsorted. If this is an {@link EventList} of {@link Comparable}
     *      elements in natural order, then a ComparableComparator} will
     *      be returned.
     */
    public Comparator getComparator() {
        return comparator;
    }
    
    /**
     * Set the {@link Comparator} in use in this {@link EventList}. This will
     * sort the {@link EventList} into a new order.
     *
     * <p>Performance Note: sorting will take <code>O(N * Log N)</code> time.
     *
     * <p><strong><font color="#FF0000">Warning:</font></strong> This method is
     * thread ready but not thread safe. See {@link EventList} for an example
     * of thread safe code.
     *
     * @param comparator the {@link Comparator} to specify how to sort the list. If
     *      the source {@link EventList} elements implement {@link Comparable},
     *      you may use a {@link GlazedLists#comparableComparator()} to sort them
     *      in their natural order. You may also specify <code>null</code> to put
     *      this {@link SortedList} in unsorted order.
     */
    public void setComparator(Comparator comparator) {
        this.comparator = comparator;
        SimpleTree previousSorted = sorted;
        Comparator treeComparator = null;
        if (comparator != null) treeComparator = new ElementComparator(comparator); else treeComparator = new ElementRawOrderComparator();
        sorted = new SimpleTree(treeComparator);
        if (previousSorted == null && unsorted == null) {
            unsorted = new SimpleTree();
            for (int i = 0, n = source.size(); i < n; i++) {
                Element unsortedNode = unsorted.add(i, EMPTY_ELEMENT, 1);
                insertByUnsortedNode(unsortedNode);
            }
            return;
        }
        if (source.size() == 0) return;
        for (SimpleTreeIterator i = new SimpleTreeIterator(unsorted); i.hasNext(); ) {
            i.next();
            Element unsortedNode = i.node();
            insertByUnsortedNode(unsortedNode);
        }
        int[] reorderMap = new int[size()];
        int oldSortedIndex = 0;
        for (SimpleTreeIterator i = new SimpleTreeIterator(previousSorted); i.hasNext(); oldSortedIndex++) {
            i.next();
            Element oldSortedNode = i.node();
            Element unsortedNode = (Element)(Element)oldSortedNode.get();
            Element newSortedNode = (Element)(Element)unsortedNode.get();
            int newSortedIndex = sorted.indexOfNode(newSortedNode, ALL_COLORS);
            reorderMap[newSortedIndex] = oldSortedIndex;
        }
        updates.beginEvent();
        updates.reorder(reorderMap);
        updates.commitEvent();
    }
    
    /**
     * {@inheritDoc} 
     */
    public int indexOf(Object object) {
        if (mode != STRICT_SORT_ORDER || comparator == null) return source.indexOf(object);
        int index = ((SimpleTree)sorted).indexOfValue(object, true, false, ALL_COLORS);
        if (index == -1) return -1;
        for (; index < size(); index++) {
            Object objectAtIndex = get(index);
            if (comparator.compare((Object)object, objectAtIndex) != 0) return -1;
            if (GlazedListsImpl.equal(object, objectAtIndex)) return index;
        }
        return -1;
    }
    
    /**
     * {@inheritDoc} 
     */
    public int lastIndexOf(Object object) {
        if (mode != STRICT_SORT_ORDER || comparator == null) return source.lastIndexOf(object);
        int index = ((SimpleTree)sorted).indexOfValue(object, false, false, ALL_COLORS);
        if (index == -1) return -1;
        for (; index > -1; index--) {
            Object objectAtIndex = get(index);
            if (comparator.compare((Object)object, objectAtIndex) != 0) return -1;
            if (GlazedListsImpl.equal(object, objectAtIndex)) return index;
        }
        return -1;
    }
    
    /**
     * Returns the first index of the <code>object</code>'s sort location or
     * the first index at which the <code>object</code> could be positioned if
     * inserted.
     *
     * <p>Unlike {@link #indexOf} this method does not guarantee the given
     * <code>object</code> {@link Object#equals(Object) equals} the element at
     * the returned index. Instead, they are indistinguishable according to the
     * sorting {@link Comparator}.
     *
     * @return a value in <tt>[0, size()]</tt> inclusive
     */
    public int sortIndex(Object object) {
        if (comparator == null) throw new IllegalStateException("No Comparator exists to perform this operation");
        return ((SimpleTree)sorted).indexOfValue(object, true, true, ALL_COLORS);
    }
    
    /**
     * Returns the last index of the <code>object</code>'s sort location or
     * the last index at which the <code>object</code> could be positioned if
     * inserted.
     *
     * <p>Unlike {@link #lastIndexOf} this method does not guarantee the given
     * <code>object</code> {@link Object#equals(Object) equals} the element at
     * the returned index. Instead, they are indistinguishable according to the
     * sorting {@link Comparator}.
     *
     * @return a value in <tt>[0, size()]</tt> inclusive
     */
    public int lastSortIndex(Object object) {
        if (comparator == null) throw new IllegalStateException("No Comparator exists to perform this operation");
        return ((SimpleTree)sorted).indexOfValue(object, false, true, ALL_COLORS);
    }
    
    /**
     * Returns the index in this list of the first occurrence of the specified
     * element, or the index where that element would be in the list if it were
     * inserted.
     *
     * @return the index in this list of the first occurrence of the specified
     *      element, or the index where that element would be in the list if it
     *      were inserted. This will return a value in <tt>[0, size()]</tt>,
     *      inclusive.
     *
     * @deprecated Deprecated as of 12/11/2005. Replaced with {@link #sortIndex(Object)}
     *      which has cleaner semantics.
     */
    public int indexOfSimulated(Object object) {
        return comparator != null ? ((SimpleTree)sorted).indexOfValue(object, true, true, ALL_COLORS) : size();
    }
    
    /**
     * {@inheritDoc} 
     */
    public boolean contains(Object object) {
        return indexOf(object) != -1;
    }
    
    /**
     * A comparator that takes an indexed node, and compares the value
     * of an object in a list that has the index of that node.
     *
     * <p>If one of the objects passed to {@link #compare} is not an
     * {@link Element}, it will compare the object directly to the object
     * in the source {@link EventList} referenced by the {@link Element}.
     * This functionality is necessary to allow use of the underlying
     * {@link Comparator} within {@link SimpleTree} to support {@link List#indexOf},
     * {@link List#lastIndexOf}, and {@link List#contains}.
     */
    private class ElementComparator implements Comparator {
        
        /**
         * the actual comparator used on the values found 
         */
        private Comparator comparator;
        
        /**
         * Creates an {@link ElementComparator} that compares the
         * objects in the source list based on the indexes of the tree
         * nodes being compared.
         */
        public ElementComparator(Comparator comparator) {
            super();
            this.comparator = comparator;
        }
        
        /**
         * Compares object alpha to object beta by using the source comparator.
         */
        public int compare(Object alpha, Object beta) {
            Object alphaObject = alpha;
            Object betaObject = beta;
            int alphaIndex = -1;
            int betaIndex = -1;
            if (alpha instanceof Element) {
                Element alphaTreeNode = (Element)(Element)alpha;
                alphaIndex = unsorted.indexOfNode(alphaTreeNode, ALL_COLORS);
                alphaObject = source.get(alphaIndex);
            }
            if (beta instanceof Element) {
                Element betaTreeNode = (Element)(Element)beta;
                betaIndex = unsorted.indexOfNode(betaTreeNode, ALL_COLORS);
                betaObject = source.get(betaIndex);
            }
            int result = comparator.compare(alphaObject, betaObject);
            if (result != 0) return result;
            if (alphaIndex != -1 && betaIndex != -1) return alphaIndex - betaIndex;
            return 0;
        }
    }
    
    /**
     * A comparator that takes an indexed node, and compares the index of that node.
     */
    private class ElementRawOrderComparator implements Comparator {
        
        private ElementRawOrderComparator() {
            super();
        }
        
        /**
         * Compares the alpha object to the beta object by their indices.
         */
        public int compare(Object alpha, Object beta) {
            try {
                Element alphaTreeNode = (Element)(Element)alpha;
                Element betaTreeNode = (Element)(Element)beta;
                int alphaIndex = unsorted.indexOfNode(alphaTreeNode, ALL_COLORS);
                int betaIndex = unsorted.indexOfNode(betaTreeNode, ALL_COLORS);
                return alphaIndex - betaIndex;
            } catch (ClassCastException e) {
                System.out.println(alpha.getClass());
                System.out.println(beta.getClass());
                throw e;
            }
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public Iterator iterator() {
        return new SortedListIterator();
    }
    
    /**
     * The fast iterator for SortedList
     */
    private class SortedListIterator implements Iterator {
        
        private SortedListIterator() {
            super();
        }
        
        /**
         * the SimpleTreeIterator to use to move across the tree 
         */
        private SimpleTreeIterator treeIterator = new SimpleTreeIterator(sorted);
        
        /**
         * Returns true iff there are more value to iterate on by caling next()
         */
        public boolean hasNext() {
            return treeIterator.hasNext();
        }
        
        /**
         * Returns the next value in the iteration.
         */
        public Object next() {
            treeIterator.next();
            Element unsortedNode = (Element)treeIterator.value();
            return source.get(unsorted.indexOfNode(unsortedNode, ALL_COLORS));
        }
        
        /**
         * Removes the last value returned by this iterator.
         */
        public void remove() {
            int indexToRemove = treeIterator.index();
            SortedList.this.source.remove(getSourceIndex(indexToRemove));
            treeIterator = new SimpleTreeIterator(sorted, indexToRemove, ALL_COLORS);
        }
    }
}
