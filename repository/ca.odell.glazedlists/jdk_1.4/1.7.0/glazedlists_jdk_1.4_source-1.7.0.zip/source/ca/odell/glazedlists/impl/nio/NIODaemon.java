package ca.odell.glazedlists.impl.nio;

import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.io.*;
import java.util.logging.*;

/**
 * An event queue of I/O events and a thread to run them on.
 */
public final class NIODaemon implements Runnable {
    
    public NIODaemon() {
        super();
    }
    
    /**
     * logging 
     */
    private static Logger logger = Logger.getLogger(NIODaemon.class.toString());
    
    /**
     * asynch queue of tasks to execute 
     */
    private List pendingRunnables = new ArrayList();
    
    /**
     * the only thread that shall access the network resources of this manager 
     */
    private Thread ioThread = null;
    
    /**
     * the selector to awaken when necessary 
     */
    private Selector selector;
    
    /**
     * whether the connection manager shall shut down 
     */
    private boolean keepRunning = false;
    
    /**
     * whom to handle incoming connections 
     */
    private NIOServer server = null;
    
    /**
     * Starts the NIODaemon.
     */
    public synchronized void start() throws IOException {
        if (ioThread != null) throw new IllegalStateException();
        selector = Selector.open();
        keepRunning = true;
        ioThread = new Thread(this, "GlazedLists nio");
        ioThread.start();
    }
    
    /**
     * Continuously selects a connection which needs servicing and services it.
     */
    public void run() {
        List toExecute = new ArrayList();
        SelectAndHandle selectAndHandle = new SelectAndHandle(this);
        while (keepRunning) {
            synchronized (this) {
                toExecute.addAll(pendingRunnables);
                toExecute.add(selectAndHandle);
                pendingRunnables.clear();
            }
            for (Iterator i = toExecute.iterator(); keepRunning && i.hasNext(); ) {
                Runnable runnable = (Runnable)(Runnable)i.next();
                i.remove();
                try {
                    runnable.run();
                } catch (RuntimeException e) {
                    logger.log(Level.SEVERE, "Failure processing I/O, continuing", e);
                }
            }
        }
        synchronized (this) {
            pendingRunnables.clear();
            selector = null;
            ioThread = null;
            keepRunning = false;
        }
    }
    
    /**
     * Tests whether this connection manager has started.
     */
    public synchronized boolean isRunning() {
        return (ioThread != null);
    }
    
    /**
     * Tests whether the current thread is the network thread.
     */
    public synchronized boolean isNetworkThread() {
        return Thread.currentThread() == ioThread;
    }
    
    /**
     * Wake up the CTP thread so that it may process pending events.
     */
    private void wakeUp() {
        selector.wakeup();
    }
    
    /**
     * Runs the specified task on the NIODaemon thread.
     */
    public void invokeAndWait(Runnable runnable) {
        if (!isRunning()) throw new IllegalStateException();
        if (isNetworkThread()) {
            runnable.run();
        } else {
            BlockingRunnable blockingRunnable = new BlockingRunnable(runnable);
            synchronized (blockingRunnable) {
                synchronized (this) {
                    pendingRunnables.add(blockingRunnable);
                }
                wakeUp();
                try {
                    blockingRunnable.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException("Wait interrupted " + e.getMessage());
                }
                RuntimeException problem = blockingRunnable.getInvocationTargetException();
                if (problem != null) throw problem;
            }
        }
    }
    
    /**
     * Runs the specified task the next time the NIODaemon thread has a chance.
     */
    public void invokeLater(Runnable runnable) {
        synchronized (this) {
            if (!isRunning()) throw new IllegalStateException();
            pendingRunnables.add(runnable);
            wakeUp();
        }
    }
    
    /**
     * Stops the NIODaemon.
     */
    public void stop() {
        invokeAndWait(new Shutdown(this));
        invokeAndWait(new Stop());
    }
    
    /**
     * Stops the server after it has been shut down.
     */
    private class Stop implements Runnable {
        
        private Stop() {
            super();
        }
        
        public void run() {
            if (selector.keys().size() != 0) {
                logger.warning("Server stopping with " + selector.keys().size() + " active connections");
            } else {
                logger.info("Server stopping with " + selector.keys().size() + " active connections");
            }
            keepRunning = false;
        }
    }
    
    /**
     * Gets the selector that this NIODaemon manages.
     */
    public Selector getSelector() {
        return selector;
    }
    
    /**
     * Configure this NIODaemon to use the specified server handler for acceptable
     * selection keys.
     */
    public void setServer(NIOServer server) {
        this.server = server;
    }
    
    public NIOServer getServer() {
        return server;
    }
}
