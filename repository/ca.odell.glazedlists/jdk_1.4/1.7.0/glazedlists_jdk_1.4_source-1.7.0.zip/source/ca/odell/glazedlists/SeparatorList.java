package ca.odell.glazedlists;

import ca.odell.glazedlists.impl.Grouper;
import ca.odell.glazedlists.impl.adt.*;
import ca.odell.glazedlists.impl.adt.barcode2.SimpleTree;
import ca.odell.glazedlists.impl.adt.barcode2.Element;
import ca.odell.glazedlists.impl.adt.barcode2.SimpleTreeIterator;
import ca.odell.glazedlists.event.ListEvent;
import java.util.Comparator;
import java.util.List;
import java.util.Collections;

/**
 * A list that adds separator objects before each group of elements.
 *
 * <p><strong>Warning:</strong> this class won't work very well with generics
 * because separators are mixed in, which will be a different class than the
 * other list elements.
 *
 * <p><strong>Developer Preview</strong> this class is still under heavy development
 * and subject to API changes. It's also really slow at the moment and won't scale
 * to lists of size larger than a hundred or so efficiently.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SeparatorList extends TransformedList {
    
    /**
     * delegate to an inner class to insert the separators 
     */
    private SeparatorInjectorList separatorSource;
    private static final Object SEPARATOR = Barcode.BLACK;
    private static final Object SOURCE_ELEMENT = Barcode.WHITE;
    
    /**
     * how many elements before we get a separator, such as 1 or 2 
     */
    private int minimumSizeForSeparator;
    
    /**
     * manage collapsed elements 
     */
    private Barcode collapsedElements;
    
    /**
     * Create a {@link SeparatorList}...
     */
    public SeparatorList(EventList source, Comparator comparator, int minimumSizeForSeparator, int defaultLimit) {
        super(new SeparatorInjectorList(new SortedList(source, comparator), comparator, defaultLimit));
        this.separatorSource = (SeparatorInjectorList)(SeparatorList.SeparatorInjectorList)super.source;
        this.minimumSizeForSeparator = minimumSizeForSeparator;
        rebuildCollapsedElements();
        this.separatorSource.addListEventListener(this);
    }
    
    /**
     * Rebuild the entire collapsed elements barcode.
     */
    private void rebuildCollapsedElements() {
        collapsedElements = new Barcode();
        collapsedElements.addBlack(0, separatorSource.size());
        int groupCount = separatorSource.insertedSeparators.colourSize(SEPARATOR);
        for (int i = 0; i < groupCount; i++) {
            updateGroup(i, groupCount, false);
        }
    }
    
    /**
     * {@inheritDoc} 
     */
    public int size() {
        return collapsedElements.colourSize(Barcode.BLACK);
    }
    
    /**
     * {@inheritDoc} 
     */
    protected int getSourceIndex(int mutationIndex) {
        return collapsedElements.getIndex(mutationIndex, Barcode.BLACK);
    }
    
    /**
     * Set the {@link Comparator} used to determine how elements are split
     * into groups.
     *
     * <p>Performance Note: sorting will take <code>O(N * Log N)</code> time.
     *
     * <p><strong><font color="#FF0000">Warning:</font></strong> This method is
     * thread ready but not thread safe. See {@link EventList} for an example
     * of thread safe code.
     */
    public void setComparator(Comparator comparator) {
        updates.beginEvent(false);
        updates.addDelete(0, size() - 1);
        SortedList sortedList = (SortedList)(SortedList)separatorSource.source;
        sortedList.setComparator(comparator);
        rebuildCollapsedElements();
        updates.addInsert(0, size() - 1);
        updates.commitEvent();
    }
    
    /**
     * Go from the current group (assumed to be black) to the next black group
     * to follow. This works by finding a white follower, then a black follower
     * of that one.
     *
     * @return <code>true</code> if the next group was found, or <code>false</code>
     *      if there was no such group and the iterator is now in an unspecified
     *      location, not necessarily the end of the barcode.
     */
    private static boolean nextBlackGroup(BarcodeIterator iterator) {
        if (!iterator.hasNextWhite()) return false;
        iterator.nextWhite();
        if (!iterator.hasNextBlack()) return false;
        iterator.nextBlack();
        return true;
    }
    
    /**
     * {@inheritDoc} 
     */
    public void listChanged(ListEvent listChanges) {
        updates.beginEvent(true);
        if (listChanges.isReordering()) {
            boolean canReorder = true;
            for (SimpleTreeIterator i = new SimpleTreeIterator(separatorSource.separators); i.hasNext(); ) {
                i.next();
                Element node = i.node();
                int limit = ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).getLimit();
                if (limit == 0) continue;
                if (limit >= separatorSource.size()) continue;
                if (limit >= ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).size()) continue;
                canReorder = false;
                break;
            }
            if (canReorder) {
                int[] previousIndices = listChanges.getReorderMap();
                int[] reorderMap = new int[collapsedElements.colourSize(Barcode.BLACK)];
                BarcodeIterator i = collapsedElements.iterator();
                int groupStartSourceIndex = 0;
                while (true) {
                    boolean newGroupFound;
                    int groupEndSourceIndex;
                    int leadingCollapsedElements;
                    if (i.hasNextWhite()) {
                        i.nextWhite();
                        groupEndSourceIndex = i.getIndex();
                        newGroupFound = true;
                        leadingCollapsedElements = i.getWhiteIndex();
                    } else {
                        newGroupFound = false;
                        groupEndSourceIndex = collapsedElements.size();
                        leadingCollapsedElements = collapsedElements.whiteSize();
                    }
                    for (int j = groupStartSourceIndex; j < groupEndSourceIndex; j++) {
                        reorderMap[j - leadingCollapsedElements] = previousIndices[j] - leadingCollapsedElements;
                    }
                    if (newGroupFound && i.hasNextBlack()) {
                        i.nextBlack();
                        groupStartSourceIndex = i.getIndex();
                    } else {
                        break;
                    }
                }
                updates.reorder(reorderMap);
            } else {
                int size = collapsedElements.colourSize(Barcode.BLACK);
                if (size > 0) {
                    updates.addDelete(0, size - 1);
                    updates.addInsert(0, size - 1);
                }
            }
        } else {
            int groupCount = separatorSource.insertedSeparators.colourSize(SEPARATOR);
            while (listChanges.next()) {
                int changeIndex = listChanges.getIndex();
                int changeType = listChanges.getType();
                if (changeType == ListEvent.INSERT) {
                    collapsedElements.add(changeIndex, Barcode.BLACK, 1);
                    int viewIndex = collapsedElements.getColourIndex(changeIndex, Barcode.BLACK);
                    updates.addInsert(viewIndex);
                } else if (changeType == ListEvent.UPDATE) {
                    if (collapsedElements.get(changeIndex) == Barcode.BLACK) {
                        int viewIndex = collapsedElements.getColourIndex(changeIndex, Barcode.BLACK);
                        updates.addUpdate(viewIndex);
                    }
                } else if (changeType == ListEvent.DELETE) {
                    Object oldColor = collapsedElements.get(changeIndex);
                    if (oldColor == Barcode.BLACK) {
                        int viewIndex = collapsedElements.getColourIndex(changeIndex, Barcode.BLACK);
                        updates.addDelete(viewIndex);
                    }
                    collapsedElements.remove(changeIndex, 1);
                }
            }
            listChanges.reset();
            while (listChanges.next()) {
                int changeIndex = listChanges.getIndex();
                int changeType = listChanges.getType();
                if (changeType == ListEvent.INSERT) {
                    int group = separatorSource.insertedSeparators.getColourIndex(changeIndex, true, SEPARATOR);
                    updateGroup(group, groupCount, true);
                } else if (changeType == ListEvent.UPDATE) {
                    int group = separatorSource.insertedSeparators.getColourIndex(changeIndex, true, SEPARATOR);
                    if (group > 0) updateGroup(group - 1, groupCount, true);
                    updateGroup(group, groupCount, true);
                    if (group < groupCount - 1) updateGroup(group + 1, groupCount, true);
                } else if (changeType == ListEvent.DELETE) {
                    if (changeIndex < separatorSource.insertedSeparators.size()) {
                        int group = separatorSource.insertedSeparators.getColourIndex(changeIndex, true, SEPARATOR);
                        updateGroup(group, groupCount, true);
                    }
                }
            }
        }
        updates.commitEvent();
    }
    
    /**
     * Update all elements in the specified group. We need to refine this method
     * since currently it does a linear scan through the group's elements, and
     * that just won't do for performance requirements.
     */
    private void updateGroup(int group, int groupCount, boolean fireEvents) {
        Separator separator = (SeparatorList.Separator)separatorSource.separators.get(group).get();
        int limit = separator.getLimit();
        int separatorStart = separatorSource.insertedSeparators.getIndex(group, SEPARATOR);
        int nextGroup = group + 1;
        int separatorEnd = nextGroup == groupCount ? separatorSource.insertedSeparators.size() : separatorSource.insertedSeparators.getIndex(nextGroup, SEPARATOR);
        int size = separatorEnd - separatorStart - 1;
        if (size < minimumSizeForSeparator) {
            setVisible(separatorStart, Barcode.WHITE, fireEvents);
            for (int i = separatorStart + 1; i < separatorEnd; i++) {
                setVisible(i, Barcode.BLACK, fireEvents);
            }
        } else {
            setVisible(separatorStart, Barcode.BLACK, fireEvents);
            for (int i = separatorStart + 1; i < separatorEnd; i++) {
                boolean withinLimit = i - separatorStart <= limit;
                setVisible(i, withinLimit ? Barcode.BLACK : Barcode.WHITE, fireEvents);
            }
        }
    }
    
    /**
     * Update the visible state of the specified element.
     */
    private void setVisible(int index, Object colour, boolean fireEvents) {
        Object previousColour = collapsedElements.get(index);
        if (colour == previousColour) {
            return;
        } else if (colour == Barcode.WHITE) {
            int viewIndex = collapsedElements.getColourIndex(index, Barcode.BLACK);
            if (fireEvents) updates.addDelete(viewIndex);
            collapsedElements.set(index, Barcode.WHITE, 1);
        } else if (colour == Barcode.BLACK) {
            collapsedElements.set(index, Barcode.BLACK, 1);
            int viewIndex = collapsedElements.getColourIndex(index, Barcode.BLACK);
            if (fireEvents) updates.addInsert(viewIndex);
        } else {
            throw new IllegalArgumentException();
        }
    }
    
    /**
     * A separator heading the elements of a group.
     */
    public interface Separator {
        
        /**
         * Get the maximum number of elements in this group to show.
         */
        public int getLimit();
        
        /**
         * Set the maximum number of elements in this group to show. This is
         * useful to collapse a group (limit of 0), cap the elements of a group
         * (limit of 5) or reverse those actions.
         *
         * <p>This method requires the write lock of the {@link SeparatorList} to be
         * held during invocation.
         */
        public void setLimit(int limit);
        
        /**
         * Get the {@link List} of all elements in this group.
         *
         * <p>This method requires the read lock of the {@link SeparatorList}
         * to be held during invocation.
         */
        public List getGroup();
        
        /**
         * A convenience method to get the first element from this group. This
         * is useful to render the separator's name.
         */
        public Object first();
        
        /**
         * A convenience method to get the number of elements in this group. This
         * is useful to render the separator.
         */
        public int size();
    }
    
    /**
     * This inner class handles the insertion of separators
     * as a separate transformation from the hiding of separators
     * and collapsed elements.
     */
    private static class SeparatorInjectorList extends TransformedList {
        
        /**
         * the grouping service manages finding where to insert groups 
         */
        private final Grouper grouper;
        
        /**
         * The separators list is black for separators, white for
         * everything else.
         *
         * <p>The following demonstrates the layout of the barcode for the
         * given source list:
         * <pre><code>
         *           INDICES 0         1         2
         *                   012345678901234567890
         *       SOURCE LIST AAAABBBCCCDEFF
         *   GROUPER BARCODE X___X__X__XXX_
         * SEPARATOR BARCODE X____X___X___X_X_X__
         * </pre></code>
         *
         * <p>To read this structure:
         * <li>the grouper barcode is an "X" for the first element in each
         *     group (called uniques), and an "_" for the following
         *     elements (called duplicates).
         * <li>the separator barcode is very similar to the grouper barcode.
         *     In this barcode, there is an "X" for each separator and an "_"
         *     for each element in the source list. We use the structure of the
         *     grouper barcode to derive and maintain the separator barcode.
         *
         * <p>When accessing elements, the separator barcode is queried. If it
         * holds an "X", the element is a separator and that separator is returned.
         * Otherwise if it is an "_", the corresponding source index is obtained
         * (by removing the number of preceding "X" elements) and the element is
         * retrieved from the source list.
         */
        private Barcode insertedSeparators;
        
        /**
         * a list of {@link Separator}s, one for each separator in the list 
         */
        private SimpleTree separators;
        
        /**
         * the number of elements to show in each group, such as 0, 5, or {@link Integer.MAX_VALUE} 
         */
        private int defaultLimit;
        
        /**
         * Create a new {@link UniqueList} that determines groups using the specified
         * {@link Comparator}. Elements that the {@link Comparator} determines are
         * equal will share a common separator.
         *
         * @see GlazedLists#beanPropertyComparator
         */
        public SeparatorInjectorList(SortedList source, Comparator comparator, int defaultLimit) {
            super(source);
            this.defaultLimit = defaultLimit;
            GrouperClient grouperClient = new GrouperClient();
            this.grouper = new Grouper(source, grouperClient);
            rebuildSeparators();
            source.addListEventListener(this);
        }
        
        /**
         * Statically build the separators data structures.
         */
        private void rebuildSeparators() {
            insertedSeparators = new Barcode();
            separators = new SimpleTree();
            insertedSeparators.add(0, SOURCE_ELEMENT, source.size());
            for (BarcodeIterator i = grouper.getBarcode().iterator(); i.hasNextColour(Grouper.UNIQUE); ) {
                i.nextColour(Grouper.UNIQUE);
                int groupIndex = i.getColourIndex(Grouper.UNIQUE);
                int sourceIndex = i.getIndex();
                insertedSeparators.add(groupIndex + sourceIndex, SEPARATOR, 1);
                Element node = separators.add(groupIndex, new GroupSeparator(), 1);
                ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).setNode(node);
                ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).setLimit(defaultLimit);
            }
            for (int i = 0; i < separators.size(); i++) {
                ((SeparatorList.SeparatorInjectorList.GroupSeparator)separators.get(i).get()).updateCachedValues();
            }
        }
        
        /**
         * {@inheritDoc} 
         */
        public Object get(int index) {
            Object type = insertedSeparators.get(index);
            if (type == SEPARATOR) return (Object)separators.get(getSeparatorIndex(index)).get(); else if (type == SOURCE_ELEMENT) return source.get(getSourceIndex(index)); else throw new IllegalStateException();
        }
        
        /**
         * {@inheritDoc} 
         */
        protected int getSourceIndex(int mutationIndex) {
            Object type = insertedSeparators.get(mutationIndex);
            if (type == SEPARATOR) return -1; else if (type == SOURCE_ELEMENT) return insertedSeparators.getColourIndex(mutationIndex, SOURCE_ELEMENT); else throw new IllegalStateException();
        }
        
        protected int getSeparatorIndex(int mutationIndex) {
            Object type = insertedSeparators.get(mutationIndex);
            if (type == SEPARATOR) return insertedSeparators.getColourIndex(mutationIndex, SEPARATOR); else if (type == SOURCE_ELEMENT) return -1; else throw new IllegalStateException();
        }
        
        /**
         * {@inheritDoc} 
         */
        public int size() {
            return insertedSeparators.size();
        }
        
        /**
         * {@inheritDoc} 
         */
        public void listChanged(ListEvent listChanges) {
            SortedList sortedSource = (SortedList)(SortedList)source;
            Comparator sourceComparator = sortedSource.getComparator();
            if (sourceComparator != grouper.getComparator()) {
                grouper.setComparator(sourceComparator);
                rebuildSeparators();
                return;
            }
            updates.beginEvent(true);
            if (listChanges.isReordering()) {
                int[] previousIndices = listChanges.getReorderMap();
                int[] reorderMap = new int[insertedSeparators.size()];
                int groupStartIndex = -1;
                int groupEndIndex = 0;
                int group = -1;
                for (int i = 0; i < previousIndices.length; i++) {
                    if (i == groupEndIndex) {
                        group++;
                        reorderMap[i + group] = i + group;
                        groupStartIndex = groupEndIndex;
                        int nextGroup = group + 1;
                        groupEndIndex = nextGroup < separators.size() ? ((SeparatorList.SeparatorInjectorList.GroupSeparator)separators.get(nextGroup).get()).start() : insertedSeparators.size();
                    }
                    int previousIndex = previousIndices[i];
                    if (previousIndex < groupStartIndex || previousIndex >= groupEndIndex) {
                        throw new IllegalStateException();
                    }
                    reorderMap[i + group + 1] = previousIndex + group + 1;
                }
                updates.reorder(reorderMap);
            } else {
                grouper.listChanged(listChanges);
            }
            for (int i = 0; i < separators.size(); i++) {
                ((SeparatorList.SeparatorInjectorList.GroupSeparator)separators.get(i).get()).updateCachedValues();
            }
            updates.commitEvent();
        }
        
        /**
         * Fire two events, one for the group (the separator) and another for the
         * actual list element.
         */
        private class GrouperClient implements Grouper.Client {
            
            private GrouperClient() {
                super();
            }
            
            public void groupChanged(int index, int groupIndex, int groupChangeType, boolean primary, int elementChangeType) {
                if (groupChangeType == ListEvent.INSERT) {
                    int expandedIndex = index + groupIndex;
                    insertedSeparators.add(expandedIndex, SEPARATOR, 1);
                    updates.addInsert(expandedIndex);
                    Element node = separators.add(groupIndex, new GroupSeparator(), 1);
                    ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).setNode(node);
                    ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).setLimit(defaultLimit);
                } else if (groupChangeType == ListEvent.UPDATE) {
                    int expandedIndex = insertedSeparators.getIndex(groupIndex, SEPARATOR);
                    updates.addUpdate(expandedIndex);
                } else if (groupChangeType == ListEvent.DELETE) {
                    int expandedIndex = insertedSeparators.getIndex(groupIndex, SEPARATOR);
                    insertedSeparators.remove(expandedIndex, 1);
                    updates.addDelete(expandedIndex);
                    Element node = separators.get(groupIndex);
                    separators.remove(node);
                    ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).setNode(null);
                    ((SeparatorList.SeparatorInjectorList.GroupSeparator)node.get()).updateCachedValues();
                    groupIndex--;
                }
                if (elementChangeType == ListEvent.INSERT) {
                    int expandedIndex = index + groupIndex + 1;
                    insertedSeparators.add(expandedIndex, SOURCE_ELEMENT, 1);
                    updates.addInsert(expandedIndex);
                } else if (elementChangeType == ListEvent.UPDATE) {
                    int expandedIndex = index + groupIndex + 1;
                    updates.addUpdate(expandedIndex);
                } else if (elementChangeType == ListEvent.DELETE) {
                    int expandedIndex = index + groupIndex + 1;
                    insertedSeparators.remove(expandedIndex, 1);
                    updates.addDelete(expandedIndex);
                }
                int shiftGroupIndex = groupIndex + 1;
                if (groupChangeType == ListEvent.DELETE && elementChangeType == ListEvent.DELETE && shiftGroupIndex < insertedSeparators.colourSize(SEPARATOR) && shiftGroupIndex < grouper.getBarcode().colourSize(Grouper.UNIQUE)) {
                    int collapsedGroupStartIndex = grouper.getBarcode().getIndex(shiftGroupIndex, Grouper.UNIQUE);
                    int separatorsIndex = insertedSeparators.getIndex(shiftGroupIndex, SEPARATOR);
                    if (collapsedGroupStartIndex + shiftGroupIndex < separatorsIndex) {
                        insertedSeparators.remove(separatorsIndex, 1);
                        updates.addDelete(separatorsIndex);
                        insertedSeparators.add(collapsedGroupStartIndex + shiftGroupIndex, SEPARATOR, 1);
                        updates.addInsert(collapsedGroupStartIndex + shiftGroupIndex);
                        index++;
                    }
                }
            }
        }
        
        /**
         * Implement the {@link Separator} interface in the most natural way.
         */
        private class GroupSeparator implements Separator {
            
            private GroupSeparator() {
                super();
            }
            private int limit = Integer.MAX_VALUE;
            private int size;
            private Object first;
            
            /**
             * The node allows the separator to figure out which
             * group in the overall list its representing.
             */
            private Element node = null;
            
            /**
             * {@inheritDoc} 
             */
            public int getLimit() {
                return limit;
            }
            
            /**
             * {@inheritDoc} 
             */
            public void setLimit(int limit) {
                if (this.limit == limit) return;
                if (node == null) {
                    return;
                }
                this.limit = limit;
                updates.beginEvent();
                int groupIndex = separators.indexOfNode(node, (byte)1);
                int separatorIndex = insertedSeparators.getIndex(groupIndex, SEPARATOR);
                updates.addUpdate(separatorIndex);
                updates.commitEvent();
            }
            
            /**
             * {@inheritDoc} 
             */
            public List getGroup() {
                if (node == null) return Collections.EMPTY_LIST;
                return source.subList(start(), end());
            }
            
            /**
             * {@inheritDoc} 
             */
            public Object first() {
                return first;
            }
            
            /**
             * {@inheritDoc} 
             */
            public int size() {
                return size;
            }
            
            /**
             * Set the {@link IndexedTreeNode} that this {@link Separator} can
             * use to find its index in the overall list of {@link Separator}s;
             */
            public void setNode(Element node) {
                this.node = node;
            }
            
            /**
             * The first index in the source containing an element from this group.
             */
            private int start() {
                if (this.node == null) throw new IllegalStateException();
                int separatorIndex = separators.indexOfNode(node, (byte)1);
                if (separatorIndex == -1) throw new IllegalStateException();
                int groupStartIndex = insertedSeparators.getIndex(separatorIndex, SEPARATOR);
                return groupStartIndex - separatorIndex;
            }
            
            /**
             * The last index in the source containing an element from this group.
             */
            private int end() {
                if (this.node == null) throw new IllegalStateException();
                int nextSeparatorIndex = separators.indexOfNode(node, (byte)1) + 1;
                if (nextSeparatorIndex == 0) throw new IllegalStateException();
                int nextGroupStartIndex = nextSeparatorIndex == insertedSeparators.colourSize(SEPARATOR) ? insertedSeparators.size() : insertedSeparators.getIndex(nextSeparatorIndex, SEPARATOR);
                return nextGroupStartIndex - nextSeparatorIndex;
            }
            
            /**
             * Update the cached {@link #first()} and {@link #size()} values, so that they
             * can be retrieved without the {@link SeparatorList}'s lock.
             */
            public void updateCachedValues() {
                if (node != null) {
                    int start = start();
                    int end = end();
                    this.first = source.get(start);
                    this.size = end - start;
                } else {
                    this.first = null;
                    this.size = 0;
                }
            }
            
            /**
             * {@inheritDoc} 
             */
            public String toString() {
                return "" + size() + " elements starting with \"" + first() + "\"";
            }
        }
    }
}
