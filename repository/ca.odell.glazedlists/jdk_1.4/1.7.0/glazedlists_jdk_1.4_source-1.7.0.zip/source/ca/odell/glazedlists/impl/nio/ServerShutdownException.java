package ca.odell.glazedlists.impl.nio;

import java.util.*;
import java.nio.*;
import java.nio.channels.*;
import java.net.*;
import java.io.*;
import java.util.logging.*;

/**
 * The reason a connection is closed when the server is shutdown.
 */
class ServerShutdownException extends Exception {
    
    /**
     * Creates a new ServerShutdownException.
     */
    public ServerShutdownException() {
        super("Server shutting down");
    }
}
