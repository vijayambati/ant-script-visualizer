package ca.odell.glazedlists.impl.adt;

import java.util.*;

/**
 * A SparseListNode models a node in an SparseList.  This class
 * does the bulk of the heavy lifting for SparseList.
 *
 * @author <a href="mailto:kevin@swank.ca">Kevin Maltby</a>
 *
 */
public final class SparseListNode {
    
    /**
     * the parent node 
     */
    private SparseListNode parent;
    
    /**
     * the tree that this node is a member of 
     */
    private SparseList host;
    
    /**
     * the left and right child nodes 
     */
    private SparseListNode left = null;
    private SparseListNode right = null;
    
    /**
     * the size of the left subtree and right subtrees including empty space 
     */
    private int totalRightSize = 0;
    private int totalLeftSize = 0;
    
    /**
     * the amount of empty space that preceeds this node 
     */
    private int emptySpace = 0;
    
    /**
     * the height of this subtree 
     */
    private int height = 1;
    
    /**
     * the value at this node 
     */
    private Object value = null;
    
    /**
     * Creates a new SparseListNode with the specified parent node, host tree and value.
     */
    SparseListNode(SparseList host, SparseListNode parent, Object value) {
        super();
        this.host = host;
        this.parent = parent;
        this.value = value;
    }
    
    /**
     * This is a convienience constructor for creating a new SparseListNode
     * with a given value and amount of preceeding empty space.
     */
    SparseListNode(SparseList host, SparseListNode parent, Object value, int emptySpace) {
        this(host, parent, value);
        this.emptySpace = emptySpace;
    }
    
    /**
     * Returns the size of the subtree rooted at this node
     */
    int size() {
        return totalLeftSize + emptySpace + totalRightSize + 1;
    }
    
    /**
     * Inserts a value into the host tree.
     */
    void insert(int index, Object value) {
        int localizedIndex = index - totalLeftSize;
        if (localizedIndex < 0) {
            totalLeftSize++;
            left.insert(index, value);
        } else if (localizedIndex > emptySpace) {
            totalRightSize++;
            right.insert(localizedIndex - emptySpace - 1, value);
        } else if (localizedIndex < emptySpace) {
            emptySpace -= localizedIndex;
            totalLeftSize += localizedIndex + 1;
            if (left == null) {
                left = new SparseListNode(host, this, value, localizedIndex);
                ensureAVL();
            } else {
                left.insertAtEnd(value, localizedIndex);
            }
        } else {
            insertAtThisNode(value);
        }
    }
    
    /**
     * Inserts a value into the host tree at an index where a value already
     * exists.  This will offset the current node's value by 1.
     */
    private void insertAtThisNode(Object value) {
        SparseListNode replacement = new SparseListNode(host, parent, value, emptySpace);
        emptySpace = 0;
        replacement.height = height;
        height = 1;
        replacement.totalRightSize = totalRightSize + 1;
        replacement.left = left;
        if (left != null) {
            replacement.left.parent = replacement;
            replacement.totalLeftSize = totalLeftSize;
            totalLeftSize = 0;
            left = null;
        }
        if (parent == null) host.setRootNode(replacement); else parent.replace(this, replacement);
        if (right == null) {
            parent = replacement;
            replacement.right = this;
            replacement.ensureAVL();
        } else {
            replacement.right = right;
            replacement.right.parent = replacement;
            totalRightSize = 0;
            right = null;
            replacement.right.moveToSmallest(this);
        }
    }
    
    /**
     * Inserts a value at the end of the tree rooted at this.
     */
    void insertAtEnd(Object value, int leadingNulls) {
        totalRightSize += leadingNulls + 1;
        if (right != null) right.insertAtEnd(value, leadingNulls); else {
            right = new SparseListNode(host, this, value, leadingNulls);
            ensureAVL();
        }
    }
    
    /**
     * Inserts multiple null values as empty space in the host tree.
     */
    void insertEmptySpace(int index, int length) {
        int localizedIndex = index - totalLeftSize;
        if (localizedIndex < 0) {
            totalLeftSize += length;
            left.insertEmptySpace(index, length);
        } else if (localizedIndex > emptySpace) {
            totalRightSize += length;
            right.insertEmptySpace(localizedIndex - emptySpace - 1, length);
        } else {
            emptySpace += length;
        }
    }
    
    /**
     * Moves a given node to be the smallest node in the subtree rooted at
     * this.
     */
    private void moveToSmallest(SparseListNode movingNode) {
        totalLeftSize += movingNode.emptySpace + 1;
        if (left != null) {
            left.moveToSmallest(movingNode);
        } else {
            movingNode.parent = this;
            left = movingNode;
            ensureAVL();
        }
    }
    
    /**
     * Gets the index of the value in this node.  This is NOT the index of the
     * first null indexed by this node.
     */
    public int getIndex() {
        if (parent != null) return parent.getIndex(this) + totalLeftSize + emptySpace;
        return totalLeftSize + emptySpace;
    }
    
    private int getIndex(SparseListNode child) {
        if (child == left) {
            if (parent != null) return parent.getIndex(this);
            return 0;
        } else {
            if (parent != null) return parent.getIndex(this) + totalLeftSize + emptySpace + 1;
            return totalLeftSize + emptySpace + 1;
        }
    }
    
    /**
     * Gets the node with the given index, or null if that index is empty.
     */
    SparseListNode getNode(int index) {
        int localizedIndex = index - totalLeftSize;
        if (localizedIndex < 0) return left.getNode(index); else if (localizedIndex > emptySpace) return right.getNode(localizedIndex - emptySpace - 1); else if (localizedIndex < emptySpace) return null; else return this;
    }
    
    /**
     * Gets the value of this node.
     */
    public Object getValue() {
        return value;
    }
    
    /**
     * Sets the value of this node and returns the replaced value.
     * If the value is set to null, this node  will be removed from
     * the tree and clear() will be called.
     */
    public Object setValue(Object value) {
        if (value != null) {
            Object oldValue = this.value;
            this.value = value;
            return oldValue;
        } else {
            emptySpace++;
            return unlink();
        }
    }
    
    /**
     * Sets the value of the node at a given index.
     */
    Object set(int index, Object value) {
        int localizedIndex = index - totalLeftSize;
        if (localizedIndex < 0) {
            return left.set(index, value);
        } else if (localizedIndex > emptySpace) {
            return right.set(localizedIndex - emptySpace - 1, value);
        } else if (localizedIndex < emptySpace) {
            if (value == null) return null;
            emptySpace--;
            insert(index, value);
            return null;
        } else {
            return setValue(value);
        }
    }
    
    /**
     * Removes and returns the value at the given index.
     */
    Object remove(int index) {
        int localizedIndex = index - totalLeftSize;
        if (localizedIndex < 0) {
            totalLeftSize--;
            return left.remove(index);
        } else if (localizedIndex > emptySpace) {
            totalRightSize--;
            return right.remove(localizedIndex - emptySpace - 1);
        } else if (localizedIndex < emptySpace) {
            emptySpace--;
            return null;
        } else {
            return unlink();
        }
    }
    
    /**
     * Unlinks this node from the tree and clears it.
     */
    private Object unlink() {
        int index = -1;
        SparseListNode replacement = null;
        boolean isLeftChild = false;
        if (right != null && left != null) {
            return unlinkFromTwoChildren();
        } else if (right != null) {
            replacement = right;
            replacement.parent = parent;
            replacement.emptySpace += emptySpace;
        } else {
            if (left != null) {
                replacement = left;
                replacement.parent = parent;
            } else replacement = null;
            if (parent == null) index = emptySpace == 0 ? -1 : host.size(); else if (parent.left == this) {
                isLeftChild = true;
                parent.emptySpace += emptySpace;
                parent.totalLeftSize -= emptySpace;
            } else if (emptySpace != 0) index = getIndex() - emptySpace;
        }
        if (parent != null) {
            parent.replace(this, replacement);
            parent.ensureAVL();
        } else {
            host.setRootNode(replacement);
        }
        if (index != -1) {
            if (parent != null) parent.prepareForReinsert(isLeftChild, emptySpace);
            host.addNulls(index, emptySpace);
        }
        return clear();
    }
    
    /**
     * Unlinks this node in the special case where this node has both
     * a left and right child.
     */
    private Object unlinkFromTwoChildren() {
        SparseListNode replacement = right.pruneSmallestChild();
        SparseListNode repParent = replacement.parent;
        replacement.emptySpace += emptySpace;
        replacement.height = height;
        replacement.left = left;
        replacement.left.parent = replacement;
        replacement.totalLeftSize = totalLeftSize;
        replacement.parent = parent;
        if (parent == null) host.setRootNode(replacement); else parent.replace(this, replacement);
        if (repParent == this) replacement.ensureAVL(); else {
            repParent.left = replacement.right;
            if (repParent.left != null) repParent.left.parent = repParent;
            repParent.totalLeftSize = replacement.totalRightSize;
            replacement.right = right;
            replacement.right.parent = replacement;
            replacement.totalRightSize = replacement.right.size();
            repParent.ensureAVL();
        }
        return clear();
    }
    
    /**
     * Prunes and returns the smallest child of the subtree rooted at this.
     * Tree references are maintained out of necessity of the calling method,
     * but sizes in the subtree are corrected accordingly.
     */
    private SparseListNode pruneSmallestChild() {
        if (left != null) {
            SparseListNode prunedNode = left.pruneSmallestChild();
            totalLeftSize -= prunedNode.emptySpace + 1;
            return prunedNode;
        } else return this;
    }
    
    /**
     * Prepares this tree to have length nulls reinserted.  This method
     * recurses up the tree altering sizes so that the tree is in a
     * consistent state for addNulls() to be called on the host tree.
     */
    private void prepareForReinsert(boolean leftChild, int length) {
        if (leftChild) totalLeftSize -= length; else totalRightSize -= length;
        if (parent != null) parent.prepareForReinsert(parent.left == this, length); else host.treeSizeChanged();
    }
    
    /**
     * Clears this node and returns the value it had.
     */
    private Object clear() {
        left = null;
        totalLeftSize = 0;
        right = null;
        totalRightSize = 0;
        host = null;
        parent = null;
        emptySpace = 0;
        height = -1;
        Object thisValue = value;
        value = null;
        return thisValue;
    }
    
    /**
     * Ensures that the tree satisfies the AVL property.  It is sufficient to
     * recurse up the tree only as long as height recalculations are needed.
     * As such, this method is intended to be called only on a node whose height
     * may be out of sync due to an insertion or deletion.  For example, calling
     * this method on a leaf node will not guarantee that this tree satisfies the
     * AVL property as it will not recurse.
     */
    private void ensureAVL() {
        int oldHeight = height;
        recalculateHeight();
        avlRotate();
        if (height != oldHeight && parent != null) parent.ensureAVL();
    }
    
    /**
     * Replaces a given child with the replacement node
     */
    private void replace(SparseListNode child, SparseListNode replacement) {
        if (child == left) left = replacement; else right = replacement;
    }
    
    /**
     * Recalculates the cached height at this level.
     */
    private void recalculateHeight() {
        int leftHeight = left == null ? 0 : left.height;
        int rightHeight = right == null ? 0 : right.height;
        height = 1 + Math.max(leftHeight, rightHeight);
    }
    
    /**
     * Determines if AVL rotations are required and performs them if they are.
     */
    private void avlRotate() {
        int leftHeight = (left != null ? left.height : 0);
        int rightHeight = (right != null ? right.height : 0);
        if (leftHeight - rightHeight >= 2) {
            int leftLeftHeight = (left.left != null ? left.left.height : 0);
            int leftRightHeight = (left.right != null ? left.right.height : 0);
            if (leftRightHeight > leftLeftHeight) left.rotateRight();
            rotateLeft();
        } else if (rightHeight - leftHeight >= 2) {
            int rightLeftHeight = (right.left != null ? right.left.height : 0);
            int rightRightHeight = (right.right != null ? right.right.height : 0);
            if (rightLeftHeight > rightRightHeight) right.rotateLeft();
            rotateRight();
        }
    }
    
    /**
     * AVL-Rotates this subtree with its left child.
     */
    private void rotateLeft() {
        SparseListNode replacement = left;
        left = replacement.right;
        totalLeftSize = replacement.totalRightSize;
        if (replacement.right != null) replacement.right.parent = this;
        replacement.right = this;
        replacement.totalRightSize = size();
        if (parent != null) parent.replace(this, replacement); else host.setRootNode(replacement);
        replacement.parent = parent;
        parent = replacement;
        recalculateHeight();
        replacement.height = 0;
    }
    
    /**
     * AVL-Rotates this subtree with its right child.
     */
    private void rotateRight() {
        SparseListNode replacement = right;
        right = replacement.left;
        totalRightSize = replacement.totalLeftSize;
        if (replacement.left != null) replacement.left.parent = this;
        replacement.left = this;
        replacement.totalLeftSize = size();
        if (parent != null) parent.replace(this, replacement); else host.setRootNode(replacement);
        replacement.parent = parent;
        parent = replacement;
        recalculateHeight();
        replacement.height = 0;
    }
    
    /**
     * For debugging purposes.
     */
    public String toString() {
        return "[ " + left + " <" + emptySpace + "> " + value + " <" + height + "> " + right + " ]";
    }
    
    /**
     * Corrects all the cached sizes up the tree by the given offsets starting
     * from this so an Iterator can perform a fast remove.
     */
    private void correctSizes(int sizeChange) {
        if (parent != null) {
            if (parent.left == this) totalLeftSize += sizeChange; else totalRightSize += sizeChange;
            parent.correctSizes(sizeChange);
        } else host.treeSizeChanged();
    }
    
    /**
     * A specialized Iterator that will significantly outperform the default
     * one provided by AbstractList when acting on this ADT.
     */
    static final class SparseListIterator implements Iterator {
        
        /**
         * the current SparseListNode being inspected 
         */
        private SparseListNode currentNode = null;
        
        /**
         * the number of times the current node has been requested 
         */
        private int timesRequested = -1;
        
        /**
         * a reference to the SparseList for removal of trailing nulls 
         */
        private SparseList sparseList = null;
        
        /**
         * the size of the actual tree within the SparseList
         */
        private int treeSize = 0;
        
        /**
         * the size of the list 
         */
        private int size = 0;
        
        /**
         * the current index being inspected 
         */
        private int index = -1;
        
        /**
         * Creates a new Iterator that is optimized for SparseLists.
         */
        SparseListIterator(SparseList sparseList, SparseListNode root) {
            super();
            if (root != null) {
                this.treeSize = root.size();
                currentNode = root;
                while (currentNode.left != null) {
                    currentNode = currentNode.left;
                }
            }
            this.sparseList = sparseList;
            this.size = sparseList.size();
        }
        
        /**
         * Returns whether or not there are more values in the SparseList to
         * iterate over.
         */
        public boolean hasNext() {
            if (index >= treeSize - 1 && index == size - 1) {
                return false;
            }
            return true;
        }
        
        /**
         * Gets the next value in this SparseList.
         */
        public Object next() {
            timesRequested++;
            index++;
            if (currentNode == null) {
                if (index < size) {
                    return null;
                } else {
                    throw new NoSuchElementException();
                }
            } else if (timesRequested > currentNode.emptySpace) {
                if (index < treeSize) {
                    findNextNode();
                    timesRequested = 0;
                } else {
                    if (index < size) {
                        return null;
                    } else {
                        throw new NoSuchElementException();
                    }
                }
            }
            if (timesRequested < currentNode.emptySpace) {
                return null;
            } else if (timesRequested == currentNode.emptySpace) {
                return currentNode.value;
            } else {
                throw new IllegalStateException();
            }
        }
        
        /**
         * Removes the current value at the Iterator from the SparseList.
         *
         * @throws UnsupportedOperationException This feature is not yet implemented.
         *
         */
        public void remove() {
            if (timesRequested == -1) {
                throw new IllegalStateException("Cannot remove() without a prior call to next()");
            } else if (currentNode == null || index >= treeSize) {
                sparseList.remove(index);
            } else if (timesRequested < currentNode.emptySpace) {
                currentNode.correctSizes(-1);
                currentNode.emptySpace--;
            } else if (timesRequested == currentNode.emptySpace) {
                currentNode.correctSizes(-1);
                SparseListNode nodeToRemove = currentNode;
                findNextNode();
                timesRequested = -1;
                nodeToRemove.unlink();
            } else {
                throw new IllegalStateException();
            }
        }
        
        /**
         * Finds the next node in the tree.
         */
        private void findNextNode() {
            if (currentNode.right != null) {
                currentNode = currentNode.right;
                while (currentNode.left != null) {
                    currentNode = currentNode.left;
                }
            } else if (currentNode.parent.left == currentNode) {
                currentNode = currentNode.parent;
            } else if (currentNode.parent.right == currentNode) {
                while (currentNode.parent.right == currentNode) {
                    currentNode = currentNode.parent;
                }
                currentNode = currentNode.parent;
            } else {
                throw new IllegalStateException();
            }
        }
        
        /**
         * Finds the previous node in the tree.
         */
        private void findPreviousNode() {
            throw new UnsupportedOperationException("Not implemented yet.");
        }
        
        public String toString() {
            return "Accessing " + currentNode + " for the " + timesRequested + " time.";
        }
    }
}
