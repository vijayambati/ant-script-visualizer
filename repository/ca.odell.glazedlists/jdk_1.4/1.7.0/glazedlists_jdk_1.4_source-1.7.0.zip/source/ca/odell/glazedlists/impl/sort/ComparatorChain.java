package ca.odell.glazedlists.impl.sort;

import java.util.*;

/**
 * A comparator chain compares objects using a list of Comparators. The
 * first comparison where the objects differ is returned.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public final class ComparatorChain implements Comparator {
    
    /**
     * the comparators to execute in sequence 
     */
    private final Comparator[] comparators;
    
    /**
     * Creates a comparator chain that evaluates the specified comparators in
     * sequence. A defensive copy of the
     *
     * @param comparators a list of objects implementing {@link Comparator}
     */
    public ComparatorChain(List comparators) {
        super();
        this.comparators = (Comparator[])comparators.toArray(new Comparator[comparators.size()]);
    }
    
    /**
     * Compares the two objects with each comparator in sequence.
     */
    public int compare(Object alpha, Object beta) {
        for (int i = 0; i < comparators.length; i++) {
            int compareResult = comparators[i].compare(alpha, beta);
            if (compareResult != 0) return compareResult;
        }
        return 0;
    }
    
    /**
     * Retrieves the {@link Comparator}s composing this
     * <code>ComparatorChain</code>.
     */
    public Comparator[] getComparators() {
        return comparators;
    }
    
    /**
     * A list of comparators are equal only if the lists are equal.
     */
    public boolean equals(Object other) {
        if (!(other instanceof ComparatorChain)) return false;
        final ComparatorChain chainOther = (ComparatorChain)(ComparatorChain)other;
        return Arrays.equals(comparators, chainOther.comparators);
    }
}
