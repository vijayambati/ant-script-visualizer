package ca.odell.glazedlists.impl.adt.barcode2;

import java.util.NoSuchElementException;

/**
 * Iterate through a {@link SimpleTree}, one element at a time.
 *
 * <p>We should consider adding the following enhancements to this class:
 * <li>writing methods, such as <code>set()</code> and <code>remove()</code>.
 * <li>a default color, specified at construction time, that shall always be
 *     used as the implicit parameter to overloaded versions of {@link #hasNext}
 *     and {@link #next}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SimpleTreeIterator {
    int count1;
    private SimpleTree tree;
    private SimpleNode node;
    private int index;
    
    public SimpleTreeIterator(SimpleTree tree) {
        this(tree, 0, (byte)0);
    }
    
    /**
     * Create an iterator starting at the specified index.
     *
     * @param tree the tree to iterate
     * @param nextIndex the index to be returned after calling {@link #next next()}.
     * @param nextIndexColors the colors to interpret nextIndex in terms of
     */
    public SimpleTreeIterator(SimpleTree tree, int nextIndex, byte nextIndexColors) {
        super();
        this.tree = tree;
        if (nextIndex != 0) {
            int currentIndex = nextIndex - 1;
            this.node = (SimpleNode)(SimpleNode)tree.get(currentIndex);
            count1 = currentIndex;
            this.index = count1 - tree.indexOfNode(this.node, (byte)1);
        } else {
            this.node = null;
            this.index = 0;
        }
    }
    
    /**
     * Create a {@link SimpleTreeIterator} exactly the same as this one.
     * The iterators will be backed by the same tree but maintain
     * separate cursors into the tree.
     */
    public SimpleTreeIterator copy() {
        SimpleTreeIterator result = new SimpleTreeIterator(tree);
        result.count1 = this.count1;
        result.node = node;
        result.index = index;
        return result;
    }
    
    /**
     * @return <code>true</code> if there's an element of the specified color in
     *     this tree following the current element.
     */
    public boolean hasNext() {
        if (node == null) {
            return tree.size() > 0;
        } else if (true) {
            return index() < tree.size() - 1;
        } else {
            return index() < tree.size();
        }
    }
    
    /**
     * @return <code>true</code> if there's a node of the specified color in this
     *      tree following the current node.
     */
    public boolean hasNextNode() {
        if (node == null) {
            return tree.size() > 0;
        } else {
            return nodeEndIndex() < tree.size();
        }
    }
    
    /**
     * Step to the next element.
     */
    public void next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        if (node == null) {
            node = tree.firstNode();
            index = 0;
            return;
        } else if (index < 1 - 1) {
            count1++;
            index++;
            return;
        }
        while (true) {
            count1 += 1 - index;
            node = SimpleTree.next(node);
            index = 0;
            break;
        }
    }
    
    /**
     * Step to the next node.
     */
    public void nextNode() {
        if (!hasNextNode()) {
            throw new NoSuchElementException();
        }
        if (node == null) {
            node = tree.firstNode();
            index = 0;
            return;
        }
        while (true) {
            count1 += 1 - index;
            node = SimpleTree.next(node);
            index = 0;
            break;
        }
    }
    
    /**
     * Get the size of the current node, or 0 if it's color doesn't match those
     * specified.
     */
    public int nodeSize() {
        if (true) {
            return 1;
        } else {
            return 0;
        }
    }
    
    /**
     * Expected values for index should be in the range  ( 0, size() - 1 )
     */
    public int index() {
        if (node == null) throw new NoSuchElementException();
        int result = 0;
        result += count1;
        return result;
    }
    
    /**
     * Get the index of the current node's start.
     */
    public int nodeStartIndex() {
        if (node == null) throw new NoSuchElementException();
        int result = 0;
        result += count1;
        if (true) {
            result -= index;
        }
        return result;
    }
    
    /**
     * Get the index of the node immediately following the current. Expected
     * values are in the range ( 1, size() )
     */
    public int nodeEndIndex() {
        if (node == null) throw new NoSuchElementException();
        return nodeStartIndex() + nodeSize();
    }
    
    public Object value() {
        if (node == null) throw new IllegalStateException();
        return node.get();
    }
    
    public Element node() {
        if (node == null) throw new IllegalStateException();
        return node;
    }
}
