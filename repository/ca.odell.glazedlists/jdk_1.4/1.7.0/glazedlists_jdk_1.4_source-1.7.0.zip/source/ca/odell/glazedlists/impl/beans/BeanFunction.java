package ca.odell.glazedlists.impl.beans;

import ca.odell.glazedlists.FunctionList;

/**
 * A {@link FunctionList.Function} that uses a {@link BeanProperty} to produce
 * the result of the function.
 *
 * @author James Lemieux
 */
public class BeanFunction implements FunctionList.Function {
    
    /**
     * The {@link BeanProperty} that is capable of extracting the function's value from source objects. 
     */
    private final BeanProperty property;
    
    /**
     * Create a new JavaBean property comparator that produces its value by
     * extracting a property from source objects. This should be accessed from the
     * {@link ca.odell.glazedlists.GlazedLists GlazedLists} tool factory.
     */
    public BeanFunction(Class beanClass, String propertyName) {
        super();
        this.property = new BeanProperty(beanClass, propertyName, true, false);
    }
    
    /**
     * @inheritDoc 
     */
    public Object evaluate(Object sourceValue) {
        return (Object)this.property.get(sourceValue);
    }
}
