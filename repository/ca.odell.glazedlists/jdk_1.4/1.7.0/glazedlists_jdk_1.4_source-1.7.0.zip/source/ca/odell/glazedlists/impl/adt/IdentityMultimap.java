package ca.odell.glazedlists.impl.adt;

import java.util.List;
import java.util.IdentityHashMap;
import java.util.ArrayList;
import java.util.Collections;

/**
 * A poor man's multimap, used only to reduce the complexity code that deals
 * with these otherwise painful structures.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class IdentityMultimap extends IdentityHashMap {
    
    public IdentityMultimap() {
        super();
    }
    
    public void addValue(Object key, Object value) {
        List values = (List)super.get(key);
        if (values == null) {
            values = new ArrayList(2);
            put(key, values);
        }
        values.add(value);
    }
    
    public Object get(Object x0) {
        Object key = (Object)x0;
        List values = (List)super.get(key);
        return values == null ? Collections.EMPTY_LIST : values;
    }
    
    public int count(Object key) {
        List values = (List)super.get(key);
        return values == null ? 0 : values.size();
    }
    /*missing*/
}
