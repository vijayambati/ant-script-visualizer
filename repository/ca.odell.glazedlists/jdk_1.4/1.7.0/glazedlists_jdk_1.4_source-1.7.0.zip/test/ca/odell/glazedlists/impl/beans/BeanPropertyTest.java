package ca.odell.glazedlists.impl.beans;

import junit.framework.*;
import java.awt.Color;

/**
 * This test verifies that the BeanProperty works as expected.
 *
 * @author <a href="mailto;kevin@swank.ca">Kevin Maltby</a>
 * @author manningj
 */
public class BeanPropertyTest extends TestCase {
    
    public BeanPropertyTest() {
        super();
    }
    
    /**
     * Tests that simple properties work.
     */
    public void testSimpleProperties() {
        BeanProperty painter = new BeanProperty(Automobile.class, "color", true, true);
        Automobile myCar = new Automobile(false);
        myCar.setColor(Color.red);
        assertEquals(Color.red, painter.get(myCar));
        painter.set(myCar, Color.blue);
        assertEquals(Color.blue, myCar.getColor());
        BeanProperty transmission = new BeanProperty(Automobile.class, "automatic", true, false);
        assertEquals(Boolean.FALSE, transmission.get(myCar));
        Automobile yourCar = new Automobile(true);
        assertEquals(Boolean.TRUE, transmission.get(yourCar));
        BeanProperty truckColor = new BeanProperty(Truck.class, "color", true, true);
        Truck myTruck = new Truck(3);
        myTruck.setColor(Color.yellow);
        assertEquals(Color.yellow, truckColor.get(myTruck));
        assertEquals(Color.class, truckColor.getValueClass());
        truckColor.set(myTruck, Color.green);
        assertEquals(Color.green, myTruck.getColor());
        BeanProperty gasUp = new BeanProperty(Automobile.class, "fullOfGas", false, true);
        gasUp.set(myCar, Boolean.TRUE);
        assertEquals(true, myCar.getDrivable());
        assertEquals(boolean.class, gasUp.getValueClass());
        gasUp.set(myCar, Boolean.FALSE);
        assertEquals(false, myCar.getDrivable());
        BeanProperty drivable = new BeanProperty(Automobile.class, "drivable", true, false);
        myCar.setFullOfGas(true);
        assertEquals(Boolean.TRUE, drivable.get(myCar));
        assertEquals(boolean.class, drivable.getValueClass());
        myCar.setFullOfGas(false);
        assertEquals(Boolean.FALSE, drivable.get(myCar));
        BeanProperty towedVehicle = new BeanProperty(SupportsTrailerHitch.class, "towedVehicle", true, true);
        myTruck.setTowedVehicle(myCar);
        assertEquals(myCar, towedVehicle.get(myTruck));
        assertEquals(Automobile.class, towedVehicle.getValueClass());
        towedVehicle.set(myTruck, yourCar);
        assertEquals(yourCar, myTruck.getTowedVehicle());
    }
    
    /**
     * Tests that navigating properties work.
     */
    public void testNavigatedProperties() {
        BeanProperty towAndPaint = new BeanProperty(SupportsTrailerHitch.class, "towedVehicle.color", true, true);
        Truck towTruck = new Truck(3);
        Automobile rainbowCar = new Automobile(true);
        towTruck.setTowedVehicle(rainbowCar);
        rainbowCar.setColor(Color.red);
        assertEquals(Color.red, towAndPaint.get(towTruck));
        assertEquals(Color.class, towAndPaint.getValueClass());
        towAndPaint.set(towTruck, Color.gray);
        assertEquals(Color.gray, rainbowCar.getColor());
        BeanProperty red = new BeanProperty(SupportsTrailerHitch.class, "towedVehicle.color.red", true, false);
        rainbowCar.setColor(Color.blue);
        assertEquals(new Integer(0), red.get(towTruck));
        rainbowCar.setColor(Color.red);
        assertEquals(new Integer(255), red.get(towTruck));
        assertEquals(int.class, red.getValueClass());
    }
    
    /**
     * Test that BeanProperties work for interfaces.
     *
     * @see <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=183">Issue 183</a>
     */
    public void testInterfaces() {
        BeanProperty codeProperty = new BeanProperty(SubInterface.class, "code", true, true);
        NamedCode namedCode = new NamedCode();
        codeProperty.set(namedCode, "C++");
        assertEquals("C++", codeProperty.get(namedCode));
    }
}
