package ca.odell.glazedlists;

import ca.odell.glazedlists.event.ListEvent;
import ca.odell.glazedlists.event.ListEventListener;
import junit.framework.TestCase;
import java.io.IOException;
import java.io.ObjectStreamClass;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Makes sure that {@link BasicEventList} works above and beyond its duties as
 * an {@link EventList}. This includes support for {@link Serializable}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class BasicEventListTest extends TestCase {
    
    public BasicEventListTest() {
        super();
    }
    
    public void testSimpleSerialization() throws IOException, ClassNotFoundException {
        EventList serializableList = new BasicEventList();
        serializableList.addAll(GlazedListsTests.stringToList("Saskatchewan Roughriders"));
        EventList serializedCopy = (EventList)GlazedListsTests.serialize(serializableList);
        assertEquals(serializableList, serializedCopy);
        serializedCopy.addAll(GlazedListsTests.stringToList("Hamilton Tiger-Cats"));
        assertFalse(serializableList.equals(serializedCopy));
    }
    
    public void testSerializeEmpty() throws IOException, ClassNotFoundException {
        EventList serializableList = new BasicEventList();
        EventList serializedCopy = (EventList)GlazedListsTests.serialize(serializableList);
        assertEquals(serializableList, serializedCopy);
    }
    
    public void testSerializableListeners() throws IOException, ClassNotFoundException {
        EventList serializableList = new BasicEventList();
        SerializableListener listener = new SerializableListener();
        serializableList.addListEventListener(listener);
        serializableList.addAll(GlazedListsTests.stringToList("Szarka"));
        assertEquals(serializableList, SerializableListener.getLastSource());
        EventList serializedCopy = (EventList)GlazedListsTests.serialize(serializableList);
        assertEquals(serializableList, serializedCopy);
        assertEquals(serializableList, SerializableListener.getLastSource());
        serializedCopy.addAll(GlazedListsTests.stringToList("McCalla"));
        assertEquals(serializedCopy, SerializableListener.getLastSource());
    }
    
    public void testUnserializableListeners() throws IOException, ClassNotFoundException {
        EventList serializableList = new BasicEventList();
        UnserializableListener listener = new UnserializableListener();
        serializableList.addListEventListener(listener);
        serializableList.addAll(GlazedListsTests.stringToList("Keith"));
        assertEquals(serializableList, UnserializableListener.getLastSource());
        EventList serializedCopy = (EventList)GlazedListsTests.serialize(serializableList);
        assertEquals(serializableList, serializedCopy);
        assertEquals(serializableList, UnserializableListener.getLastSource());
        serializedCopy.addAll(GlazedListsTests.stringToList("Holmes"));
        assertEquals(serializableList, UnserializableListener.getLastSource());
    }
    
    public void testSerialVersionUID() {
        assertEquals(4883958173323072345L, ObjectStreamClass.lookup(BasicEventList.class).getSerialVersionUID());
    }
    
    /**
     * Ensures the serialization format as of October 3, 2005 is still valid today.
     * We created a {@link BasicEventList} containing a sequence of one character
     * Strings, and dumped that to bytes.
     */
    public void testVersion20051003() throws IOException, ClassNotFoundException {
        byte[] serializedBytes = new byte[]{-84, -19, 0, 5, 115, 114, 0, 35, 99, 97, 46, 111, 100, 101, 108, 108, 46, 103, 108, 97, 122, 101, 100, 108, 105, 115, 116, 115, 46, 66, 97, 115, 105, 99, 69, 118, 101, 110, 116, 76, 105, 115, 116, 67, -57, 78, 21, 18, -55, -109, 89, 3, 0, 1, 76, 0, 4, 100, 97, 116, 97, 116, 0, 16, 76, 106, 97, 118, 97, 47, 117, 116, 105, 108, 47, 76, 105, 115, 116, 59, 120, 112, 117, 114, 0, 19, 91, 76, 106, 97, 118, 97, 46, 108, 97, 110, 103, 46, 79, 98, 106, 101, 99, 116, 59, -112, -50, 88, -97, 16, 115, 41, 108, 2, 0, 0, 120, 112, 0, 0, 0, 16, 116, 0, 1, 79, 116, 0, 1, 99, 116, 0, 1, 116, 116, 0, 1, 111, 116, 0, 1, 98, 116, 0, 1, 101, 116, 0, 1, 114, 116, 0, 1, 32, 116, 0, 1, 49, 116, 0, 1, 48, 116, 0, 1, 44, 116, 0, 1, 32, 116, 0, 1, 50, 116, 0, 1, 48, 116, 0, 1, 48, 116, 0, 1, 53, 117, 114, 0, 47, 91, 76, 99, 97, 46, 111, 100, 101, 108, 108, 46, 103, 108, 97, 122, 101, 100, 108, 105, 115, 116, 115, 46, 101, 118, 101, 110, 116, 46, 76, 105, 115, 116, 69, 118, 101, 110, 116, 76, 105, 115, 116, 101, 110, 101, 114, 59, 50, 67, 108, 98, -82, 79, 50, 13, 2, 0, 0, 120, 112, 0, 0, 0, 0, 120};
        List expected = new ArrayList();
        expected.addAll(GlazedListsTests.stringToList("October 10, 2005"));
        Object deserialized = GlazedListsTests.fromBytes(serializedBytes);
        assertEquals(expected, deserialized);
        assertEquals("[O, c, t, o, b, e, r,  , 1, 0, ,,  , 2, 0, 0, 5]", deserialized.toString());
    }
    
    /**
     * This listener invokes a static method each time it's target {@link EventList} is changed.
     */
    private static class SerializableListener implements ListEventListener, Serializable {
        
        private SerializableListener() {
            super();
        }
        private static EventList lastSource = null;
        
        public void listChanged(ListEvent listChanges) {
            lastSource = listChanges.getSourceList();
        }
        
        public static EventList getLastSource() {
            return lastSource;
        }
    }
    
    /**
     * This listener is not serializable, but it shouldn't prevent serialization on an observing
     * {@link EventList}.
     */
    private static class UnserializableListener implements ListEventListener {
        
        private UnserializableListener() {
            super();
        }
        private static EventList lastSource = null;
        
        public void listChanged(ListEvent listChanges) {
            lastSource = listChanges.getSourceList();
        }
        
        public static EventList getLastSource() {
            return lastSource;
        }
    }
}
