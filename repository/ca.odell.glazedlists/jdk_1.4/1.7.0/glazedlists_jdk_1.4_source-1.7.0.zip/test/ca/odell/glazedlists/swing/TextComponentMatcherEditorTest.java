package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.TextFilterator;
import ca.odell.glazedlists.matchers.SimpleMatcherEditorListener;
import javax.swing.*;
import javax.swing.text.AbstractDocument;

/**
 * Test {@link TextComponentMatcherEditor}.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class TextComponentMatcherEditorTest extends SwingTestCase {
    
    public TextComponentMatcherEditorTest() {
        super();
    }
    private SimpleMatcherEditorListener eventCounter;
    
    /**
     * Tests the user interface. This is a mandatory method in SwingTestCase classes.
     */
    public void testGui() {
        super.testGui();
    }
    
    public void guiSetUp() {
        eventCounter = new SimpleMatcherEditorListener();
    }
    
    public void guiTearDown() {
        eventCounter = null;
    }
    
    public void guiTestConstructors() {
        JTextField textComponent = new JTextField();
        AbstractDocument document = (AbstractDocument)(AbstractDocument)textComponent.getDocument();
        int initialDocumentListenerCount = document.getDocumentListeners().length;
        TextFilterator textFilterator = GlazedLists.toStringTextFilterator();
        TextComponentMatcherEditor tcme;
        tcme = new TextComponentMatcherEditor(textComponent, textFilterator);
        assertEquals(0, textComponent.getActionListeners().length);
        assertEquals(initialDocumentListenerCount + 1, document.getDocumentListeners().length);
        assertSame(textFilterator, tcme.getFilterator());
        assertTrue(tcme.isLive());
        tcme.dispose();
        tcme = new TextComponentMatcherEditor(textComponent, textFilterator, true);
        assertEquals(0, textComponent.getActionListeners().length);
        assertEquals(initialDocumentListenerCount + 1, document.getDocumentListeners().length);
        assertSame(textFilterator, tcme.getFilterator());
        assertTrue(tcme.isLive());
        tcme.dispose();
        tcme = new TextComponentMatcherEditor(textComponent, textFilterator, false);
        assertEquals(1, textComponent.getActionListeners().length);
        assertEquals(initialDocumentListenerCount, document.getDocumentListeners().length);
        assertSame(textFilterator, tcme.getFilterator());
        assertFalse(tcme.isLive());
        tcme.dispose();
        tcme = new TextComponentMatcherEditor(document, textFilterator);
        assertEquals(0, textComponent.getActionListeners().length);
        assertEquals(initialDocumentListenerCount + 1, document.getDocumentListeners().length);
        assertSame(textFilterator, tcme.getFilterator());
        assertTrue(tcme.isLive());
        tcme.dispose();
        assertEquals(0, textComponent.getActionListeners().length);
        assertEquals(initialDocumentListenerCount, document.getDocumentListeners().length);
    }
    
    /**
     * Test that this thing works, even if our document is preloaded with data.
     */
    public void guiTestPrePopulated() {
        TextComponentMatcherEditor textMatcherEditor = null;
        eventCounter.assertNoEvents(0);
        JTextField prePopulatedTextField = new JTextField();
        prePopulatedTextField.setText("ABC");
        textMatcherEditor = new TextComponentMatcherEditor(prePopulatedTextField, GlazedLists.toStringTextFilterator(), true);
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        assertFalse(textMatcherEditor.getMatcher().matches("BCDEF"));
        textMatcherEditor = new TextComponentMatcherEditor(prePopulatedTextField.getDocument(), GlazedLists.toStringTextFilterator());
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        assertFalse(textMatcherEditor.getMatcher().matches("BCDEF"));
    }
    
    /**
     * Test that this thing works when the document is changed.
     */
    public void guiTestChangeDocument() {
        TextComponentMatcherEditor textMatcherEditor = null;
        eventCounter.assertNoEvents(0);
        JTextField textField = new JTextField();
        textMatcherEditor = new TextComponentMatcherEditor(textField, GlazedLists.toStringTextFilterator(), true);
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        textField.setText("DEF");
        assertFalse(textMatcherEditor.getMatcher().matches("ABCDE"));
        assertTrue(textMatcherEditor.getMatcher().matches("TONEDEF"));
        textField = new JTextField();
        textMatcherEditor = new TextComponentMatcherEditor(textField.getDocument(), GlazedLists.toStringTextFilterator());
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        textField.setText("HIJ");
        assertFalse(textMatcherEditor.getMatcher().matches("BCDEF"));
        assertTrue(textMatcherEditor.getMatcher().matches("HIJESSE"));
    }
    
    /**
     * Test that this thing works when live is turned off.
     */
    public void guiTestNonLive() {
        TextComponentMatcherEditor textMatcherEditor = null;
        eventCounter.assertNoEvents(0);
        JTextField textField = new JTextField();
        textMatcherEditor = new TextComponentMatcherEditor(textField, GlazedLists.toStringTextFilterator(), false);
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        textField.setText("DEF");
        assertTrue(textMatcherEditor.getMatcher().matches("ABCDE"));
        assertTrue(textMatcherEditor.getMatcher().matches("TONEDEF"));
        textField.postActionEvent();
        assertFalse(textMatcherEditor.getMatcher().matches("ABCDE"));
        assertTrue(textMatcherEditor.getMatcher().matches("TONEDEF"));
    }
    
    /**
     * Test that this thing works with dispose.
     */
    public void guiTestDispose() {
        TextComponentMatcherEditor textMatcherEditor = null;
        eventCounter.assertNoEvents(0);
        boolean[] liveOptions = {true, false};
        for (int b = 0; b < liveOptions.length; b++) {
            JTextField textField = new JTextField();
            textMatcherEditor = new TextComponentMatcherEditor(textField, GlazedLists.toStringTextFilterator(), liveOptions[b]);
            textField.setText("DEF");
            textField.postActionEvent();
            assertTrue(textMatcherEditor.getMatcher().matches("TONEDEF"));
            assertFalse(textMatcherEditor.getMatcher().matches("STUPID"));
            textMatcherEditor.dispose();
            textField.setText("STU");
            textField.postActionEvent();
            assertTrue(textMatcherEditor.getMatcher().matches("TONEDEF"));
            assertFalse(textMatcherEditor.getMatcher().matches("STUPID"));
        }
    }
}
