package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.ThreadRecorderEventList;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedListsTests;
import java.awt.*;

/**
 * Test EventListModel from the Swing thread.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class EventListModelTest extends SwingTestCase {
    
    public EventListModelTest() {
        super();
    }
    
    /**
     * Tests the user interface. This is a mandatory method in SwingTestCase classes.
     */
    public void testGui() {
        super.testGui();
    }
    
    /**
     * Verifies that the new getElementAt() method of EventListModel works.
     */
    public void guiTestGetElementAt() {
        EventList colors = new BasicEventList();
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.BLUE);
        EventListModel tableModel = new EventListModel(colors);
        assertEquals(Color.RED, tableModel.getElementAt(0));
        assertEquals(Color.GREEN, tableModel.getElementAt(1));
        assertEquals(Color.BLUE, tableModel.getElementAt(2));
        try {
            tableModel.getElementAt(100);
            fail("failed to receive IndexOutOfBoundsException for invalid index");
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            tableModel.getElementAt(-1);
            fail("failed to receive IndexOutOfBoundsException for invalid index");
        } catch (IndexOutOfBoundsException e) {
        }
    }
    
    public void guiTestConstructorLocking() throws InterruptedException {
        final ThreadRecorderEventList atomicList = new ThreadRecorderEventList(new BasicEventList());
        final Thread writerThread = new Thread(GlazedListsTests.createJerkyAddRunnable(atomicList, null, 2000, 50), "WriterThread");
        writerThread.start();
        Thread.sleep(200);
        final EventList delayList = GlazedListsTests.delayList(atomicList, 50);
        new EventListModel(delayList);
        writerThread.join();
        assertEquals(3, atomicList.getReadWriteBlockCount());
    }
}
