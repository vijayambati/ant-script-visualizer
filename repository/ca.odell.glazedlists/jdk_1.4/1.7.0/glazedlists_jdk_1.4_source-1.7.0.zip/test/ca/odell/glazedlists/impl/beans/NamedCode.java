package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

class NamedCode implements SubInterface {
    
    NamedCode() {
        super();
    }
    private String name = "JManning";
    private String code = "Java!";
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
}
