package ca.odell.glazedlists;

import ca.odell.glazedlists.matchers.*;
import java.util.*;

/**
 * A MatcherEditor for minimum values.
 */
class MinimumValueMatcherEditor extends AbstractMatcherEditor {
    private int minimum = 0;
    
    public MinimumValueMatcherEditor() {
        super();
        currentMatcher = GlazedListsTests.matchAtLeast(0);
    }
    
    public void setMinimum(int value) {
        if (value < minimum) {
            this.minimum = value;
            fireRelaxed(GlazedListsTests.matchAtLeast(minimum));
        } else if (value == minimum) {
        } else {
            this.minimum = value;
            fireConstrained(GlazedListsTests.matchAtLeast(minimum));
        }
    }
}
