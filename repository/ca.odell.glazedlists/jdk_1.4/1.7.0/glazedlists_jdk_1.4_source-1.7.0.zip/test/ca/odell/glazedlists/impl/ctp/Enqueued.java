package ca.odell.glazedlists.impl.ctp;

import java.util.*;
import ca.odell.glazedlists.impl.io.Bufferlo;
import java.io.*;

/**
 * Models an outgoing chunk.
 */
class Enqueued {
    private Bufferlo data = new Bufferlo();
    
    public Enqueued(String charData) {
        super();
        data.write(charData);
    }
    
    public Bufferlo getData() {
        return data;
    }
    
    public String toString() {
        if (data.length() > 30) return "Enqueued \"" + data.length() + ":" + data.toString().substring(0, 30) + "\""; else return "Enqueued \"" + data + "\"";
    }
}
