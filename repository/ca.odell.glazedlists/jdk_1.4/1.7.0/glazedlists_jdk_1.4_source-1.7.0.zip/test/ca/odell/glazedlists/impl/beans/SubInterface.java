package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

interface SubInterface extends BaseInterface {
    
    public String getName();
    
    public void setName(String name);
}
