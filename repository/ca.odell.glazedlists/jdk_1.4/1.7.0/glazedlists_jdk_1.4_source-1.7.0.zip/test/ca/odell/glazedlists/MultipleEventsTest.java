package ca.odell.glazedlists;

import junit.framework.*;

/**
 * Tests to verify that for each list change, only one event is fired.
 *
 * @see <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=46">Bug 46</a>
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class MultipleEventsTest extends TestCase {
    
    public MultipleEventsTest() {
        super();
    }
    
    /**
     * Tests that clearing the filter list does not fire multiple
     * events on the original list.
     */
    public void testFilterList() {
        EventList source = new BasicEventList();
        source.add(new int[]{1});
        source.add(new int[]{0});
        source.add(new int[]{1});
        source.add(new int[]{0});
        IntegerArrayMatcherEditor matcherEditor = new IntegerArrayMatcherEditor(0, 0);
        matcherEditor.setFilter(0, 1);
        FilterList filterList = new FilterList(source, matcherEditor);
        ListConsistencyListener counter = ListConsistencyListener.install(filterList);
        filterList.clear();
        assertEquals(1, counter.getEventCount());
    }
    
    /**
     * Tests that clearing a sub list does not fire multiple
     * events on the original list.
     */
    public void testSubList() {
        EventList source = new BasicEventList();
        source.add("A");
        source.add("B");
        source.add("C");
        source.add("D");
        EventList subList = (EventList)(EventList)source.subList(1, 3);
        ListConsistencyListener counter = ListConsistencyListener.install(subList);
        subList.clear();
        assertEquals(1, counter.getEventCount());
    }
    
    /**
     * Tests that clearing a unique list does not fire multiple
     * events on the original list.
     */
    public void testUniqueList() {
        EventList source = new BasicEventList();
        source.add("A");
        source.add("B");
        source.add("B");
        source.add("C");
        EventList uniqueList = new UniqueList(source);
        ListConsistencyListener counter = ListConsistencyListener.install(uniqueList);
        uniqueList.clear();
        assertEquals(1, counter.getEventCount());
    }
}
