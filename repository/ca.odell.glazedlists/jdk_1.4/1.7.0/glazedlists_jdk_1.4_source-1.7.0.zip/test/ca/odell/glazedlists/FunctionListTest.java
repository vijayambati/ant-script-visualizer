package ca.odell.glazedlists;

import junit.framework.TestCase;
import java.util.List;
import java.util.ArrayList;

public class FunctionListTest extends TestCase {
    
    public FunctionListTest() {
        super();
    }
    
    public void testConstructor() {
        try {
            new FunctionList(new BasicEventList(), null);
            fail("failed to receive an IllegalArgumentException with null forward Function");
        } catch (IllegalArgumentException e) {
        }
        new FunctionList(new BasicEventList(), new IntegerToString());
        new FunctionList(new BasicEventList(), new IntegerToString(), null);
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        source.add(new Integer(0));
        source.add(new Integer(1));
        source.add(new Integer(2));
        assertEquals(3, intsToStrings.size());
        assertEquals("0", (String)intsToStrings.get(0));
        assertEquals("1", (String)intsToStrings.get(1));
        assertEquals("2", (String)intsToStrings.get(2));
        intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        assertEquals(3, intsToStrings.size());
        assertEquals("0", (String)intsToStrings.get(0));
        assertEquals("1", (String)intsToStrings.get(1));
        assertEquals("2", (String)intsToStrings.get(2));
    }
    
    public void testAdd() {
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        source.add(new Integer(0));
        source.add(new Integer(1));
        source.add(new Integer(2));
        assertEquals("0", (String)intsToStrings.get(0));
        assertEquals("1", (String)intsToStrings.get(1));
        assertEquals("2", (String)intsToStrings.get(2));
        intsToStrings.add("3");
        intsToStrings.add("4");
        intsToStrings.add("5");
        assertEquals("3", (String)intsToStrings.get(3));
        assertEquals("4", (String)intsToStrings.get(4));
        assertEquals("5", (String)intsToStrings.get(5));
        intsToStrings.add(0, "8");
        assertEquals("8", (String)intsToStrings.get(0));
        source = new BasicEventList();
        intsToStrings = new FunctionList(source, new IntegerToString());
        source.add(new Integer(0));
        assertEquals("0", (String)intsToStrings.get(0));
        try {
            intsToStrings.add("3");
            fail("failed to receive an IllegalStateException for a call to add with no reverse function specified");
        } catch (IllegalStateException e) {
        }
        try {
            intsToStrings.add(2, "3");
            fail("failed to receive an IllegalStateException for a call to add with no reverse function specified");
        } catch (IllegalStateException e) {
        }
    }
    
    public void testAddAll() {
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        List toAdd = new ArrayList();
        toAdd.add(new Integer(0));
        toAdd.add(new Integer(1));
        toAdd.add(new Integer(2));
        source.addAll(toAdd);
        assertEquals("0", (String)intsToStrings.get(0));
        assertEquals("1", (String)intsToStrings.get(1));
        assertEquals("2", (String)intsToStrings.get(2));
    }
    
    public void testSet() {
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        source.add(new Integer(0));
        source.add(new Integer(1));
        source.add(new Integer(2));
        intsToStrings.set(0, "8");
        assertEquals("8", (String)intsToStrings.get(0));
        source = new BasicEventList();
        intsToStrings = new FunctionList(source, new IntegerToString());
        source.add(new Integer(0));
        try {
            intsToStrings.set(0, "8");
            fail("failed to receive an IllegalStateException for a call to set with no reverse function specified");
        } catch (Exception e) {
        }
        source.set(0, new Integer(9));
        assertEquals("9", (String)intsToStrings.get(0));
    }
    
    public void testRemove() {
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new IntegerToString(), new StringToInteger());
        source.add(new Integer(0));
        source.add(new Integer(1));
        source.add(new Integer(2));
        intsToStrings.remove(0);
        assertEquals("1", (String)intsToStrings.get(0));
        assertEquals("2", (String)intsToStrings.get(1));
        source.remove(0);
        assertEquals("2", (String)intsToStrings.get(0));
    }
    
    public void testAdvancedFunction() {
        BasicEventList source = new BasicEventList();
        FunctionList intsToStrings = new FunctionList(source, new AdvancedIntegerToString(), new StringToInteger());
        source.add(new Integer(0));
        assertEquals(0, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getReevaluateCount());
        source.set(0, source.get(0));
        assertEquals(1, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getReevaluateCount());
        assertEquals(1, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getReevaluateCount());
        source.set(0, new Integer(0));
        assertEquals(2, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getReevaluateCount());
        assertEquals(0, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getDisposeCount());
        source.remove(0);
        assertEquals(1, ((AdvancedIntegerToString)(FunctionListTest.AdvancedIntegerToString)intsToStrings.getForwardFunction()).getDisposeCount());
    }
    
    private static class StringToInteger implements FunctionList.Function {
        
        private StringToInteger() {
            super();
        }
        
        public Object evaluate(Object x0) {
            String value = (String)x0;
            return new Integer(value);
        }
        /*missing*/
    }
    
    private static class IntegerToString implements FunctionList.Function {
        
        private IntegerToString() {
            super();
        }
        
        public Object evaluate(Object x0) {
            Integer value = (Integer)x0;
            return value.toString();
        }
        /*missing*/
    }
    
    private static class AdvancedIntegerToString extends IntegerToString implements FunctionList.AdvancedFunction {
        
        private AdvancedIntegerToString() {
            super();
        }
        private int reevaluateCount = 0;
        private int disposeCount = 0;
        
        public Object reevaluate(Object x0, Object x1) {
            Integer value = (Integer)x0;
            String oldValue = (String)x1;
            this.reevaluateCount++;
            return this.evaluate(value);
        }
        
        public void dispose(Object x0, Object x1) {
            Integer sourceValue = (Integer)x0;
            String transformedValue = (String)x1;
            this.disposeCount++;
        }
        
        public int getReevaluateCount() {
            return reevaluateCount;
        }
        
        public int getDisposeCount() {
            return this.disposeCount;
        }
        /*missing*/
        /*missing*/
    }
}
