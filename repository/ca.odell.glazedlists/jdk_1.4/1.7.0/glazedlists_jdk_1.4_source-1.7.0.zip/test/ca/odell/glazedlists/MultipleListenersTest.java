package ca.odell.glazedlists;

import junit.framework.*;
import ca.odell.glazedlists.impl.sort.*;
import ca.odell.glazedlists.matchers.AbstractMatcherEditor;
import ca.odell.glazedlists.matchers.Matcher;
import java.util.*;

/**
 * This test verifies that event lists can have multiple listeners.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class MultipleListenersTest extends TestCase {
    
    public MultipleListenersTest() {
        super();
    }
    
    /**
     * for randomly choosing list indices 
     */
    private Random random = new Random();
    
    /**
     * The multiple listeners test creates a single BasicEventList and a
     * set of listeners on it. The basic event list is changed and each
     * listener is changed in sequence to verify that the listeners all
     * receive notification.
     */
    public void testMultipleListeners() {
        BasicEventList root = new BasicEventList();
        List control = new ArrayList();
        for (int i = 0; i < 1000; i++) {
            Integer value = new Integer(random.nextInt(100));
            root.add(value);
            control.add(value);
        }
        Comparator comparator = GlazedLists.comparableComparator();
        SortedList sorted = new SortedList(root, comparator);
        IntegerSizeMatcherEditor matcherEditor = new IntegerSizeMatcherEditor(50);
        FilterList filtered = new FilterList(root, matcherEditor);
        for (int i = 0; i < 30; i++) {
            for (int j = 0; j < 100; j++) {
                Integer value = new Integer(random.nextInt(100));
                root.add(value);
                control.add(value);
            }
            assertEquals(root, control);
            List sortedControl = new ArrayList();
            sortedControl.addAll(control);
            Collections.sort(sortedControl, sorted.getComparator());
            assertEquals(sortedControl, sorted);
            List filteredControl = new ArrayList();
            for (int j = 0; j < control.size(); j++) {
                if (matcherEditor.getMatcher().matches(control.get(j))) {
                    filteredControl.add(control.get(j));
                }
            }
            assertEquals(filteredControl, filtered);
            if (comparator instanceof ReverseComparator) {
                comparator = GlazedLists.comparableComparator();
            } else {
                comparator = GlazedLists.reverseComparator(comparator);
            }
            sorted.setComparator(comparator);
            matcherEditor.setThreshhold(random.nextInt(100));
        }
    }
    
    /**
     * A simple filter for filtering integers by size.
     */
    class IntegerSizeMatcherEditor extends AbstractMatcherEditor {
        
        public IntegerSizeMatcherEditor(int threshhold) {
            super();
            setThreshhold(threshhold);
        }
        
        public void setThreshhold(int threshhold) {
            fireChanged(new IntegerMatcher(threshhold));
        }
        
        private class IntegerMatcher implements Matcher {
            int threshhold;
            
            public IntegerMatcher(int threshhold) {
                super();
                this.threshhold = threshhold;
            }
            
            public boolean matches(Object element) {
                Integer integer = (Integer)(Integer)element;
                return (integer.intValue() >= threshhold);
            }
        }
    }
    
    /**
     * The main method simply provides access to this class outside of JUnit.
     */
    public static void main(String[] args) {
        new MultipleListenersTest().testMultipleListeners();
    }
}
