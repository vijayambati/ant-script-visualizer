package ca.odell.glazedlists.io;

import junit.framework.*;
import java.io.*;

/**
 * This test verifies that the FileList works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class FileListTest extends TestCase {
    
    public FileListTest() {
        super();
    }
    
    /**
     * Creates a file list, writes a value and reads a value. The written value
     * is the sum of the last two values read. If less than 2 values are read, then 1 is
     * written.
     */
    public void testCreate() throws IOException {
        File fibonacciFile = File.createTempFile("fibonacci", "j81");
        fibonacciFile.deleteOnExit();
        int expectedSecondLast = 0;
        int expectedLast = 0;
        int current = 0;
        for (int i = 0; i < 16; i++) {
            FileList fibonacci = new FileList(fibonacciFile, GlazedListsIO.serializableByteCoder());
            if (fibonacci.size() < 2) {
                current = 1;
            } else {
                Integer secondLast = (Integer)(Integer)fibonacci.get(fibonacci.size() - 2);
                assertEquals(expectedSecondLast, secondLast.intValue());
                Integer last = (Integer)(Integer)fibonacci.get(fibonacci.size() - 1);
                assertEquals(expectedLast, last.intValue());
                current = secondLast.intValue() + last.intValue();
            }
            fibonacci.add(new Integer(current));
            fibonacci.close();
            expectedSecondLast = expectedLast;
            expectedLast = current;
        }
    }
}
