package ca.odell.glazedlists;

import junit.framework.*;
import ca.odell.glazedlists.event.*;
import java.util.*;

/**
 * This test attempts to cause atomic change events that have change blocks
 * with indexes in random order.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class IndexOrderTest extends TestCase {
    
    public IndexOrderTest() {
        super();
    }
    
    /**
     * for randomly choosing list indices 
     */
    private Random random = new Random();
    
    /**
     * Test to verify that the list changes occur in increasing order.
     * GlazedL
     * <p>This creates a long chain of lists designed to cause events where the indices
     * are out of order. The resultant list is a list of integer arrays of size two.
     * That list has been filtered to not contain any elements where the first index is
     * greater than 50. It has been sorted in increasing order.
     */
    public void testIncreasingOrder() {
        EventList unsorted = new BasicEventList();
        IntegerArrayMatcherEditor matcherEditor = new IntegerArrayMatcherEditor(0, 50);
        FilterList filteredOnce = new FilterList(unsorted, matcherEditor);
        for (int a = 0; a < 100; a++) {
            List currentChange = new ArrayList();
            for (int b = 0; b < 10; b++) {
                currentChange.add(new int[]{random.nextInt(100), random.nextInt(100)});
            }
            unsorted.addAll(currentChange);
        }
        for (int b = 0; b < 100; b++) {
            matcherEditor.setFilter(random.nextInt(2), random.nextInt(100));
        }
    }
    
    /**
     * Test to verify that the lists work with change indices out of order.
     *
     * <p>This creates a long chain of lists designed to cause events where the indices
     * are out of order. The resultant list is a list of integer arrays of size two.
     * That list has been filtered to not contain any elements where the first index is
     * greater than 50. It has been sorted in increasing order.
     */
    public void testIndexOutOfOrder() {
        EventList unsorted = new BasicEventList();
        SortedList sortedOnce = new SortedList(unsorted, GlazedListsTests.intArrayComparator(0));
        IntegerArrayMatcherEditor matcherEditor = new IntegerArrayMatcherEditor(0, 50);
        FilterList filteredOnce = new FilterList(sortedOnce, matcherEditor);
        SortedList sortedTwice = new SortedList(filteredOnce, GlazedListsTests.intArrayComparator(0));
        ListConsistencyListener.install(unsorted);
        ListConsistencyListener.install(sortedOnce);
        ListConsistencyListener.install(filteredOnce);
        ListConsistencyListener.install(sortedTwice);
        ArrayList controlList = new ArrayList();
        for (int a = 0; a < 15; a++) {
            List currentChange = new ArrayList();
            for (int b = 0; b < controlList.size() || b < 10; b++) {
                currentChange.add(new int[]{random.nextInt(100), random.nextInt(100)});
            }
            unsorted.addAll(currentChange);
            controlList.addAll(currentChange);
            Collections.sort(controlList, sortedTwice.getComparator());
            for (Iterator i = controlList.iterator(); i.hasNext(); ) {
                if (matcherEditor.getMatcher().matches(i.next())) continue;
                i.remove();
            }
            assertEquals(controlList, filteredOnce);
        }
    }
}
