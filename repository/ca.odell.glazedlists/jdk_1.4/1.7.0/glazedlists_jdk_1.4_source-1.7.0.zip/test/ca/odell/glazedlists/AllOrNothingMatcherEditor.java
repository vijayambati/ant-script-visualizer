package ca.odell.glazedlists;

import ca.odell.glazedlists.matchers.*;
import java.util.*;

/**
 * Matcher that allows testing matchAll() and matchNone().
 */
class AllOrNothingMatcherEditor extends AbstractMatcherEditor {
    
    AllOrNothingMatcherEditor() {
        super();
    }
    
    /**
     * @param state True show everything, otherwise show nothing
     */
    public void showAll(boolean state) {
        if (state) fireMatchAll(); else fireMatchNone();
    }
}
