package ca.odell.glazedlists;

import junit.framework.TestCase;
import ca.odell.glazedlists.matchers.*;
import java.util.*;

/**
 * Tests the generic FilterList class.
 */
public class FilterListTest extends TestCase {
    
    public FilterListTest() {
        super();
    }
    
    /**
     * This test ensures FilterList's generic arguments are correct.
     * Specifically, a FilterList<E> should be able to accept any Matcher<? super E>
     * and MatcherEditor<? super E>. In other words:
     *
     * <p>FilterList<Number> can accept a Matcher<Number> or Matcher<Object>, but not
     * a Matcher<Integer>.
     *
     * <p>FilterList<Number> can accept a MatcherEditor<Number> or MatcherEditor<Object>, but not
     * a MatcherEditor<Integer>.
     */
    public void testGenericsCompile() {
        final Matcher numberMatcher = new MinimumNumberMatcher(0);
        final MatcherEditor numberMatcherEditor = new MinimumNumberMatcherEditor();
        new FilterList(new BasicEventList(), Matchers.falseMatcher());
        new FilterList(new BasicEventList(), numberMatcher);
        new FilterList(new BasicEventList(), new AllOrNothingMatcherEditor());
        new FilterList(new BasicEventList(), numberMatcherEditor);
        final FilterList filtered = new FilterList(new BasicEventList());
        filtered.setMatcher(Matchers.falseMatcher());
        filtered.setMatcher(numberMatcher);
        filtered.setMatcherEditor(new AllOrNothingMatcherEditor());
        filtered.setMatcherEditor(numberMatcherEditor);
    }
    
    /**
     * This test demonstrates Issue 213.
     */
    public void testRelax() {
        EventList original = new BasicEventList();
        List values = GlazedListsTests.intArrayToIntegerCollection(new int[]{11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 0, 10, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 10, 1});
        original.addAll(values);
        MinimumValueMatcherEditor editor = new MinimumValueMatcherEditor();
        FilterList myFilterList = new FilterList(original, editor);
        ListConsistencyListener.install(myFilterList);
        editor.setMinimum(11);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(10);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(0);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(10);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(11);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(0);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        values = GlazedListsTests.intArrayToIntegerCollection(new int[]{11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11});
        original.clear();
        original.addAll(values);
        editor.setMinimum(10);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(11);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(12);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(10);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        values = GlazedListsTests.intArrayToIntegerCollection(new int[]{8, 6, 7, 5, 3, 0, 9});
        original.clear();
        original.addAll(values);
        editor.setMinimum(5);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(10);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(1);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(0);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
        editor.setMinimum(1);
        assertEquals(myFilterList, GlazedListsTests.filter(original, editor.getMatcher()));
    }
    
    /**
     * Test Matchers that fire matchAll() and matchNone() events.
     */
    public void testMatchAllOrNothing() {
        EventList baseList = new BasicEventList();
        baseList.add(new Integer(1));
        baseList.add(new Integer(2));
        baseList.add(new Integer(3));
        baseList.add(new Integer(4));
        baseList.add(new Integer(5));
        AllOrNothingMatcherEditor matcher = new AllOrNothingMatcherEditor();
        FilterList filterList = new FilterList(baseList, matcher);
        ListConsistencyListener.install(filterList);
        assertEquals(5, filterList.size());
        matcher.showAll(false);
        assertEquals(0, filterList.size());
        matcher.showAll(false);
        assertEquals(0, filterList.size());
        matcher.showAll(true);
        assertEquals(5, filterList.size());
        matcher.showAll(true);
        assertEquals(5, filterList.size());
    }
    
    public void testDispose() {
        EventList baseList = GlazedLists.eventList(GlazedListsTests.stringToList("ABCCBA"));
        FilterList filterList = new FilterList(baseList);
        GlazedListsTests.ListEventCounter counter = new GlazedListsTests.ListEventCounter();
        filterList.addListEventListener(counter);
        TextMatcherEditor editor = new TextMatcherEditor(GlazedLists.toStringTextFilterator());
        filterList.setMatcherEditor(editor);
        assertEquals(0, counter.getCountAndReset());
        editor.setFilterText(new String[]{"B"});
        assertEquals(1, counter.getCountAndReset());
        filterList.dispose();
        assertEquals(0, counter.getCountAndReset());
        editor.setFilterText(new String[]{"C"});
        assertEquals(0, counter.getCountAndReset());
    }
}
