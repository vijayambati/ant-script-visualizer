package ca.odell.glazedlists.io;

import java.util.*;
import ca.odell.glazedlists.*;
import junit.framework.*;
import java.io.*;

/**
 * Verifies that NetworkList works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class NetworkListTest extends TestCase {
    
    public NetworkListTest() {
        super();
    }
    
    /**
     * the peer manages publishing and subscribing 
     */
    private ListPeer peer;
    
    /**
     * the port to listen on 
     */
    private static int serverPort = 5100;
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        try {
            serverPort++;
            peer = new ListPeer(serverPort);
            peer.start();
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        peer.stop();
    }
    
    /**
     * Verifies that Resources can be published and subscribed to.
     */
    public void testSimpleSubscription() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            SimpleNetworkListStatusListener sourceListener = new SimpleNetworkListStatusListener(sourceList);
            waitFor(1000);
            assertTrue(sourceListener.isConnected());
            sourceListTS.add(new Integer(8));
            sourceListTS.add(new Integer(6));
            sourceListTS.add(new Integer(7));
            sourceListTS.add(new Integer(5));
            NetworkList targetList = peer.subscribe("localhost", serverPort, path, GlazedListsIO.serializableByteCoder());
            SimpleNetworkListStatusListener targetListener = new SimpleNetworkListStatusListener(targetList);
            waitFor(1000);
            assertTrue(targetListener.isConnected());
            assertEquals(sourceList, targetList);
            sourceListTS.add(new Integer(3));
            sourceListTS.add(new Integer(0));
            sourceListTS.add(new Integer(9));
            waitFor(1000);
            assertEquals(sourceList, targetList);
            targetList.disconnect();
            waitFor(1000);
            assertFalse(targetListener.isConnected());
            assertTrue(sourceListener.isConnected());
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Verifies that the client can disconnect and reconnect.
     */
    public void testClientDisconnect() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            sourceListTS.add(new Integer(8));
            sourceListTS.add(new Integer(6));
            NetworkList targetList = peer.subscribe("localhost", serverPort, path, GlazedListsIO.serializableByteCoder());
            SimpleNetworkListStatusListener targetListener = new SimpleNetworkListStatusListener(targetList);
            waitFor(1000);
            assertTrue(targetListener.isConnected());
            assertTrue(targetList.isConnected());
            assertEquals(sourceList, targetList);
            List snapshot = new ArrayList();
            snapshot.addAll(sourceListTS);
            targetList.disconnect();
            waitFor(1000);
            assertFalse(targetListener.isConnected());
            assertFalse(targetList.isConnected());
            sourceListTS.add(new Integer(7));
            sourceListTS.add(new Integer(5));
            waitFor(1000);
            assertEquals(snapshot, targetList);
            targetList.connect();
            waitFor(1000);
            assertTrue(targetListener.isConnected());
            assertTrue(targetList.isConnected());
            assertEquals(sourceList, targetList);
            targetList.disconnect();
            waitFor(1000);
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Verifies that the server can disconnect and reconnect.
     */
    public void testServerDisconnect() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            SimpleNetworkListStatusListener sourceListener = new SimpleNetworkListStatusListener(sourceList);
            sourceListTS.add(new Integer(8));
            sourceListTS.add(new Integer(6));
            NetworkList targetList = peer.subscribe("localhost", serverPort, path, GlazedListsIO.serializableByteCoder());
            SimpleNetworkListStatusListener targetListener = new SimpleNetworkListStatusListener(targetList);
            waitFor(1000);
            assertTrue(sourceListener.isConnected());
            assertTrue(sourceList.isConnected());
            assertTrue(targetListener.isConnected());
            assertTrue(targetList.isConnected());
            assertEquals(sourceList, targetList);
            List snapshot = new ArrayList();
            snapshot.addAll(sourceListTS);
            sourceList.disconnect();
            waitFor(1000);
            assertFalse(sourceListener.isConnected());
            assertFalse(sourceList.isConnected());
            assertFalse(targetListener.isConnected());
            assertFalse(targetList.isConnected());
            sourceListTS.add(new Integer(7));
            sourceListTS.add(new Integer(5));
            waitFor(1000);
            assertEquals(snapshot, targetList);
            sourceList.connect();
            targetList.connect();
            waitFor(1000);
            assertTrue(sourceListener.isConnected());
            assertTrue(sourceList.isConnected());
            assertTrue(targetListener.isConnected());
            assertTrue(targetList.isConnected());
            assertEquals(sourceList, targetList);
            targetList.disconnect();
            waitFor(1000);
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Verifies that many listeners can subscribe to a resource.
     */
    public void testManyListeners() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            sourceListTS.add(new Integer(8));
            sourceListTS.add(new Integer(6));
            int connectPort = serverPort;
            List peers = new ArrayList();
            for (int p = 0; p < 4; p++) {
                serverPort++;
                ListPeer listenerPeer = new ListPeer(serverPort);
                listenerPeer.start();
                peers.add(listenerPeer);
            }
            List listeners = new ArrayList();
            for (Iterator p = peers.iterator(); p.hasNext(); ) {
                ListPeer listenerPeer = (ListPeer)(ListPeer)p.next();
                NetworkList listener = listenerPeer.subscribe("localhost", connectPort, path, GlazedListsIO.serializableByteCoder());
                listeners.add(listener);
            }
            waitFor(1000);
            for (Iterator i = listeners.iterator(); i.hasNext(); ) {
                NetworkList listener = (NetworkList)(NetworkList)i.next();
                assertEquals(sourceList, listener);
            }
            sourceListTS.add(new Integer(3));
            sourceListTS.add(new Integer(0));
            sourceListTS.add(new Integer(9));
            waitFor(1000);
            for (Iterator i = listeners.iterator(); i.hasNext(); ) {
                NetworkList listener = (NetworkList)(NetworkList)i.next();
                assertEquals(sourceList, listener);
            }
            for (Iterator p = peers.iterator(); p.hasNext(); ) {
                ListPeer listenerPeer = (ListPeer)(ListPeer)p.next();
                listenerPeer.stop();
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Verifies that the server can unpublish a value.
     */
    public void testServerUnpublish() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            sourceListTS.add(new Integer(8));
            sourceListTS.add(new Integer(6));
            NetworkList targetList = peer.subscribe("localhost", serverPort, path, GlazedListsIO.serializableByteCoder());
            waitFor(1000);
            assertEquals(sourceList, targetList);
            List snapshot = new ArrayList();
            snapshot.addAll(sourceListTS);
            sourceList.disconnect();
            waitFor(1000);
            assertFalse(targetList.isConnected());
            EventList sourceList2TS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList2 = peer.publish(sourceList2TS, path, GlazedListsIO.serializableByteCoder());
            sourceList2TS.add(new Integer(7));
            sourceList2TS.add(new Integer(5));
            targetList.connect();
            waitFor(1000);
            assertEquals(sourceList2, targetList);
            sourceList2.disconnect();
            waitFor(1000);
            assertFalse(targetList.isConnected());
            sourceList.connect();
            targetList.connect();
            waitFor(1000);
            assertEquals(sourceList, targetList);
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Verifies that nothing breaks when a client subscribes during a flurry of updates.
     */
    public void testFrequentUpdates() {
        try {
            String path = "/integers";
            EventList sourceListTS = GlazedLists.threadSafeList(new BasicEventList());
            NetworkList sourceList = peer.publish(sourceListTS, path, GlazedListsIO.serializableByteCoder());
            NetworkList targetList = peer.subscribe("localhost", serverPort, path, GlazedListsIO.serializableByteCoder());
            targetList.disconnect();
            for (int j = 0; j < 5; j++) {
                waitFor(1000);
                sourceListTS.clear();
                targetList.connect();
                for (int i = 0; i < 25; i++) {
                    sourceListTS.add(new Integer(i));
                }
                waitFor(1000);
                assertEquals(sourceList, targetList);
                targetList.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    /**
     * Waits for the specified duration of time. This hack method should be replaced
     * with something else that uses notification.
     */
    private static void waitFor(long time) {
        try {
            Object lock = new Object();
            synchronized (lock) {
                lock.wait(time);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Runs the test of this application
     */
    public static void main(String[] args) {
        NetworkListTest test = new NetworkListTest();
        test.setUp();
        test.testSimpleSubscription();
        test.tearDown();
    }
}
