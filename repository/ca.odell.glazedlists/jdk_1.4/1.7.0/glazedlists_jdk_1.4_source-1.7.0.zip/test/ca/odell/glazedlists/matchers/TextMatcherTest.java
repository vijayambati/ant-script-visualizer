package ca.odell.glazedlists.matchers;

import junit.framework.TestCase;
import ca.odell.glazedlists.impl.filter.*;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.TextFilterator;
import java.util.*;

public class TextMatcherTest extends TestCase {
    
    public TextMatcherTest() {
        super();
    }
    private List numbers = Arrays.asList(new Object[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"});
    private List monotonicAlphabet = Arrays.asList(new Object[]{"0", "01", "012", "0123", "01234", "012345", "0123456", "01234567", "012345678", "0123456789"});
    private List dictionary = Arrays.asList(new Object[]{"act", "actor", "enact", "reactor"});
    
    public void testNormalizeValue() {
        assertTrue(Arrays.equals(new String[0], TextMatcher.normalizeFilters(new String[0])));
        assertTrue(Arrays.equals(new String[0], TextMatcher.normalizeFilters(new String[]{null, ""})));
        assertTrue(Arrays.equals(new String[]{"x"}, TextMatcher.normalizeFilters(new String[]{"x", null, ""})));
        assertTrue(Arrays.equals(new String[]{"x", "Y", "z"}, TextMatcher.normalizeFilters(new String[]{null, "", "x", null, "", "Y", null, "", "z", null, ""})));
        assertTrue(Arrays.equals(new String[]{"xyz"}, TextMatcher.normalizeFilters(new String[]{null, "", "x", null, "", "xy", null, "", "xyz", null, ""})));
        assertTrue(Arrays.equals(new String[]{"xyz"}, TextMatcher.normalizeFilters(new String[]{null, "", "xyz", null, "", "xy", null, "", "x", null, ""})));
        assertTrue(Arrays.equals(new String[]{"xyz"}, TextMatcher.normalizeFilters(new String[]{null, "", "xy", null, "", "xyz", null, "", "x", null, ""})));
        assertTrue(Arrays.equals(new String[]{"xyz"}, TextMatcher.normalizeFilters(new String[]{null, "", "xyz", null, "", "xyz", null, "", "xyz", null, ""})));
        assertTrue(Arrays.equals(new String[]{"blackened"}, TextMatcher.normalizeFilters(new String[]{"black", "blackened"})));
        assertTrue(Arrays.equals(new String[]{"this"}, TextMatcher.normalizeFilters(new String[]{"this", "his"})));
        assertTrue(Arrays.equals(new String[]{"blackened", "this"}, TextMatcher.normalizeFilters(new String[]{"blackened", "this"})));
        assertTrue(Arrays.equals(new String[]{"blackened", "this"}, TextMatcher.normalizeFilters(new String[]{"this", "blackened"})));
    }
    
    public void testIsFilterRelaxed() {
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"x"}, new String[0]));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xx"}, new String[]{"x"}));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xx", "y"}, new String[]{"xx"}));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xx", "y"}, new String[]{"y"}));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xx", "y"}, new String[]{"x"}));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xyz"}, new String[]{"x"}));
        assertTrue(TextMatcher.isFilterRelaxed(new String[]{"xyz"}, new String[]{"xy"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[0], new String[]{"abc"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{""}, new String[]{"abc"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{"xyz"}, new String[]{"abc"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{"xyz"}, new String[]{"xyz", "abc"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{"xyz"}, new String[]{"xyz", "xy", "x"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{"xyz", ""}, new String[]{"xyz"}));
        assertFalse(TextMatcher.isFilterRelaxed(new String[]{"xyz", ""}, new String[]{"xyz", "xyz"}));
    }
    
    public void testIsFilterEqual() {
        assertTrue(TextMatcher.isFilterEqual(new String[0], new String[0]));
        assertTrue(TextMatcher.isFilterEqual(new String[]{"x"}, new String[]{"x"}));
        assertTrue(TextMatcher.isFilterEqual(new String[]{"x", "y"}, new String[]{"x", "y"}));
    }
    
    public void testIsFilterConstrained() {
        assertTrue(TextMatcher.isFilterConstrained(new String[0], new String[]{"x"}));
        assertTrue(TextMatcher.isFilterConstrained(new String[]{"x"}, new String[]{"xx"}));
        assertTrue(TextMatcher.isFilterConstrained(new String[]{"x"}, new String[]{"x", "y"}));
        assertTrue(TextMatcher.isFilterConstrained(new String[]{"x"}, new String[]{"xyz"}));
        assertTrue(TextMatcher.isFilterConstrained(new String[]{"xy"}, new String[]{"xyz"}));
        assertTrue(TextMatcher.isFilterConstrained(new String[]{"xyz", "xy", "x"}, new String[]{"xyzz"}));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"abc"}, new String[0]));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"abc"}, new String[]{""}));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"xyz"}, new String[]{"abc"}));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"xyz", "abc"}, new String[]{"xyz"}));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"xyz"}, new String[]{"xyz", ""}));
        assertFalse(TextMatcher.isFilterConstrained(new String[]{"xyz", "xyz"}, new String[]{"xyz", ""}));
    }
    
    public void testConstrainingFilter() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(numbers);
        assertEquals(list, numbers);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        textMatcherEditor.addMatcherEditorListener(counter);
        textMatcherEditor.setFilterText(new String[]{"0"});
        assertEquals(Arrays.asList(new Object[]{"0"}), list);
        counter.assertCounterState(0, 0, 0, 1, 0);
    }
    
    public void testRelaxingFilter() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(numbers);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        textMatcherEditor.addMatcherEditorListener(counter);
        textMatcherEditor.setFilterText(new String[]{"0"});
        assertEquals(Arrays.asList(new Object[]{"0"}), list);
        textMatcherEditor.setFilterText(new String[0]);
        assertEquals(numbers, list);
        counter.assertCounterState(1, 0, 0, 1, 0);
        counter.resetCounterState();
        textMatcherEditor.setFilterText(new String[]{"01"});
        assertEquals(Collections.EMPTY_LIST, list);
        textMatcherEditor.setFilterText(new String[]{"0"});
        assertEquals(Arrays.asList(new Object[]{"0"}), list);
        counter.assertCounterState(0, 0, 0, 1, 1);
        counter.resetCounterState();
        textMatcherEditor.setFilterText(new String[]{"0", "1"});
        assertEquals(Collections.EMPTY_LIST, list);
        textMatcherEditor.setFilterText(new String[]{"0"});
        assertEquals(Arrays.asList(new Object[]{"0"}), list);
        counter.assertCounterState(0, 0, 0, 1, 1);
    }
    
    public void testRelaxAndConstrainFilter() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(monotonicAlphabet);
        String filterText = "";
        for (int i = 0; i < monotonicAlphabet.size(); i++) {
            filterText += i;
            textMatcherEditor.setFilterText(new String[]{filterText});
            assertEquals(monotonicAlphabet.size() - i, list.size());
        }
        for (int i = monotonicAlphabet.size(); i > 0; i--) {
            assertEquals(monotonicAlphabet.size() - i + 1, list.size());
            filterText = filterText.substring(0, filterText.length() - 1);
            textMatcherEditor.setFilterText(new String[]{filterText});
        }
        String[] filterTexts;
        for (int i = 0; i < monotonicAlphabet.size(); i++) {
            filterTexts = new String[i + 1];
            for (int j = 0; j < filterTexts.length; j++) filterTexts[j] = String.valueOf(j);
            textMatcherEditor.setFilterText(filterTexts);
            assertEquals(monotonicAlphabet.size() - i, list.size());
        }
        for (int i = monotonicAlphabet.size(); i > 0; i--) {
            filterTexts = new String[i];
            for (int j = 0; j < filterTexts.length; j++) filterTexts[j] = String.valueOf(j);
            textMatcherEditor.setFilterText(filterTexts);
            assertEquals(monotonicAlphabet.size() - i + 1, list.size());
        }
    }
    
    public void testClearFilter() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(numbers);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        textMatcherEditor.addMatcherEditorListener(counter);
        assertEquals(list, numbers);
        textMatcherEditor.setFilterText(new String[]{"6"});
        counter.assertCounterState(0, 0, 0, 1, 0);
        counter.resetCounterState();
        assertEquals(Arrays.asList(new String[]{"6"}), list);
        textMatcherEditor.setFilterText(new String[0]);
        counter.assertCounterState(1, 0, 0, 0, 0);
        assertEquals(list, numbers);
    }
    
    public void testMatchNonStrings() {
        final TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new IntegerTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.add(new Integer(10));
        list.add(new Integer(3));
        list.add(new Integer(11));
        list.add(new Integer(2));
        list.add(new Integer(12));
        list.add(new Integer(9));
        list.add(new Integer(103));
        list.add(new Integer(7));
        textMatcherEditor.setFilterText(new String[]{"1"});
        assertEquals(4, list.size());
        assertEquals(list.get(0), new Integer(10));
        assertEquals(list.get(1), new Integer(11));
        assertEquals(list.get(2), new Integer(12));
        assertEquals(list.get(3), new Integer(103));
    }
    
    public void testChangeMode() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(monotonicAlphabet);
        textMatcherEditor.setFilterText(new String[]{"789"});
        assertEquals(Arrays.asList(new String[]{"0123456789"}), list);
        textMatcherEditor.setMode(TextMatcherEditor.STARTS_WITH);
        assertEquals(Collections.EMPTY_LIST, list);
        textMatcherEditor.setMode(TextMatcherEditor.CONTAINS);
        assertEquals(Arrays.asList(new String[]{"0123456789"}), list);
        list.clear();
        list.addAll(dictionary);
        assertEquals(Collections.EMPTY_LIST, list);
        textMatcherEditor.setFilterText(new String[]{"act"});
        assertEquals(dictionary, list);
        textMatcherEditor.setMode(TextMatcherEditor.STARTS_WITH);
        assertEquals(Arrays.asList(new String[]{"act", "actor"}), list);
        textMatcherEditor.setMode(TextMatcherEditor.CONTAINS);
        assertEquals(dictionary, list);
    }
    
    public void testChangeModeNotifications() {
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList list = new FilterList(new BasicEventList(), textMatcherEditor);
        list.addAll(monotonicAlphabet);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        textMatcherEditor.addMatcherEditorListener(counter);
        assertEquals(TextMatcherEditor.CONTAINS, textMatcherEditor.getMode());
        textMatcherEditor.setMode(TextMatcherEditor.STARTS_WITH);
        assertEquals(TextMatcherEditor.STARTS_WITH, textMatcherEditor.getMode());
        counter.assertCounterState(0, 0, 0, 0, 0);
        textMatcherEditor.setMode(TextMatcherEditor.CONTAINS);
        assertEquals(TextMatcherEditor.CONTAINS, textMatcherEditor.getMode());
        counter.assertCounterState(0, 0, 0, 0, 0);
        textMatcherEditor.setFilterText(new String[]{"012"});
        counter.assertCounterState(0, 0, 0, 1, 0);
        counter.resetCounterState();
        textMatcherEditor.setMode(TextMatcherEditor.STARTS_WITH);
        assertEquals(TextMatcherEditor.STARTS_WITH, textMatcherEditor.getMode());
        counter.assertCounterState(0, 0, 0, 1, 0);
        textMatcherEditor.setMode(TextMatcherEditor.CONTAINS);
        assertEquals(TextMatcherEditor.CONTAINS, textMatcherEditor.getMode());
        counter.assertCounterState(0, 0, 0, 1, 1);
    }
    
    /**
     * Test to verify that the filter is working correctly when values
     * are being added to a list.
     */
    public void testFilterBeforeAndAfter() {
        EventList unfilteredList = new BasicEventList();
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList filteredList = new FilterList(unfilteredList, textMatcherEditor);
        String filter = "7";
        textMatcherEditor.setFilterText(new String[]{filter});
        for (int i = 1000; i < 2000; i++) {
            unfilteredList.add(String.valueOf(i));
        }
        List controlList = new ArrayList();
        for (Iterator i = unfilteredList.iterator(); i.hasNext(); ) {
            String element = (String)(String)i.next();
            if (element.indexOf(filter) != -1) controlList.add(element);
        }
        assertEquals(controlList, filteredList);
        textMatcherEditor.setFilterText(new String[]{});
        assertEquals(filteredList, unfilteredList);
        textMatcherEditor.setFilterText(new String[]{filter});
        assertEquals(controlList, filteredList);
    }
    
    /**
     * Test to verify that the filter is working correctly when the list
     * is changing by adds, removes and deletes.
     */
    public void testFilterDynamic() {
        Random random = new Random();
        EventList unfilteredList = new BasicEventList();
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList filteredList = new FilterList(unfilteredList, textMatcherEditor);
        String filter = "5";
        textMatcherEditor.setFilterText(new String[]{filter});
        for (int i = 0; i < 4000; i++) {
            int operation = random.nextInt(4);
            int value = random.nextInt(10);
            int index = unfilteredList.isEmpty() ? 0 : random.nextInt(unfilteredList.size());
            if (operation <= 1 || unfilteredList.isEmpty()) {
                unfilteredList.add(index, String.valueOf(value));
            } else if (operation == 2) {
                unfilteredList.remove(index);
            } else if (operation == 3) {
                unfilteredList.set(index, String.valueOf(value));
            }
        }
        List controlList = new ArrayList();
        for (Iterator i = unfilteredList.iterator(); i.hasNext(); ) {
            String element = (String)(String)i.next();
            if (element.indexOf(filter) != -1) controlList.add(element);
        }
        assertEquals(controlList, filteredList);
    }
    
    /**
     * Test to verify that the filter correctly handles modification.
     *
     * This performs a sequence of operations. Each operation is performed on
     * either the filtered list or the unfiltered list. The list where the
     * operation is performed is selected at random.
     */
    public void testFilterWritable() {
        Random random = new Random();
        EventList unfilteredList = new BasicEventList();
        TextMatcherEditor textMatcherEditor = new TextMatcherEditor(new StringTextFilterator());
        FilterList filteredList = new FilterList(unfilteredList, textMatcherEditor);
        String filter = "5";
        textMatcherEditor.setFilterText(new String[]{filter});
        for (int i = 0; i < 4000; i++) {
            List list;
            if (random.nextBoolean()) list = filteredList; else list = unfilteredList;
            int operation = random.nextInt(4);
            int value = random.nextInt(10);
            int index = list.isEmpty() ? 0 : random.nextInt(list.size());
            if (operation <= 1 || list.isEmpty()) {
                list.add(index, String.valueOf(value));
            } else if (operation == 2) {
                list.remove(index);
            } else if (operation == 3) {
                list.set(index, String.valueOf(value));
            }
        }
        List controlList = new ArrayList();
        for (Iterator i = unfilteredList.iterator(); i.hasNext(); ) {
            String element = (String)(String)i.next();
            if (element.indexOf(filter) != -1) controlList.add(element);
        }
        assertEquals(controlList, filteredList);
    }
    
    /**
     * Intentionally add raw Integers into the list with this TextFilterator in
     * order to validate that TextFilterator is always backwards compatible with
     * old behaviour. (Namely that the .toString() value is used for filtering
     * all of the filterator's object)
     */
    private static class IntegerTextFilterator implements TextFilterator {
        
        private IntegerTextFilterator() {
            super();
        }
        
        public void getFilterStrings(List x0, Object x1) {
            List baseList = (List)x0;
            Integer element = (Integer)x1;
            ((List)baseList).add(element);
        }
        /*missing*/
    }
}
