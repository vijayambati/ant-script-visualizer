package ca.odell.glazedlists;

import ca.odell.glazedlists.matchers.*;
import java.util.*;

/**
 * A MatcherEditor for minimum Number values.
 */
class MinimumNumberMatcherEditor extends AbstractMatcherEditor {
    private int minimum = 0;
    
    public MinimumNumberMatcherEditor() {
        super();
        currentMatcher = new MinimumNumberMatcher(0);
    }
    
    public void setMinimum(int value) {
        if (value < minimum) {
            this.minimum = value;
            fireRelaxed(new MinimumNumberMatcher(minimum));
        } else if (value == minimum) {
        } else {
            this.minimum = value;
            fireConstrained(new MinimumNumberMatcher(minimum));
        }
    }
}
