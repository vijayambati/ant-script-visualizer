package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

class Truck extends Automobile implements SupportsTrailerHitch {
    private int numSeats;
    private Automobile towedVehicle;
    
    public Truck(int seats) {
        super(false);
    }
    
    public int getNumSeats() {
        return numSeats;
    }
    
    public void setTowedVehicle(Automobile towedVehicle) {
        this.towedVehicle = towedVehicle;
    }
    
    public Automobile getTowedVehicle() {
        return towedVehicle;
    }
}
