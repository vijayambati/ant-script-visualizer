package ca.odell.glazedlists;

import java.util.*;

/**
 * The ThreadedCompositeRunner is a manually-executed test that verifies that
 * the CompositeList is thread safe. It creates a handful of threads that write
 * and read composite lists.
 *
 * <p>To verify that deadlocks are not occuring, each thread updates its time variable
 * with the current time. One extra thread cycles through examining the clock
 * variables and prints the time of the oldest thread. If such a variable never
 * increments, we have a deadlock!
 *
 * @author <a href="mailto:kevin@swank.ca">Kevin Maltby</a>
 */
public class ThreadedCompositeRunner {
    
    public ThreadedCompositeRunner() {
        super();
    }
    
    /**
     * the global clock of the threaded composite runner 
     */
    private int clock = 0;
    
    /**
     * A clocked thread is a thread that records the most recent time
     * it performed an operation.
     */
    abstract class ClockedThread implements Runnable {
        
        ClockedThread() {
            super();
        }
        private int time = 0;
        
        public int getTime() {
            synchronized (ThreadedCompositeRunner.this) {
                return time;
            }
        }
        
        protected void stampTime() {
            synchronized (ThreadedCompositeRunner.this) {
                time = clock;
            }
        }
    }
    
    /**
     * The reader thread alternates between reading a single random value
     * and reading the entire list.
     */
    class ReaderThread extends ClockedThread {
        private EventList listToRead;
        private Random dice = new Random();
        
        public ReaderThread(EventList listToRead) {
            super();
            this.listToRead = listToRead;
        }
        
        public void run() {
            while (true) {
                listToRead.getReadWriteLock().readLock().lock();
                if (listToRead.size() > 0) {
                    listToRead.get(dice.nextInt(listToRead.size()));
                }
                listToRead.getReadWriteLock().readLock().unlock();
                listToRead.getReadWriteLock().readLock().lock();
                listToRead.toArray();
                listToRead.getReadWriteLock().readLock().unlock();
                stampTime();
                Thread.yield();
            }
        }
    }
    
    /**
     * The writer thread alternates between inserting a single random value
     * and removing a single random value.
     */
    class WriterThread extends ClockedThread {
        private EventList listToWrite;
        private Random dice = new Random();
        
        public WriterThread(EventList listToWrite) {
            super();
            this.listToWrite = listToWrite;
        }
        
        public void run() {
            while (true) {
                int repeat = dice.nextInt(1000);
                for (int i = 0; i < repeat; i++) {
                    listToWrite.add(dice.nextInt(i + 1), Boolean.TRUE);
                    stampTime();
                    Thread.yield();
                }
                while (!listToWrite.isEmpty()) {
                    listToWrite.remove(dice.nextInt(listToWrite.size()));
                    stampTime();
                    Thread.yield();
                }
            }
        }
    }
    
    /**
     * The main method starts this experiment.
     */
    public static void main(String[] args) {
        new ThreadedCompositeRunner().run(args);
    }
    
    /**
     * Starts a series of reader and writer threads and verifies that they
     * continue reading and writing.
     */
    public void run(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: ThreadedCompositeRunner <writer count> <reader count> <composite size>");
            System.out.println("");
            System.out.println("writer count: The number of writer threads, each writing their own BasicEventList");
            System.out.println("reader count: The number of reader threads, each reading a CompositeList");
            System.out.println("composite size: The number of writer lists per CompositeList");
            System.out.println("");
            System.out.println("The application starts threads for the writers and readers. Then one extra thread");
            System.out.println("called the coordinator asks each thread the time that they last completed an");
            System.out.println("operation. This is equivalent to asking each thread whether it has deadlocked yet.");
            System.out.println("A thread that has deadlocked will have a last-operation-time value that never");
            System.out.println("increments. The coordinator prints the oldest last-operation-time and the current");
            System.out.println("time. If the oldest last-operation-time has not incremented since last check, the");
            System.out.println("coordinator only prints the current time. A user can tell that a thread has deadlocked");
            System.out.println("if the clock value is printed repeatedly but the oldest last-operation-time no longer");
            System.out.println("increments.");
            return;
        }
        int writerCount = Integer.parseInt(args[0]);
        int readerCount = Integer.parseInt(args[1]);
        int compositeSize = Integer.parseInt(args[2]);
        Random dice = new Random();
        List lists = new ArrayList();
        List threads = new ArrayList();
        for (int i = 0; i < writerCount; i++) {
            BasicEventList list = new BasicEventList();
            lists.add(list);
            WriterThread thread = new WriterThread(list);
            threads.add(thread);
        }
        List compositeLists = new ArrayList();
        for (int i = 0; i < readerCount; i++) {
            CompositeList compositeList = new CompositeList();
            for (int j = 0; j < compositeSize; j++) {
                compositeList.addMemberList((EventList)(EventList)lists.get(dice.nextInt(lists.size())));
            }
            compositeLists.add(compositeList);
            ReaderThread readerThread = new ReaderThread(compositeList);
            threads.add(readerThread);
        }
        int threadId = 100;
        for (Iterator i = threads.iterator(); i.hasNext(); ) {
            ClockedThread runnable = (ClockedThread)(ThreadedCompositeRunner.ClockedThread)i.next();
            new Thread(runnable, "T" + threadId++).start();
        }
        int lastMinTime = -1;
        while (true) {
            int minTime = clock;
            for (Iterator i = threads.iterator(); i.hasNext(); ) {
                ClockedThread thread = (ClockedThread)(ThreadedCompositeRunner.ClockedThread)i.next();
                int threadTime = thread.getTime();
                if (threadTime < minTime) minTime = threadTime;
            }
            if (minTime > lastMinTime) {
                System.out.println("CLOCK " + clock + " MINTIME " + minTime);
                lastMinTime = minTime;
            } else {
                if (clock % 100 == 0) System.out.println("CLOCK " + clock);
            }
            synchronized (ThreadedCompositeRunner.this) {
                clock++;
            }
            Thread.yield();
        }
    }
}
