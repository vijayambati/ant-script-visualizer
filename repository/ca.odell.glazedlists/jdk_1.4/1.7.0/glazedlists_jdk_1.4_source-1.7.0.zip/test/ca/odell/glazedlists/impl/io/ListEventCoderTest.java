package ca.odell.glazedlists.impl.io;

import java.util.*;
import ca.odell.glazedlists.*;
import ca.odell.glazedlists.io.*;
import java.io.*;
import junit.framework.*;

/**
 * Tests the ListEventCoder.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ListEventCoderTest extends TestCase {
    
    public ListEventCoderTest() {
        super();
    }
    
    /**
     * encodes java.lang.Integer 
     */
    private ByteCoder intCoder = new IntegerCoder();
    
    /**
     * Tests that a list event can be encoded and decoded.
     */
    public void testEncodeDecode() throws IOException {
        EventList toEncode = new BasicEventList();
        EventEncoderListener encoder = new EventEncoderListener(intCoder);
        toEncode.addListEventListener(encoder);
        EventList toDecode = new BasicEventList();
        toEncode.add(new Integer(8));
        Bufferlo add8Encoding = (Bufferlo)(Bufferlo)encoder.getEncodings().remove(0);
        ListEventToBytes.toListEvent(add8Encoding, toDecode, intCoder);
        assertEquals(toEncode, toDecode);
        List addAll = Arrays.asList(new Object[]{new Integer(6), new Integer(7), new Integer(5), new Integer(3), new Integer(0), new Integer(9)});
        toEncode.addAll(addAll);
        Bufferlo addAllEncoding = (Bufferlo)(Bufferlo)encoder.getEncodings().remove(0);
        ListEventToBytes.toListEvent(addAllEncoding, toDecode, intCoder);
        assertEquals(toEncode, toDecode);
    }
    
    /**
     * Tests that a snapshot can be decoded.
     */
    public void testSnapshotDecode() throws IOException {
        EventList toEncode = new BasicEventList();
        EventList toDecode = new BasicEventList();
        toDecode.add(new Integer(1));
        toDecode.add(new Integer(2));
        toDecode.add(new Integer(4));
        List entireList = Arrays.asList(new Object[]{new Integer(8), new Integer(6), new Integer(7), new Integer(5), new Integer(3), new Integer(0), new Integer(9)});
        toEncode.addAll(entireList);
        Bufferlo entireListEncoding = ListEventToBytes.toBytes(toEncode, intCoder);
        ListEventToBytes.toListEvent(entireListEncoding, toDecode, intCoder);
        assertEquals(toEncode, toDecode);
    }
}
