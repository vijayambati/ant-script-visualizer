package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.BasicEventList;
import javax.swing.*;

/**
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class JEventListPanelTest extends SwingTestCase {
    
    public JEventListPanelTest() {
        super();
    }
    
    /**
     * Tests the user interface. This is a mandatory method in SwingTestCase classes.
     */
    public void testGui() {
        super.testGui();
    }
    
    /**
     * Verifies that JEventListPanel works with all operations in sequence.
     */
    public void guiTestAddUpdateDelete() {
        EventList checkBoxes = new BasicEventList();
        JEventListPanel checkboxPanel = new JEventListPanel(checkBoxes, new CheckBoxFormat());
        checkBoxes.add(new JCheckBox("Saskatchewan"));
        checkBoxes.add(new JCheckBox("Manitoba"));
        checkBoxes.set(0, new JCheckBox("Ontario"));
        checkBoxes.remove(1);
        checkBoxes.remove(0);
    }
    
    /**
     * Trivial implementation of {@link JEventListPanel.Format} for testing.
     */
    class CheckBoxFormat extends JEventListPanel.AbstractFormat {
        
        public CheckBoxFormat() {
            super("pref", "pref", null, null, new String[]{"1, 1"});
        }
        
        public JComponent getComponent(Object x0, int x1) {
            JCheckBox element = (JCheckBox)x0;
            int component = (int)x1;
            return element;
        }
        /*missing*/
    }
}
