package ca.odell.glazedlists;

import ca.odell.glazedlists.impl.GlazedListsImpl;
import junit.framework.TestCase;
import java.util.Comparator;
import java.util.Date;

public class SequenceListTest extends TestCase {
    
    public SequenceListTest() {
        super();
    }
    private static final Date apr = GlazedListsTests.createDate(2006, 3, 15);
    private static final Date may = GlazedListsTests.createDate(2006, 4, 15);
    private static final Date jun = GlazedListsTests.createDate(2006, 5, 15);
    private static final Date jul = GlazedListsTests.createDate(2006, 6, 15);
    private static final Date aug = GlazedListsTests.createDate(2006, 7, 15);
    private static final Date sep = GlazedListsTests.createDate(2006, 8, 15);
    
    public void testConstructor() {
        try {
            new SequenceList(new BasicEventList(), null);
            fail();
        } catch (IllegalArgumentException e) {
        }
        try {
            new SequenceList(new BasicEventList(), null, (Comparator)GlazedLists.comparableComparator());
            fail();
        } catch (IllegalArgumentException e) {
        }
        try {
            new SequenceList(new BasicEventList(), Sequencers.monthSequencer(), null);
            fail();
        } catch (IllegalArgumentException e) {
        }
        new SequenceList(new BasicEventList(), Sequencers.monthSequencer());
        new SequenceList(new BasicEventList(), Sequencers.monthSequencer(), (Comparator)GlazedLists.comparableComparator());
        final EventList source = new BasicEventList();
        source.add(apr);
        source.add(aug);
        final SequenceList sequence = new SequenceList(source, Sequencers.monthSequencer());
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
    }
    
    public void testAdd() {
        final EventList source = new BasicEventList();
        final SequenceList sequence = new SequenceList(source, Sequencers.monthSequencer());
        ListConsistencyListener.install(sequence);
        source.add(jun);
        assertEquals(2, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(1));
        source.add(aug);
        assertEquals(4, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(3));
        source.add(apr);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
        source.add(apr);
        source.add(may);
        source.add(jun);
        source.add(jul);
        source.add(aug);
        assertEquals(6, sequence.size());
    }
    
    public void testRemove() {
        final EventList source = new BasicEventList();
        final SequenceList sequence = new SequenceList(source, Sequencers.monthSequencer());
        ListConsistencyListener.install(sequence);
        source.add(apr);
        source.add(jun);
        source.add(aug);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
        source.remove(apr);
        assertEquals(4, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(3));
        source.remove(aug);
        assertEquals(2, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(1));
        source.remove(jun);
        assertEquals(0, sequence.size());
        source.add(apr);
        source.add(jun);
        source.add(aug);
        assertEquals(6, sequence.size());
        source.remove(jun);
        assertEquals(6, sequence.size());
        source.clear();
        assertEquals(0, sequence.size());
    }
    
    public void testSet() {
        final EventList source = new BasicEventList();
        final SequenceList sequence = new SequenceList(source, Sequencers.monthSequencer());
        ListConsistencyListener.install(sequence);
        source.add(apr);
        source.add(jun);
        source.add(aug);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
        source.set(0, may);
        assertEquals(5, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(4));
        source.set(0, apr);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
        source.set(source.size() - 1, jul);
        assertEquals(5, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        source.set(source.size() - 1, aug);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
        source.set(1, may);
        assertEquals(6, sequence.size());
        assertEquals(GlazedListsImpl.getMonthBegin(apr), sequence.get(0));
        assertEquals(GlazedListsImpl.getMonthBegin(may), sequence.get(1));
        assertEquals(GlazedListsImpl.getMonthBegin(jun), sequence.get(2));
        assertEquals(GlazedListsImpl.getMonthBegin(jul), sequence.get(3));
        assertEquals(GlazedListsImpl.getMonthBegin(aug), sequence.get(4));
        assertEquals(GlazedListsImpl.getMonthBegin(sep), sequence.get(5));
    }
}
