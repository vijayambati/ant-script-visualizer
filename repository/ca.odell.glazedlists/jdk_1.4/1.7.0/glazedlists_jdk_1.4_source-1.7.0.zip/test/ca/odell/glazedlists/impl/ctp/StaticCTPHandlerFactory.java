package ca.odell.glazedlists.impl.ctp;

import java.util.*;
import java.io.*;

/**
 * A static handler for handing predictable test data.
 */
class StaticCTPHandlerFactory implements CTPHandlerFactory {
    
    StaticCTPHandlerFactory() {
        super();
    }
    private List handlers = new ArrayList();
    
    public void addHandler(CTPHandler handler) {
        handlers.add(handler);
    }
    
    public CTPHandler constructHandler() {
        if (handlers.isEmpty()) throw new IllegalStateException("No more handlers");
        return (CTPHandler)(CTPHandler)handlers.remove(0);
    }
}
