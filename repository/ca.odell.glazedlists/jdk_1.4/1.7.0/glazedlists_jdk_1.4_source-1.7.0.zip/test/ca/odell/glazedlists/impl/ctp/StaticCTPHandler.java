package ca.odell.glazedlists.impl.ctp;

import java.util.*;
import ca.odell.glazedlists.impl.io.Bufferlo;
import java.text.ParseException;
import java.io.*;

/**
 * A CTPHandler where all data is known beforehand.
 */
class StaticCTPHandler implements CTPHandler {
    
    StaticCTPHandler() {
        super();
    }
    
    /**
     * the actions to be performed on this connection 
     */
    private List tasks = new ArrayList();
    
    /**
     * whether this connection has connected 
     */
    private boolean ready = false;
    
    /**
     * whether this connection has disconnected 
     */
    private boolean closed = false;
    
    /**
     * the reason this connection was closed 
     */
    private Exception closeReason = null;
    
    /**
     * the connection being handled 
     */
    private CTPConnection connection = null;
    
    /**
     * the incoming data 
     */
    private Bufferlo incoming = new Bufferlo();
    
    /**
     * Add expected incoming data.
     */
    public void addExpected(String data) {
        tasks.add(new Expected(data));
    }
    
    /**
     * Add queued outgoing data.
     */
    public void addEnqueued(String data) {
        tasks.add(new Enqueued(data));
    }
    
    /**
     * Notify that this connection is ready for use.
     */
    public synchronized void connectionReady(CTPConnection source) {
        if (ready) throw new IllegalStateException("Connection already ready");
        ready = true;
        this.connection = source;
        handlePendingTasks();
    }
    
    /**
     * Handle the specified incoming data.
     */
    public synchronized void receiveChunk(CTPConnection source, Bufferlo data) {
        incoming.append(data);
        try {
            while (incoming.length() > 0) {
                Expected expected = (Expected)(Expected)tasks.get(0);
                boolean consumed = expected.tryConsume(incoming);
                if (!consumed) return;
                tasks.remove(0);
                handlePendingTasks();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Notify that this connection is no longer ready for use.
     */
    public synchronized void connectionClosed(CTPConnection source, Exception closeReason) {
        if (closed) throw new IllegalStateException("Connection already closed");
        closed = true;
        connection = null;
        if (!tasks.isEmpty()) throw new IllegalStateException("Closed prematurely! " + tasks.size() + " Pending tasks " + tasks + ", reason " + closeReason);
        this.closeReason = closeReason;
        notifyAll();
    }
    
    /**
     * Handle pending tasks that can be performed immediately.
     */
    private void handlePendingTasks() {
        while (tasks.size() > 0 && tasks.get(0) instanceof Enqueued) {
            Enqueued enqueued = (Enqueued)(Enqueued)tasks.remove(0);
            connection.sendChunk(enqueued.getData());
        }
        if (tasks.isEmpty()) {
            notifyAll();
        }
    }
    
    /**
     * Close this connection.
     */
    public synchronized void close() {
        if (closed) return;
        if (!ready) throw new IllegalStateException("Connection not established");
        connection.close();
    }
    
    /**
     * Ensures that this handler has completed its tasks. If it has not, a RuntimeException
     * shall be thrown.
     */
    public synchronized void assertComplete(long timeout) {
        if (!tasks.isEmpty()) {
            try {
                wait(timeout);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        if (!tasks.isEmpty()) throw new IllegalStateException(tasks.size() + " uncompleted tasks " + tasks + ", pending data \"" + incoming + "\"");
    }
    
    /**
     * Ensures that this handler has been closed.
     */
    public synchronized Exception assertClosed(long timeout) {
        if (!closed) {
            try {
                wait(timeout);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        if (!closed) throw new IllegalStateException("Open connection with " + tasks.size() + " uncompleted tasks");
        return closeReason;
    }
}
