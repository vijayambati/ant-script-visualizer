package ca.odell.glazedlists;

import ca.odell.glazedlists.impl.beans.JavaBeanEventListConnector;
import junit.framework.TestCase;
import javax.swing.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

/**
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ObservableElementListTest extends TestCase {
    private ObservableElementList labels;
    private ListConsistencyListener counter;
    
    public ObservableElementListTest() {
        super("Observable Elements - RFE 157");
    }
    
    public void setUp() {
        labels = new ObservableElementList(new BasicEventList(), GlazedLists.beanConnector(JLabel.class));
        counter = ListConsistencyListener.install(labels);
        assertEquals(0, counter.getEventCount());
    }
    
    public void tearDown() {
        labels = null;
        counter = null;
    }
    
    /**
     * Tests ObservableEleemntLists' handling of JavaBean PropertyChangeEvents
     */
    public void testJavabeans() {
        JLabel ottawa = new JLabel("Rough Riders");
        JLabel wrestling = new JLabel("WWF");
        labels.add(ottawa);
        labels.add(wrestling);
        assertEquals(2, counter.getEventCount());
        ottawa.setText("Renegades");
        assertEquals(3, counter.getEventCount());
        assertEquals(1, counter.getChangeCount(2));
        wrestling.setText("WWE");
        assertEquals(4, counter.getEventCount());
        assertEquals(1, counter.getChangeCount(3));
    }
    
    public void testAddRemoveListeners() {
        final JLabel listElement1 = new JLabel();
        final JLabel listElement2 = new JLabel();
        final int initialListenerCount = listElement1.getPropertyChangeListeners().length;
        labels.add(listElement1);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        labels.remove(listElement1);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        labels.add(listElement1);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        labels.set(0, null);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        labels.set(0, listElement1);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        labels.set(0, listElement2);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        assertEquals(initialListenerCount + 1, listElement2.getPropertyChangeListeners().length);
        labels.add(listElement2);
        assertEquals(initialListenerCount + 2, listElement2.getPropertyChangeListeners().length);
        labels.remove(0);
        assertEquals(initialListenerCount + 1, listElement2.getPropertyChangeListeners().length);
        labels.remove(0);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        assertEquals(initialListenerCount, listElement2.getPropertyChangeListeners().length);
    }
    
    public void testConstructor() {
        try {
            new ObservableElementList(new BasicEventList(), null);
            fail("Failed to receive a NullPointerException on null connector argument");
        } catch (NullPointerException npe) {
        }
        try {
            new ObservableElementList(null, GlazedLists.beanConnector(JLabel.class));
            fail("Failed to receive a NullPointerException on null source list");
        } catch (NullPointerException npe) {
        }
        new ObservableElementList(new BasicEventList(), GlazedLists.beanConnector(JLabel.class));
        final JLabel listElement1 = new JLabel();
        final int initialListenerCount = listElement1.getPropertyChangeListeners().length;
        final BasicEventList source = new BasicEventList();
        source.add(listElement1);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        ObservableElementList list = new ObservableElementList(source, GlazedLists.beanConnector(JLabel.class));
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        list.remove(listElement1);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
    }
    
    public void testDisposeSingleEventList() {
        this.runTestDispose(this.labels);
        this.runTestDispose(new ObservableElementList(new BasicEventList(), new MultiEventListJLabelConnector(false)));
    }
    
    private void runTestDispose(ObservableElementList labels) {
        final JLabel listElement1 = new JLabel();
        final int initialListenerCount = listElement1.getPropertyChangeListeners().length;
        labels.add(listElement1);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        labels.dispose();
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        assertTrue(listElement1 == labels.get(0));
        labels.remove(0);
        assertTrue(labels.isEmpty());
    }
    
    public void testPickyConnector() {
        this.runTestPickyConnector(new ObservableElementList(new BasicEventList(), new PickyJLabelConnector()));
        this.runTestPickyConnector(new ObservableElementList(new BasicEventList(), new MultiEventListJLabelConnector(true)));
    }
    
    private void runTestPickyConnector(ObservableElementList list) {
        final JLabel listElement1 = new JLabel();
        final int initialListenerCount = listElement1.getPropertyChangeListeners().length;
        list.add(listElement1);
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
        list.add(listElement1);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        list.remove(0);
        assertEquals(initialListenerCount + 1, listElement1.getPropertyChangeListeners().length);
        list.remove(0);
        assertTrue(list.isEmpty());
        assertEquals(initialListenerCount, listElement1.getPropertyChangeListeners().length);
    }
    
    public void testLateBloomingMultiEventListConnector() {
        final int bloomCount = 5;
        final ObservableElementList list = new ObservableElementList(new BasicEventList(), new LateBloomingMultiEventListJLabelConnector(bloomCount));
        final JLabel listElement1 = new JLabel();
        final int initialListenerCount1 = listElement1.getPropertyChangeListeners().length;
        for (int i = 0; i < bloomCount; i++) list.add(listElement1);
        assertEquals(initialListenerCount1 + bloomCount, listElement1.getPropertyChangeListeners().length);
        for (int i = 0; i < bloomCount; i++) list.add(listElement1);
        assertEquals(initialListenerCount1 + 2 * bloomCount, listElement1.getPropertyChangeListeners().length);
        final PropertyChangeListener[] propertyChangeListeners = listElement1.getPropertyChangeListeners();
        List listeners = new ArrayList();
        Set uniqueListeners = new HashSet();
        for (int i = 0; i < propertyChangeListeners.length; i++) {
            if (!(propertyChangeListeners[i] instanceof JavaBeanEventListConnector.PropertyChangeHandler)) continue;
            listeners.add(propertyChangeListeners[i]);
            uniqueListeners.add(propertyChangeListeners[i]);
        }
        assertEquals(bloomCount * 2, listeners.size());
        assertEquals(bloomCount + 1, uniqueListeners.size());
        final JLabel listElement2 = new JLabel();
        final int initialListenerCount2 = listElement2.getPropertyChangeListeners().length;
        list.add(listElement2);
        assertEquals(initialListenerCount2 + 1, listElement2.getPropertyChangeListeners().length);
        list.remove(listElement2);
        assertEquals(initialListenerCount2, listElement2.getPropertyChangeListeners().length);
        for (int i = 1; i < 2 * bloomCount + 1; i++) {
            list.remove(0);
            assertEquals(initialListenerCount1 + 2 * bloomCount - i, listElement1.getPropertyChangeListeners().length);
        }
    }
    
    public void testMultithreadedUpdate() throws InterruptedException {
        final LazyThreadedConnector connector = new LazyThreadedConnector();
        final ObservableElementList list = new ObservableElementList(new BasicEventList(), connector);
        final JLabel listElement1 = new JLabel();
        list.add(listElement1);
        listElement1.setText("testing");
        list.remove(0);
        final Thread updateThread = connector.getLastUpdateThread();
        assertTrue(updateThread.isAlive());
        updateThread.join();
        assertEquals(false, connector.isExitDueToException());
    }
    
    /**
     * This connector installs a common JavaBean listener on every element
     * until bloomCount has been reached, when it begins installing unique
     * listeners on each additional element.
     */
    private class LateBloomingMultiEventListJLabelConnector extends MultiEventListJLabelConnector {
        private int elementCount = 0;
        private final int bloomCount;
        
        public LateBloomingMultiEventListJLabelConnector(int bloomCount) {
            super(false);
            this.bloomCount = bloomCount;
        }
        
        public EventListener installListener(Object x0) {
            JLabel element = (JLabel)x0;
            if (this.elementCount++ < this.bloomCount) {
                element.addPropertyChangeListener(this.propertyChangeListener);
                return this.propertyChangeListener;
            }
            return super.installListener(element);
        }
        /*missing*/
    }
    
    /**
     * This connector only installs JavaBean listeners on every second element
     * that is added to the associated {@link ObservableElementList} if the picky
     * flag is set to true.
     */
    private class MultiEventListJLabelConnector extends JavaBeanEventListConnector {
        private final boolean picky;
        private int elementCount = 0;
        
        public MultiEventListJLabelConnector(boolean picky) {
            super(JLabel.class);
            this.picky = picky;
        }
        
        public EventListener installListener(Object x0) {
            JLabel element = (JLabel)x0;
            if (this.picky && this.elementCount++ % 2 == 0) return null;
            final PropertyChangeListener propertyChangeHandler = new PropertyChangeHandler();
            element.addPropertyChangeListener(propertyChangeHandler);
            return propertyChangeHandler;
        }
        
        public void uninstallListener(Object x0, EventListener x1) {
            JLabel element = (JLabel)x0;
            EventListener listener = (EventListener)x1;
            element.removePropertyChangeListener((PropertyChangeListener)(PropertyChangeListener)listener);
        }
        /*missing*/
        /*missing*/
    }
    
    /**
     * This connector only installs JavaBean listeners on every second element
     * that is added to the associated {@link ObservableElementList}.
     */
    private class PickyJLabelConnector extends JavaBeanEventListConnector {
        private int elementCount = 0;
        
        public PickyJLabelConnector() {
            super(JLabel.class);
        }
        
        public EventListener installListener(Object x0) {
            JLabel element = (JLabel)x0;
            if (this.elementCount++ % 2 == 0) return null;
            return super.installListener(element);
        }
        /*missing*/
    }
    
    /**
     * This connector only installs JavaBean listeners on every second element
     * that is added to the associated {@link ObservableElementList}.
     */
    private class LazyThreadedConnector extends JavaBeanEventListConnector {
        private Thread lastUpdateThread;
        private boolean exitDueToException = false;
        
        public LazyThreadedConnector() {
            super(JLabel.class);
        }
        
        protected PropertyChangeListener createPropertyChangeListener() {
            return new LazyThreadedPropertyChangeHandler();
        }
        
        public Thread getLastUpdateThread() {
            return lastUpdateThread;
        }
        
        public boolean isExitDueToException() {
            return exitDueToException;
        }
        
        /**
         * The PropertyChangeListener which notifies the
         * {@link ObservableElementList} within this Connector of changes to
         * list elements.
         */
        protected class LazyThreadedPropertyChangeHandler extends PropertyChangeHandler {
            
            protected LazyThreadedPropertyChangeHandler() {
                super();
            }
            
            public void propertyChange(final PropertyChangeEvent event) {
                lastUpdateThread = new Thread(new DelayThenNotifyRunnable(event, this));
                lastUpdateThread.start();
            }
        }
        
        private class DelayThenNotifyRunnable implements Runnable {
            private PropertyChangeEvent event;
            private LazyThreadedPropertyChangeHandler handler;
            
            public DelayThenNotifyRunnable(PropertyChangeEvent event, LazyThreadedPropertyChangeHandler handler) {
                super();
                this.event = event;
                this.handler = handler;
            }
            
            public void run() {
                try {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                    }
                    handler.propertyChange(event);
                } catch (Exception e) {
                    exitDueToException = true;
                }
            }
        }
    }
}
