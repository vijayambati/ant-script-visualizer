package ca.odell.glazedlists.impl.ctp;

import java.util.*;
import ca.odell.glazedlists.impl.io.Bufferlo;
import java.text.ParseException;
import java.io.*;

/**
 * Models an expected incoming chunk.
 */
class Expected {
    
    /**
     * the expected data 
     */
    private String expected = null;
    
    /**
     * Creates a new expectation of the specified data.
     */
    public Expected(String charData) {
        super();
        this.expected = charData;
    }
    
    /**
     * Consumes the specified data, which must match the expected data. If this does
     * not match, an Exception was thrown.
     *
     * @return the number of bytes remaining to be consumed.
     */
    public boolean tryConsume(Bufferlo lunch) throws IOException, ParseException {
        if (lunch.length() < expected.length()) return false;
        lunch.consume(expected);
        expected = null;
        return true;
    }
    
    /**
     * Whether this has been satisfied.
     */
    private boolean done() {
        return (expected == null);
    }
    
    /**
     *
     * Print the expected string.
     */
    public String toString() {
        if (expected.length() > 30) return "Expected \"" + expected.length() + ":" + expected.substring(0, 30) + "\""; else return "Expected \"" + expected + "\"";
    }
}
