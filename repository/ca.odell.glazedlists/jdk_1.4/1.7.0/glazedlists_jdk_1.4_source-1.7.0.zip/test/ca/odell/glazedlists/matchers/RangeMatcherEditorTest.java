package ca.odell.glazedlists.matchers;

import ca.odell.glazedlists.GlazedListsTests;
import junit.framework.TestCase;
import java.util.Date;

public class RangeMatcherEditorTest extends TestCase {
    
    public RangeMatcherEditorTest() {
        super();
    }
    private static final Date apr = GlazedListsTests.createDate(2006, 3, 15);
    private static final Date may = GlazedListsTests.createDate(2006, 4, 15);
    private static final Date jun = GlazedListsTests.createDate(2006, 5, 15);
    private static final Date jul = GlazedListsTests.createDate(2006, 6, 15);
    private static final Date aug = GlazedListsTests.createDate(2006, 7, 15);
    private static final Date sep = GlazedListsTests.createDate(2006, 8, 15);
    
    public void testSetRange() {
        final RangeMatcherEditor matcherEditor = new RangeMatcherEditor();
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        matcherEditor.addMatcherEditorListener(counter);
        counter.assertCounterState(0, 0, 0, 0, 0);
        matcherEditor.setRange(may, jul);
        counter.assertCounterState(0, 0, 0, 1, 0);
        matcherEditor.setRange(may, aug);
        counter.assertCounterState(0, 0, 0, 1, 1);
        matcherEditor.setRange(apr, aug);
        counter.assertCounterState(0, 0, 0, 1, 2);
        matcherEditor.setRange(apr, jul);
        counter.assertCounterState(0, 0, 0, 2, 2);
        matcherEditor.setRange(jun, jul);
        counter.assertCounterState(0, 0, 0, 3, 2);
        matcherEditor.setRange(apr, sep);
        counter.assertCounterState(0, 0, 0, 3, 3);
        matcherEditor.setRange(may, aug);
        counter.assertCounterState(0, 0, 0, 4, 3);
        matcherEditor.setRange(jun, sep);
        counter.assertCounterState(0, 0, 1, 4, 3);
        matcherEditor.setRange(may, aug);
        counter.assertCounterState(0, 0, 2, 4, 3);
        matcherEditor.setRange(may, aug);
        counter.assertCounterState(0, 0, 2, 4, 3);
    }
    
    public void testSetRangeWithNulls() {
        final RangeMatcherEditor matcherEditor = new RangeMatcherEditor();
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        matcherEditor.addMatcherEditorListener(counter);
        counter.assertCounterState(0, 0, 0, 0, 0);
        matcherEditor.setRange(may, jul);
        counter.assertCounterState(0, 0, 0, 1, 0);
        matcherEditor.setRange(may, null);
        counter.assertCounterState(0, 0, 0, 1, 1);
        matcherEditor.setRange(null, null);
        counter.assertCounterState(1, 0, 0, 1, 1);
        matcherEditor.setRange(null, null);
        counter.assertCounterState(1, 0, 0, 1, 1);
        matcherEditor.setRange(may, jul);
        counter.assertCounterState(1, 0, 0, 2, 1);
        matcherEditor.setRange(null, jul);
        counter.assertCounterState(1, 0, 0, 2, 2);
        matcherEditor.setRange(null, null);
        counter.assertCounterState(2, 0, 0, 2, 2);
        matcherEditor.setRange(may, jul);
        counter.assertCounterState(2, 0, 0, 3, 2);
        matcherEditor.setRange(null, null);
        counter.assertCounterState(3, 0, 0, 3, 2);
        matcherEditor.setRange(may, null);
        counter.assertCounterState(3, 0, 0, 4, 2);
        matcherEditor.setRange(null, null);
        counter.assertCounterState(4, 0, 0, 4, 2);
        matcherEditor.setRange(null, jul);
        counter.assertCounterState(4, 0, 0, 5, 2);
    }
}
