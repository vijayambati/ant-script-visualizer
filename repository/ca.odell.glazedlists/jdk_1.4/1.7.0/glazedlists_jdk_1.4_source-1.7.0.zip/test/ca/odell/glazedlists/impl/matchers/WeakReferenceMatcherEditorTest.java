package ca.odell.glazedlists.impl.matchers;

import junit.framework.TestCase;
import ca.odell.glazedlists.matchers.MatcherEditor;
import ca.odell.glazedlists.matchers.Matchers;
import ca.odell.glazedlists.matchers.TextMatcherEditor;
import ca.odell.glazedlists.matchers.CountingMatcherEditorListener;
import java.lang.ref.WeakReference;

public class WeakReferenceMatcherEditorTest extends TestCase {
    
    public WeakReferenceMatcherEditorTest() {
        super();
    }
    
    public void testAddRemoveListener() {
        final TextMatcherEditor textMatcherEditor = new TextMatcherEditor();
        MatcherEditor weakMatcherEditor = Matchers.weakReferenceProxy(textMatcherEditor);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        weakMatcherEditor.addMatcherEditorListener(counter);
        counter.assertCounterState(0, 0, 0, 0, 0);
        textMatcherEditor.setFilterText(new String[]{"booblah"});
        counter.assertCounterState(0, 0, 0, 1, 0);
        weakMatcherEditor.removeMatcherEditorListener(counter);
        textMatcherEditor.setFilterText(new String[]{"bibbety"});
        counter.assertCounterState(0, 0, 0, 1, 0);
    }
    
    public void testGarbageCollectWeakListener() {
        final TextMatcherEditor textMatcherEditor = new TextMatcherEditor();
        MatcherEditor weakMatcherEditor = Matchers.weakReferenceProxy(textMatcherEditor);
        CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        final WeakReference weakRef = new WeakReference(counter);
        weakMatcherEditor.addMatcherEditorListener(counter);
        counter.assertCounterState(0, 0, 0, 0, 0);
        textMatcherEditor.setFilterText(new String[]{"booblah"});
        counter.assertCounterState(0, 0, 0, 1, 0);
        counter = null;
        System.gc();
        textMatcherEditor.setFilterText(new String[]{"bibbety"});
        assertNull(weakRef.get());
    }
    
    public void testGarbageCollectWeakReferenceProxy() {
        final TextMatcherEditor textMatcherEditor = new TextMatcherEditor();
        MatcherEditor weakMatcherEditor = Matchers.weakReferenceProxy(textMatcherEditor);
        final CountingMatcherEditorListener counter = new CountingMatcherEditorListener();
        weakMatcherEditor.addMatcherEditorListener(counter);
        counter.assertCounterState(0, 0, 0, 0, 0);
        textMatcherEditor.setFilterText(new String[]{"booblah"});
        counter.assertCounterState(0, 0, 0, 1, 0);
        weakMatcherEditor = null;
        System.gc();
        textMatcherEditor.setFilterText(new String[]{"bibbety"});
        counter.assertCounterState(0, 0, 0, 1, 0);
    }
}
