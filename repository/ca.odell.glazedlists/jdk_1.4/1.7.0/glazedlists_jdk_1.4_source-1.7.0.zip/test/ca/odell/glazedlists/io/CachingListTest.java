package ca.odell.glazedlists.io;

import junit.framework.TestCase;
import ca.odell.glazedlists.BasicEventList;
import java.util.Random;

/**
 * This test verifies that the {@link ca.odell.glazedlists.io.CachingList} behaves as expected.
 *
 * @author <a href="mailto:kevin@swank.ca">Kevin Maltby</a>
 */
public class CachingListTest extends TestCase {
    
    public CachingListTest() {
        super();
    }
    private CachingList cache = null;
    private BasicEventList source = null;
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        source = new BasicEventList();
        cache = new CachingList(source, 15);
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        cache.dispose();
        cache = null;
        source.clear();
        source = null;
    }
    
    /**
     * Validate that the cache correctly retrieves values from the source
     * and that there are zero cache hits.
     */
    public void testNonRepetitiveLookups() {
        for (int i = 0; i < 25; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 25; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        assertEquals(0, cache.getCacheHits());
        assertEquals(25, cache.getCacheMisses());
    }
    
    /**
     * Validate that the cache correctly retrieves values from the source
     * when fetched repeatedly.  There should be one cache miss, and
     * 24 cached hits.
     */
    public void testRepetitiveLookup() {
        for (int i = 0; i < 3; i++) {
            source.add(new Integer(i));
        }
        Integer ONE = new Integer(1);
        for (int i = 0; i < 25; i++) {
            Object result = cache.get(1);
            assertEquals(ONE, (Integer)(Integer)result);
        }
        assertEquals(24, cache.getCacheHits());
        assertEquals(1, cache.getCacheMisses());
    }
    
    /**
     * Validate that the cache behaves correctly when it has reached the defined
     * maximum size and Objects which are uncached are requested.  This tests
     * cache overflow behaviour without repetitive lookups that can change which
     * cache entry is considered the 'oldest' as that test is covered by
     * {@link #testCacheEntryAccessReorderingForOverflow()}.
     */
    public void testCacheOverflowBehaviour() {
        for (int i = 0; i < 25; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 15; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        int cacheHitBaseline = cache.getCacheHits();
        int cacheMissBaseline = cache.getCacheMisses();
        Object result = cache.get(20);
        assertEquals(new Integer(20), (Integer)(Integer)result);
        assertEquals(cacheHitBaseline, cache.getCacheHits());
        assertEquals(cacheMissBaseline + 1, cache.getCacheMisses());
        result = cache.get(0);
        assertEquals(new Integer(0), (Integer)(Integer)result);
        assertEquals(cacheHitBaseline, cache.getCacheHits());
        assertEquals(cacheMissBaseline + 2, cache.getCacheMisses());
    }
    
    /**
     * Validate that the cache reorders the cached entries correctly
     * based on last access so that the oldest entry is removed when
     * the cache overflows.
     */
    public void testCacheEntryAccessReorderingForOverflow() {
        for (int i = 0; i < 25; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 15; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        Random random = new Random(11);
        for (int i = 0; i < 100; i++) {
            cache.get(random.nextInt(15));
        }
        int cacheHitBaseline = cache.getCacheHits();
        int cacheMissBaseline = cache.getCacheMisses();
        for (int i = 14; i >= 0; i--) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        assertEquals(cacheHitBaseline += 15, cache.getCacheHits());
        assertEquals(cacheMissBaseline, cache.getCacheMisses());
        Object result = cache.get(20);
        assertEquals(new Integer(20), (Integer)(Integer)result);
        assertEquals(cacheHitBaseline, cache.getCacheHits());
        assertEquals(cacheMissBaseline + 1, cache.getCacheMisses());
        for (int i = 14; i >= 0; i--) {
            result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
            assertEquals(cacheHitBaseline, cache.getCacheHits());
            assertEquals(cacheMissBaseline + 1 + (15 - i), cache.getCacheMisses());
        }
    }
    
    /**
     * Validates that when a remove is called on an index
     * that is cached, the value is successfully removed
     * from the cache.
     */
    public void testRemovingCachedValueWithCachedFollower() {
        for (int i = 0; i < 10; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 5; i++) {
            cache.get(i);
        }
        cache.remove(2);
        assertEquals(0, cache.getCacheHits());
        assertEquals(5, cache.getCacheMisses());
        Object result = cache.get(2);
        assertEquals(3, ((Integer)(Integer)result).intValue());
        assertEquals(1, cache.getCacheHits());
        assertEquals(5, cache.getCacheMisses());
    }
    
    /**
     * Validates that when a remove is called on an index
     * that is cached, the value is successfully removed
     * from the cache.
     */
    public void testRemovingCachedValueAtCacheEdge() {
        for (int i = 0; i < 10; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 5; i++) {
            cache.get(i);
        }
        cache.remove(4);
        assertEquals(0, cache.getCacheHits());
        assertEquals(5, cache.getCacheMisses());
        Object result = cache.get(4);
        assertEquals(5, ((Integer)(Integer)result).intValue());
        assertEquals(0, cache.getCacheHits());
        assertEquals(6, cache.getCacheMisses());
    }
    
    /**
     * Validates that when a remove is called on an index
     * that has been cached, that the internal cache size
     * decreases.
     */
    public void testRemoveCorrectsCacheSize() {
        for (int i = 0; i < 25; i++) {
            source.add(new Integer(i));
        }
        for (int i = 0; i < 15; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        for (int i = 10; i > 0; i--) {
            cache.remove(i);
        }
        for (int i = 6; i < 15; i++) {
            cache.get(i);
        }
        int cacheHitBaseline = cache.getCacheHits();
        int cacheMissBaseline = cache.getCacheMisses();
        Object result = cache.get(0);
        assertEquals(0, ((Integer)(Integer)result).intValue());
        assertEquals(cacheHitBaseline + 1, cache.getCacheHits());
        assertEquals(cacheMissBaseline, cache.getCacheMisses());
    }
    
    /**
     * Validate the proper response to requested an index beyond
     * <code>source.size() - 1</code>.  This test is included as
     * a result of CachingList overriding get() from TransformedList.
     */
    public void testBoundsErrorBehaviour() {
        boolean exceptionThrown = false;
        try {
            cache.get(26);
        } catch (IndexOutOfBoundsException e) {
            exceptionThrown = true;
        }
        if (exceptionThrown == false) {
            fail("No exception was thrown when an invalid index was requested on an empty source.");
        }
        for (int i = 0; i < 25; i++) {
            source.add(new Integer(i));
        }
        exceptionThrown = false;
        try {
            cache.get(26);
        } catch (IndexOutOfBoundsException e) {
            exceptionThrown = true;
        }
        if (exceptionThrown == false) {
            fail("No exception was thrown when an invalid index was requested on an empty cache.");
        }
        for (int i = 9; i < 15; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        exceptionThrown = false;
        try {
            cache.get(26);
        } catch (IndexOutOfBoundsException e) {
            exceptionThrown = true;
        }
        if (exceptionThrown == false) {
            fail("No exception was thrown when an invalid index was requested on a partially full cache.");
        }
        for (int i = 9; i < 15; i++) {
            Object result = cache.get(i);
            assertEquals(new Integer(i), (Integer)(Integer)result);
        }
        exceptionThrown = false;
        try {
            cache.get(26);
        } catch (IndexOutOfBoundsException e) {
            exceptionThrown = true;
        }
        if (!exceptionThrown) {
            fail("No exception was thrown when an invalid index was requested on a full cache.");
        }
    }
    
    /**
     * This main provides performance testing capabilities for CachingList.
     *
     * <p>It was originally the main method of CachingList itself, and it's since
     * been moved here. It should be linked into the proper test system.
     */
    public static void main(String[] args) {
        int argsLength = args.length;
        int listSize = -1;
        int cacheSize = -1;
        int waitDuration = -1;
        CacheTestHelper testHelper = null;
        if (argsLength == 2) {
            try {
                listSize = Integer.parseInt(args[0]);
                waitDuration = Integer.parseInt(args[1]);
                testHelper = new CacheTestHelper(listSize, waitDuration);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("CachingList expects integer arguments.");
            }
        } else if (argsLength == 3) {
            try {
                listSize = Integer.parseInt(args[0]);
                cacheSize = Integer.parseInt(args[1]);
                waitDuration = Integer.parseInt(args[2]);
                testHelper = new CacheTestHelper(listSize, cacheSize, waitDuration);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("CachingList expects integer arguments.");
            }
        } else {
            System.out.println("\'CachingList\' Usage:");
            System.out.println("CachingList <sourceListSize> <waitDuration>");
            System.out.println("OR");
            System.out.println("CachingList <sourceListSize> <cacheSize> <waitDuration>");
            System.exit(1);
        }
        testHelper.runTests();
    }
}
