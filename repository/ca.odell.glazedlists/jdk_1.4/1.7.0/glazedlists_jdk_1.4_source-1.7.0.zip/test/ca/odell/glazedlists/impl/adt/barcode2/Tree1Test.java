package ca.odell.glazedlists.impl.adt.barcode2;

import junit.framework.TestCase;
import java.util.*;
import ca.odell.glazedlists.GlazedListsTests;
import ca.odell.glazedlists.GlazedLists;

/**
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class Tree1Test extends TestCase {
    
    public Tree1Test() {
        super();
    }
    
    /**
     * test values 
     */
    private static List colors = GlazedListsTests.stringToList("A");
    private static byte allColors = 1;
    
    /**
     * for randomly choosing list indices 
     */
    private Random random = new Random();
    
    /**
     * Make sure we can have a few unsorted elements in an otherwise ordered tree.
     */
    public void testUnsortedElementInSortedTree() {
        SimpleTree tree = new SimpleTree();
        Element e = tree.addInSortedOrder(Tree1Test.allColors, "E", 1);
        Element g = tree.addInSortedOrder(Tree1Test.allColors, "G", 1);
        Element i = tree.addInSortedOrder(Tree1Test.allColors, "I", 1);
        Element k = tree.addInSortedOrder(Tree1Test.allColors, "K", 1);
        Element m = tree.addInSortedOrder(Tree1Test.allColors, "M", 1);
        Element o = tree.addInSortedOrder(Tree1Test.allColors, "O", 1);
        k.setSorted(Element.UNSORTED);
        k.set("A");
        Element h = tree.addInSortedOrder(Tree1Test.allColors, "H", 1);
        Element n = tree.addInSortedOrder(Tree1Test.allColors, "N", 1);
        List asList = new SimpleTreeAsList(tree);
        assertEquals(GlazedListsTests.stringToList("EGHIAMNO"), asList);
    }
    
    /**
     * Tests to verify that the SimpleTree is consistent after a long
     * series of list operations.
     */
    public void testListOperations() {
        SimpleTree indexedTree = new SimpleTree();
        List controlList = new ArrayList();
        for (int i = 0; i < 30; i++) {
            int operation = random.nextInt(4);
            int index = controlList.isEmpty() ? 0 : random.nextInt(controlList.size());
            Object value = new Integer(random.nextInt(10));
            if (operation <= 1 || controlList.isEmpty()) {
                indexedTree.add(index, value, 1);
                controlList.add(index, value);
            } else if (operation == 2) {
                indexedTree.remove(index, 1);
                controlList.remove(index);
            }
        }
        List indexedTreeList = new ArrayList();
        for (SimpleTreeIterator i = new SimpleTreeIterator(indexedTree); i.hasNext(); ) {
            i.next();
            Element node = i.node();
            indexedTreeList.add(node.get());
        }
        assertEquals(controlList, indexedTreeList);
    }
    
    /**
     * Tests to verify that the SimpleTree is consistent with multiple
     * entries that have the same value.
     */
    public void testEqualValues() {
        SimpleTree indexedTree = new SimpleTree(GlazedLists.comparableComparator());
        int ACount = 0;
        int BCount = 0;
        int CCount = 0;
        int DCount = 0;
        int ECount = 0;
        while (BCount < 100 || DCount < 100) {
            indexedTree.addInSortedOrder((byte)1, "B", 1);
            BCount++;
            indexedTree.addInSortedOrder((byte)1, "D", 1);
            DCount++;
        }
        while (ACount < 100 || CCount < 100 || ECount < 100) {
            int letter = random.nextInt(3);
            if (letter == 0 && ACount < 100) {
                indexedTree.addInSortedOrder((byte)1, "A", 1);
                ACount++;
            } else if (letter == 1 && CCount < 100) {
                indexedTree.addInSortedOrder((byte)1, "C", 1);
                CCount++;
            } else if (letter == 2 && ECount < 100) {
                indexedTree.addInSortedOrder((byte)1, "E", 1);
                ECount++;
            }
        }
        while (ACount > 0 || CCount > 0 || ECount > 0) {
            int letter = random.nextInt(3);
            if (letter == 0 && ACount > 0) {
                int index = indexedTree.indexOfValue("A", true, false, (byte)1);
                indexedTree.remove(index, 1);
                ACount--;
            } else if (letter == 1 && CCount > 0) {
                int index = indexedTree.indexOfValue("C", true, false, (byte)1);
                indexedTree.remove(index, 1);
                CCount--;
            } else if (letter == 2 && ECount > 0) {
                int index = indexedTree.indexOfValue("E", true, false, (byte)1);
                indexedTree.remove(index, 1);
                ECount--;
            }
        }
        for (SimpleTreeIterator i = new SimpleTreeIterator(indexedTree); i.hasNext(); ) {
            i.next();
            Element node = i.node();
            if (node.get().equals("B")) BCount--; else if (node.get().equals("D")) DCount--; else fail();
        }
        assertEquals(BCount, 0);
        assertEquals(DCount, 0);
    }
    
    public void testIterators() {
        SimpleTree tree = new SimpleTree();
        tree.add(0, "A", 1);
        tree.add(1, "B", 1);
        tree.add(2, "C", 1);
        SimpleTreeIterator iterator = new SimpleTreeIterator(tree, 0, (byte)1);
        assertEquals(true, iterator.hasNext());
        iterator.next();
        assertEquals(0, iterator.index());
        assertEquals("A", (String)iterator.value());
        assertEquals(true, iterator.hasNext());
        iterator.next();
        assertEquals(1, iterator.index());
        assertEquals("B", (String)iterator.value());
        assertEquals(true, iterator.hasNext());
        iterator.next();
        assertEquals(2, iterator.index());
        assertEquals("C", (String)iterator.value());
        assertEquals(false, iterator.hasNext());
    }
    
    public void testIndexOfEtc() {
        SimpleTree tree = new SimpleTree(GlazedLists.comparableComparator());
        tree.addInSortedOrder((byte)1, "B", 1);
        tree.addInSortedOrder((byte)1, "B", 1);
        tree.addInSortedOrder((byte)1, "B", 1);
        tree.addInSortedOrder((byte)1, "D", 1);
        tree.addInSortedOrder((byte)1, "D", 1);
        tree.addInSortedOrder((byte)1, "E", 1);
        assertEquals(0, tree.indexOfValue("B", true, false, (byte)1));
        assertEquals(2, tree.indexOfValue("B", false, false, (byte)1));
        assertEquals(0, tree.indexOfValue("B", true, true, (byte)1));
        assertEquals(3, tree.indexOfValue("D", true, false, (byte)1));
        assertEquals(4, tree.indexOfValue("D", false, false, (byte)1));
        assertEquals(3, tree.indexOfValue("D", true, true, (byte)1));
        assertEquals(5, tree.indexOfValue("E", true, false, (byte)1));
        assertEquals(5, tree.indexOfValue("E", false, false, (byte)1));
        assertEquals(5, tree.indexOfValue("E", true, true, (byte)1));
        assertEquals(-1, tree.indexOfValue("A", true, false, (byte)1));
        assertEquals(-1, tree.indexOfValue("A", false, false, (byte)1));
        assertEquals(0, tree.indexOfValue("A", true, true, (byte)1));
        assertEquals(-1, tree.indexOfValue("C", true, false, (byte)1));
        assertEquals(-1, tree.indexOfValue("C", false, false, (byte)1));
        assertEquals(3, tree.indexOfValue("C", true, true, (byte)1));
        assertEquals(-1, tree.indexOfValue("F", true, false, (byte)1));
        assertEquals(-1, tree.indexOfValue("F", false, false, (byte)1));
        assertEquals(6, tree.indexOfValue("F", true, true, (byte)1));
    }
}
