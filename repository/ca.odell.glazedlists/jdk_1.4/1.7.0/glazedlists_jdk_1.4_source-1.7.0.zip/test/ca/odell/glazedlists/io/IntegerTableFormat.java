package ca.odell.glazedlists.io;

import ca.odell.glazedlists.gui.*;

/**
 * The IntegerTableFormat specifies how an integer is displayed in a table.
 * 
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class IntegerTableFormat implements TableFormat {
    
    public IntegerTableFormat() {
        super();
    }
    
    public int getColumnCount() {
        return 1;
    }
    
    public String getColumnName(int column) {
        return "Value";
    }
    
    public Object getColumnValue(Object x0, int x1) {
        Integer baseObject = (Integer)x0;
        int column = (int)x1;
        return baseObject;
    }
    /*missing*/
}
