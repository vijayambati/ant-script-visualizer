package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.*;
import ca.odell.glazedlists.matchers.Matchers;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.util.Arrays;
import java.util.Collections;

/**
 * This test verifies that the EventSelectionModel works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class EventSelectionModelSwingTest extends SwingTestCase {
    
    public EventSelectionModelSwingTest() {
        super();
    }
    
    /**
     * Tests the user interface. This is a mandatory method in SwingTestCase classes.
     */
    public void testGui() {
        super.testGui();
    }
    
    /**
     * Tests that selection survives a sorting.
     */
    public void guiTestSort() {
        BasicEventList list = new BasicEventList();
        SortedList sorted = new SortedList(list, null);
        EventSelectionModel eventSelectionModel = new EventSelectionModel(sorted);
        list.add("E");
        list.add("C");
        list.add("F");
        list.add("B");
        list.add("A");
        list.add("D");
        assertEquals(Arrays.asList(new String[]{}), eventSelectionModel.getSelected());
        eventSelectionModel.addSelectionInterval(0, 0);
        eventSelectionModel.addSelectionInterval(4, 4);
        assertEquals(Arrays.asList(new String[]{"E", "A"}), eventSelectionModel.getSelected());
        sorted.setComparator(GlazedLists.comparableComparator());
        assertEquals(Arrays.asList(new String[]{"A", "E"}), eventSelectionModel.getSelected());
        sorted.setComparator(GlazedLists.reverseComparator());
        assertEquals(Arrays.asList(new String[]{"E", "A"}), eventSelectionModel.getSelected());
    }
    
    /**
     * Verifies that the selected index is cleared when the selection is cleared.
     */
    public void guiTestClear() {
        BasicEventList list = new BasicEventList();
        EventSelectionModel eventSelectionModel = new EventSelectionModel(list);
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("F");
        eventSelectionModel.addSelectionInterval(1, 4);
        assertEquals(list.subList(1, 5), eventSelectionModel.getSelected());
        eventSelectionModel.clearSelection();
        assertEquals(Collections.EMPTY_LIST, eventSelectionModel.getSelected());
        assertEquals(-1, eventSelectionModel.getMinSelectionIndex());
        assertEquals(-1, eventSelectionModel.getMaxSelectionIndex());
        assertEquals(true, eventSelectionModel.isSelectionEmpty());
    }
    
    /**
     * Tests a problem where the {@link ca.odell.glazedlists.swing.EventSelectionModel} fails to fire events
     *
     * This test was contributed by: Sergey Bogatyrjov
     */
    public void guiTestSelectionModel() {
        EventList source = new BasicEventList();
        source.addAll(Arrays.asList(new String[]{"one", "two", "three"}));
        FilterList filtered = new FilterList(source, Matchers.trueMatcher());
        EventSelectionModel model = new EventSelectionModel(filtered);
        EventSelectionModelSwingTest.ListSelectionChangeCounter counter = new EventSelectionModelSwingTest.ListSelectionChangeCounter();
        model.addListSelectionListener(counter);
        model.setSelectionInterval(1, 1);
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.falseMatcher());
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.trueMatcher());
        assertEquals(0, counter.getCountAndReset());
        model.setSelectionInterval(0, 0);
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.falseMatcher());
        assertEquals(1, counter.getCountAndReset());
    }
    
    public void guiTestConstructorLocking() throws InterruptedException {
        final ThreadRecorderEventList atomicList = new ThreadRecorderEventList(new BasicEventList());
        final Thread writerThread = new Thread(GlazedListsTests.createJerkyAddRunnable(atomicList, null, 2000, 50), "WriterThread");
        writerThread.start();
        Thread.sleep(200);
        final EventList delayList = GlazedListsTests.delayList(atomicList, 50);
        new EventSelectionModel(delayList);
        writerThread.join();
        assertEquals(3, atomicList.getReadWriteBlockCount());
    }
    
    /**
     * Counts the number of ListSelectionEvents fired.
     */
    private class ListSelectionChangeCounter implements ListSelectionListener {
        
        private ListSelectionChangeCounter() {
            super();
        }
        private int count = 0;
        
        public void valueChanged(ListSelectionEvent e) {
            count++;
        }
        
        public int getCountAndReset() {
            int result = count;
            count = 0;
            return result;
        }
    }
}
