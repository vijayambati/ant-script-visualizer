package ca.odell.glazedlists.impl.io;

import ca.odell.glazedlists.io.*;
import java.io.*;

/**
 * Encodes integers and decodes them.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class IntegerCoder implements ByteCoder {
    
    public IntegerCoder() {
        super();
    }
    
    public void encode(Object source, OutputStream target) throws IOException {
        DataOutputStream dataOut = new DataOutputStream(target);
        Integer sourceInt = (Integer)(Integer)source;
        dataOut.writeInt(sourceInt.intValue());
        dataOut.flush();
    }
    
    public Object decode(InputStream source) throws IOException {
        DataInputStream dataIn = new DataInputStream(source);
        int value = dataIn.readInt();
        return new Integer(value);
    }
}
