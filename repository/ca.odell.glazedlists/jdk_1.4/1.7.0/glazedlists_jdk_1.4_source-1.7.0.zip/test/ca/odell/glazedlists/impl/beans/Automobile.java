package ca.odell.glazedlists.impl.beans;

import junit.framework.*;
import java.awt.Color;

/**
 * A test object.
 */
class Automobile {
    private boolean automatic;
    private Color color;
    private boolean fullOfGas;
    
    public Automobile(boolean automatic) {
        super();
        this.automatic = automatic;
        color = Color.BLACK;
        fullOfGas = true;
    }
    
    public Color getColor() {
        return color;
    }
    
    public boolean getDrivable() {
        return fullOfGas;
    }
    
    public void setColor(Color color) {
        this.color = color;
    }
    
    public boolean isAutomatic() {
        return automatic;
    }
    
    public void setFullOfGas(boolean fullOfGas) {
        this.fullOfGas = fullOfGas;
    }
}
