package ca.odell.glazedlists;

import junit.framework.*;
import ca.odell.glazedlists.event.*;
import java.util.*;

/**
 * A PopularityListTest tests the functionality of the PopularityList.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class PopularityListTest extends TestCase {
    
    public PopularityListTest() {
        super();
    }
    
    /**
     * Test that the Popularity List works with simple data.
     */
    public void testSimpleData() {
        EventList source = new BasicEventList();
        PopularityList popularityList = new PopularityList(source);
        source.add("Mike");
        source.add("Kevin");
        source.add("Graham");
        source.add("Mike");
        source.add("Melissa");
        source.add("Melissa");
        source.add("Jonathan");
        source.add("Jodie");
        source.add("Andrew");
        source.add("Melissa");
        assertEquals("Melissa", popularityList.get(0));
        assertEquals("Mike", popularityList.get(1));
        source.add("Jonathan");
        source.add("Jonathan");
        source.remove("Mike");
        source.remove("Melissa");
        assertEquals("Jonathan", popularityList.get(0));
        assertEquals("Melissa", popularityList.get(1));
        source.add("Mike");
        source.add("Mike");
        source.add("Mike");
        assertEquals("Mike", popularityList.get(0));
        assertEquals("Jonathan", popularityList.get(1));
        assertEquals("Melissa", popularityList.get(2));
        source.clear();
    }
    
    /**
     * Tests that the Popularity List works by using a random sequence of operations.
     */
    public void testRandom() {
        Random dice = new Random(0);
        EventList source = new BasicEventList();
        SortedList sortedSource = new SortedList(source);
        PopularityList popularityList = new PopularityList(source);
        new PopularityListValidator(popularityList, sortedSource);
        for (int i = 0; i < 1000; i++) {
            source.add(new Integer(dice.nextInt(50)));
        }
        for (int i = 0; i < 900; i++) {
            int remIndex = dice.nextInt(source.size());
            source.remove(remIndex);
        }
        for (int i = 0; i < 800; i++) {
            int updateIndex = dice.nextInt(source.size());
            Integer updateValue = new Integer(dice.nextInt(50));
            source.set(updateIndex, updateValue);
        }
    }
    
    /**
     * Tests that the PopularityList can handle multiple simultaneous events.
     */
    public void testMultipleEvents() {
        EventList source = new BasicEventList();
        source.add(new int[]{86, 1, 1, 1, 1, 0, 0});
        source.add(new int[]{86, 1, 0, 1, 1, 1, 0});
        source.add(new int[]{86, 1, 0, 0, 0, 0, 0});
        source.add(new int[]{75, 1, 1, 1, 1, 0, 1});
        source.add(new int[]{75, 1, 0, 0, 0, 0, 1});
        source.add(new int[]{75, 1, 0, 0, 0, 0, 1});
        source.add(new int[]{30, 1, 1, 1, 1, 0, 1});
        source.add(new int[]{98, 1, 1, 1, 1, 0, 1});
        source.add(new int[]{98, 1, 0, 0, 1, 1, 1});
        IntegerArrayMatcherEditor matcherEditor = new IntegerArrayMatcherEditor(0, 0);
        FilterList filterList = new FilterList(source, matcherEditor);
        SortedList sortedList = new SortedList(source, GlazedListsTests.intArrayComparator(0));
        PopularityList popularityList = new PopularityList(filterList, GlazedListsTests.intArrayComparator(0));
        new PopularityListValidator(popularityList, sortedList);
        matcherEditor.setFilter(1, 1);
        matcherEditor.setFilter(2, 1);
        matcherEditor.setFilter(3, 1);
        matcherEditor.setFilter(4, 1);
        matcherEditor.setFilter(5, 1);
        matcherEditor.setFilter(6, 1);
    }
    
    /**
     * Tests that the PopularityList can handle edge case sets.
     */
    public void testEdgeSets() {
        EventList source = new BasicEventList();
        source.add("Audi");
        source.add("Audi");
        source.add("Audi");
        source.add("BMW");
        source.add("Chevy");
        source.add("Chevy");
        source.add("Chevy");
        source.add("Datsun");
        SortedList sortedList = new SortedList(source);
        PopularityList popularityList = new PopularityList(source);
        new PopularityListValidator(popularityList, sortedList);
        source.set(2, "BMW");
        source.set(1, "BMW");
        source.set(0, "BMW");
        source.set(6, "Datsun");
        source.set(5, "Datsun");
        source.set(4, "Datsun");
        source.set(3, "Datsun");
        source.set(2, "Datsun");
        source.set(1, "Datsun");
        source.set(0, "Datsun");
        source.set(7, "Ford");
        source.set(6, "Ford");
        source.set(0, "Audi");
        source.set(1, "BMW");
        source.set(2, "BMW");
        source.set(3, "BMW");
        source.set(4, "BMW");
        source.set(5, "Chevy");
        source.set(4, "Chevy");
        source.set(6, "Chevy");
        source.set(7, "Chevy");
    }
    
    /**
     * Tests that the PopularityList can handle edge case sets.
     */
    public void testLeftEdgeSet() {
        EventList source = new BasicEventList();
        SortedList sortedList = new SortedList(source);
        PopularityList popularityList = new PopularityList(source);
        new PopularityListValidator(popularityList, sortedList);
        source.add(0, "Audi");
        source.add(1, "Audi");
        source.add(2, "BMW");
        source.add(3, "BMW");
        source.set(1, "BMW");
    }
    
    /**
     * Tests that the PopularityList elements that have the same count are in sorted
     * order.
     */
    public void testEqualPopularityOrdering() {
        EventList source = new BasicEventList();
        PopularityList popularityList = new PopularityList(source);
        source.add(0, "chaos");
        source.add(1, "fiery");
        source.add(2, "gecko");
        source.add(0, "banjo");
        source.add(2, "dingo");
        source.add(5, "hippo");
        source.add(0, "album");
        source.add(4, "eerie");
        List sortedSingleCopy = new ArrayList();
        sortedSingleCopy.addAll(source);
        Collections.sort(sortedSingleCopy);
        assertEquals(sortedSingleCopy, popularityList);
        source.add(0, "chaos");
        source.add(1, "fiery");
        source.add(2, "gecko");
        source.add(0, "banjo");
        source.add(2, "dingo");
        source.add(5, "hippo");
        source.add(0, "album");
        source.add(4, "eerie");
        assertEquals(sortedSingleCopy, popularityList);
        source.add("chaos");
        source.add("fiery");
        source.add("gecko");
        source.add("banjo");
        source.add("dingo");
        source.add("hippo");
        source.add("album");
        source.add("eerie");
        assertEquals(sortedSingleCopy, popularityList);
        source.set(0, "gecko");
        source.set(2, "hippo");
        source.set(4, "dingo");
        source.set(5, "banjo");
        List expectedTwoClasses = new ArrayList();
        expectedTwoClasses.add("banjo");
        expectedTwoClasses.add("dingo");
        expectedTwoClasses.add("gecko");
        expectedTwoClasses.add("hippo");
        expectedTwoClasses.add("album");
        expectedTwoClasses.add("chaos");
        expectedTwoClasses.add("eerie");
        expectedTwoClasses.add("fiery");
        assertEquals(expectedTwoClasses, popularityList);
    }
    
    /**
     * Validates that the state of the PopularityList is correct. Because this class
     * is a Listener, it can detect the exact change that causes the PopularityList
     * to come out of sync.
     */
    class PopularityListValidator implements ListEventListener {
        private List elementCounts = new ArrayList();
        private PopularityList popularityList;
        private SortedList sortedSource;
        
        /**
         * Creates a PopularityListValidator that validates that the specified
         * popularity list ranks the elements in the speceified sortedlist in 
         * order of popularity. A SortedList is used because it has much better
         * performance for {@link List#indexOf(Object)} and {@link List#lastIndexOf(Object)}
         * operations.
         */
        public PopularityListValidator(PopularityList popularityList, SortedList sortedSource) {
            super();
            this.popularityList = popularityList;
            this.sortedSource = sortedSource;
            for (int i = 0; i < popularityList.size(); i++) {
                elementCounts.add(new Integer(count(popularityList.get(i))));
            }
            popularityList.addListEventListener(this);
        }
        
        /**
         * Handle the source PopularityList changing by validating that list.
         */
        public void listChanged(ListEvent listEvent) {
            List changedIndices = new ArrayList();
            while (listEvent.next()) {
                int changeIndex = listEvent.getIndex();
                int changeType = listEvent.getType();
                changedIndices.add(new Integer(changeIndex));
                if (changeType == ListEvent.DELETE) {
                    elementCounts.remove(changeIndex);
                } else if (changeType == ListEvent.INSERT) {
                    elementCounts.add(changeIndex, new Integer(count(popularityList.get(changeIndex))));
                } else if (changeType == ListEvent.UPDATE) {
                    elementCounts.set(changeIndex, new Integer(count(popularityList.get(changeIndex))));
                }
            }
            assertEquals(popularityList.size(), elementCounts.size());
            for (Iterator c = changedIndices.iterator(); c.hasNext(); ) {
                int changeIndex = ((Integer)(Integer)c.next()).intValue();
                for (int i = Math.max(changeIndex - 1, 0); i < Math.min(changeIndex + 2, popularityList.size()); i++) {
                    assertEquals("Test index " + i + ", value: " + popularityList.get(i), elementCounts.get(i), new Integer(count(popularityList.get(i))));
                }
            }
        }
        
        /**
         * Get the number of copies of the specified value exist in the source list.
         */
        public int count(Object value) {
            int first = sortedSource.indexOf(value);
            if (first == -1) return 0;
            int last = sortedSource.lastIndexOf(value);
            return (last - first + 1);
        }
    }
}
