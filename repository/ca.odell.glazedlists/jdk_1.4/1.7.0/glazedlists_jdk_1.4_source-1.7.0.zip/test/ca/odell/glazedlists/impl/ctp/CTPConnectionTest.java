package ca.odell.glazedlists.impl.ctp;

import junit.framework.*;
import java.io.*;

/**
 * A CTPConnectionTest verifies that behaviour is correct when connections fail.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class CTPConnectionTest extends TestCase {
    
    public CTPConnectionTest() {
        super();
    }
    
    /**
     * Verifies that an Exception is thrown if there is a bind failure.
     */
    public void testRepeatedBind() {
        StaticCTPHandlerFactory handlerFactory = new StaticCTPHandlerFactory();
        int serverPort = 6000;
        CTPConnectionManager connectionManager = null;
        try {
            connectionManager = new CTPConnectionManager(handlerFactory, serverPort);
            connectionManager.start();
        } catch (IOException e) {
            fail(e.getMessage());
        }
        try {
            CTPConnectionManager connectionManager2 = new CTPConnectionManager(handlerFactory, serverPort);
            connectionManager2.start();
            fail();
        } catch (IOException e) {
        } finally {
            connectionManager.stop();
        }
    }
    
    /**
     * Verifies that a connect timeout causes the CTPHandler to be closed.
     */
    public void testConnectionRefused() throws IOException {
        StaticCTPHandlerFactory handlerFactory = new StaticCTPHandlerFactory();
        int serverPort = 6001;
        int connectPort = 6002;
        CTPConnectionManager connectionManager = new CTPConnectionManager(handlerFactory, serverPort);
        connectionManager.start();
        StaticCTPHandler refused = new StaticCTPHandler();
        connectionManager.connect(refused, "localhost", connectPort);
        refused.assertClosed((long)1000);
        connectionManager.stop();
    }
    
    /**
     * Verifies that a connect timeout causes the CTPHandler to be closed.
     */
    public void testConnectionTimeOut() throws IOException {
        System.err.println("Skipping timeout test which takes 77 seconds to run");
    }
}
