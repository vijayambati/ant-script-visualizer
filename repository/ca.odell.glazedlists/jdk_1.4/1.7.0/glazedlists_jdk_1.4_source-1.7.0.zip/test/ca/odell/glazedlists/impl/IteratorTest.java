package ca.odell.glazedlists.impl;

import junit.framework.*;
import ca.odell.glazedlists.*;
import java.util.*;

/**
 * This test verifies that the EventListIterator works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class IteratorTest extends TestCase {
    
    public IteratorTest() {
        super();
    }
    
    /**
     * for randomly choosing list indices 
     */
    private final Random random = new Random();
    
    /**
     * Tests to verify that the Iterator can iterate through the list both
     * forwards and backwards.
     */
    public void testIterateThrough() {
        final EventList originalList = new BasicEventList();
        for (int i = 0; i < 26; i++) originalList.add(new Integer(i));
        final List forwardsControlList = new ArrayList();
        for (Iterator i = originalList.iterator(); i.hasNext(); ) forwardsControlList.add(i.next());
        assertEquals(originalList, forwardsControlList);
        final List backwardsControlList = new ArrayList();
        for (ListIterator i = originalList.listIterator(originalList.size()); i.hasPrevious(); ) backwardsControlList.add(i.previous());
        Collections.reverse(backwardsControlList);
        assertEquals(originalList, backwardsControlList);
    }
    
    /**
     * Tests to verify that the ListIterator can iterate through the list
     * while removes are performed directly on the list.
     */
    public void testIterateWithExternalRemove() {
        final EventList deleteFromList = new BasicEventList();
        final List originalList = new ArrayList();
        for (int i = 0; i < 100; i++) {
            final Integer value = new Integer(i);
            deleteFromList.add(value);
            originalList.add(value);
        }
        final List iteratedElements = new ArrayList();
        final Iterator iterator = deleteFromList.listIterator();
        for (int a = 0; a < 50; a++) iteratedElements.add(iterator.next());
        for (int a = 50; a > 0; a--) deleteFromList.remove(random.nextInt(a));
        for (int a = 0; a < 50; a++) iteratedElements.add(iterator.next());
        assertEquals(originalList, iteratedElements);
        assertFalse(iterator.hasNext());
    }
    
    /**
     * Tests to verify that the EventListIterator and the SimpleTreeIterator can
     * iterate through the list and remove its elements as it goes without
     * incident.
     */
    public void testIterateWithInternalRemove() {
        final EventList iterateForwardList = new BasicEventList();
        final EventList iterateBackwardList = new BasicEventList();
        final List originalList = new ArrayList();
        for (int i = 0; i < 20; i++) {
            final Integer value = new Integer(random.nextInt(100));
            iterateForwardList.add(value);
            iterateBackwardList.add(value);
            originalList.add(value);
        }
        for (ListIterator i = iterateForwardList.listIterator(); i.hasNext(); ) if (((Integer)i.next()).intValue() > 50) i.remove();
        for (ListIterator i = iterateBackwardList.listIterator(iterateBackwardList.size()); i.hasPrevious(); ) if (((Integer)i.previous()).intValue() > 50) i.remove();
        for (int i = 0; i < originalList.size(); ) {
            if (((Integer)originalList.get(i)).intValue() > 50) originalList.remove(i); else i++;
        }
        assertEquals(originalList, iterateForwardList);
        assertEquals(originalList, iterateBackwardList);
    }
    
    /**
     * Tests the edge condition of the previous method.
     */
    public void testPreviousEdgeCondition() {
        final EventList iterationList = new BasicEventList();
        for (int i = 0; i < 20; i++) iterationList.add(new Integer(random.nextInt(100)));
        final ListIterator i = iterationList.listIterator();
        assertFalse(i.hasPrevious());
        try {
            i.previous();
            fail("A call to previous() was allowed before next() was called");
        } catch (NoSuchElementException e) {
        }
        i.next();
        assertTrue(i.hasPrevious());
    }
    
    /**
     * Tests that changing the underlying list externally to the ListIterator
     * doesn't break the expectation of the remove operation.
     */
    public void testRemoveAfterInsertAtCursor() {
        final EventList testList = new BasicEventList();
        String hello = "Hello, world.";
        String bye = "Goodbye, cruel world.";
        String end = "the end";
        testList.add(bye);
        testList.add(end);
        final ListIterator iterator = testList.listIterator();
        iterator.next();
        testList.add(0, hello);
        iterator.remove();
        assertFalse(testList.contains(bye));
    }
    
    /**
     * Tests that changing the underlying list externally to the ListIterator
     * doesn't break the expectation of the remove operation.
     */
    public void testRemoveAfterInsertAtNext() {
        final EventList testList = new BasicEventList();
        String hello = "Hello, world.";
        String bye = "Goodbye, cruel world.";
        String end = "the end";
        testList.add(bye);
        testList.add(end);
        final ListIterator iterator = testList.listIterator();
        iterator.next();
        testList.add(1, hello);
        iterator.remove();
        assertFalse(testList.contains(bye));
    }
    
    /**
     * Tests that changing the underlying list externally to the ListIterator
     * doesn't break the expectation of the remove operation.
     */
    public void testRemoveAfterInsertAtCursorReverse() {
        BasicEventList testList = new BasicEventList();
        String hello = "Hello, world.";
        String bye = "Goodbye, cruel world.";
        String end = "the end";
        testList.add(end);
        testList.add(bye);
        final ListIterator iterator = testList.listIterator(testList.size());
        iterator.previous();
        testList.add(1, hello);
        iterator.remove();
        assertFalse(testList.contains(bye));
    }
    
    /**
     * Tests that changing the underlying list externally to the ListIterator
     * doesn't break the expectation of the remove operation.
     */
    public void testRemoveAfterInsertAtPrevious() {
        BasicEventList testList = new BasicEventList();
        String hello = "Hello, world.";
        String bye = "Goodbye, cruel world.";
        String end = "the end";
        testList.add(end);
        testList.add(bye);
        final ListIterator iterator = testList.listIterator(testList.size());
        iterator.previous();
        testList.add(0, hello);
        iterator.remove();
        assertFalse(testList.contains(bye));
    }
    
    /**
     * Tests that adding at a particular element does the right thing.
     */
    public void testAdding() {
        final List controlList = new ArrayList();
        controlList.add("zero");
        controlList.add("one");
        controlList.add("two");
        controlList.add("three");
        controlList.add("four");
        final EventList forwardsList = new BasicEventList();
        forwardsList.add("one");
        forwardsList.add("three");
        final ListIterator iterator = forwardsList.listIterator(0);
        iterator.add("zero");
        assertEquals("one", (String)iterator.next());
        iterator.add("two");
        assertEquals("three", (String)iterator.next());
        iterator.add("four");
        assertEquals(controlList, forwardsList);
        final EventList backwardsList = new BasicEventList();
        backwardsList.add("one");
        backwardsList.add("three");
        final ListIterator backwardsIterator = backwardsList.listIterator(backwardsList.size());
        backwardsIterator.add("four");
        assertEquals("four", (String)backwardsIterator.previous());
        assertEquals("three", (String)backwardsIterator.previous());
        backwardsIterator.add("two");
        assertEquals("two", (String)backwardsIterator.previous());
        assertEquals("one", (String)backwardsIterator.previous());
        backwardsIterator.add("zero");
        assertEquals("zero", (String)backwardsIterator.previous());
        assertEquals(false, backwardsIterator.hasPrevious());
        assertEquals(controlList, backwardsList);
    }
    
    /**
     * Tests empty list adds
     */
    public void testEmptyListAdding() {
        final List testList = new BasicEventList();
        final ListIterator iterator = testList.listIterator();
        iterator.add("just one element");
        assertEquals(1, testList.size());
        assertFalse(iterator.hasNext());
        assertTrue(iterator.hasPrevious());
    }
    
    /**
     * Tests that the EventListIterator responds correctly to adding on an
     * empty list from an external call to remove().
     */
    public void testExternalAddingOnEmptyList() {
        final EventList testList = new BasicEventList();
        final ListIterator iterator = testList.listIterator();
        assertFalse(iterator.hasPrevious());
        assertFalse(iterator.hasNext());
        String hello = "hello, world";
        testList.add(hello);
        assertTrue(iterator.hasPrevious());
        assertFalse(iterator.hasNext());
        assertEquals(hello, (String)iterator.previous());
        assertFalse(iterator.hasPrevious());
        assertTrue(iterator.hasNext());
    }
    
    /**
     * This manually executed test runs forever creating iterators and
     * testing how memory responds.
     *
     * @see <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=316">Issue 316</a>
     */
    public static void main(String[] args) {
        final List list = new BasicEventList();
        list.addAll(GlazedListsTests.stringToList("ABCDEFGHIJK"));
        long memoryUsage = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024);
        int repetitions = 0;
        while (true) {
            for (Iterator regularIterator = list.iterator(); regularIterator.hasNext(); ) {
                regularIterator.next();
            }
            for (ListIterator listIterator = list.listIterator(); listIterator.hasNext(); ) {
                listIterator.next();
            }
            long newMemoryUsage = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024);
            if (newMemoryUsage > memoryUsage) {
                memoryUsage = newMemoryUsage;
                System.out.println(repetitions + ": " + memoryUsage + "k, HIGHER");
            } else if (repetitions % 10000 == 0) {
                System.out.println(repetitions + ": " + newMemoryUsage + "k");
            }
            repetitions++;
        }
    }
}
