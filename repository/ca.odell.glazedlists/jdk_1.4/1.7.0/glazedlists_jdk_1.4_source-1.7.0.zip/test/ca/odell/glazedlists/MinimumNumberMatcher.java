package ca.odell.glazedlists;

import ca.odell.glazedlists.matchers.*;
import java.util.*;

/**
 * A Matcher for minimum Number values.
 */
class MinimumNumberMatcher implements Matcher {
    private final int number;
    
    public MinimumNumberMatcher(int number) {
        super();
        this.number = number;
    }
    
    public boolean matches(Object x0) {
        Number item = (Number)x0;
        return item != null && item.intValue() >= number;
    }
    /*missing*/
}
