package ca.odell.glazedlists;

import junit.framework.*;
import java.util.*;

/**
 * This test verifies that the SortedList works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SortedListTest extends TestCase {
    
    public SortedListTest() {
        super();
    }
    
    /**
     * the source list 
     */
    private BasicEventList unsortedList = null;
    
    /**
     * the sorted list 
     */
    private SortedList sortedList = null;
    
    /**
     * for randomly choosing list indices 
     */
    private Random random = new Random(2);
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        unsortedList = new BasicEventList();
        sortedList = new SortedList(unsortedList);
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        unsortedList = null;
        sortedList = null;
    }
    
    /**
     * Tests that elements are properly moved when value changes require that
     * if sort order is not enforced on the list.
     */
    public void testSimpleMovesSortNotEnforced() {
        unsortedList = new BasicEventList();
        sortedList = new SortedList(unsortedList);
        sortedList.setMode(SortedList.AVOID_MOVING_ELEMENTS);
        ListConsistencyListener.install(sortedList);
        unsortedList.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), sortedList);
        unsortedList.set(3, "H");
        assertEquals(GlazedListsTests.stringToList("ABCHEFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCHEFG"), sortedList);
        unsortedList.addAll(3, GlazedListsTests.stringToList("IJKLMNO"));
        assertEquals(GlazedListsTests.stringToList("ABCIJKLMNOHEFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCHEFGIJKLMNO"), sortedList);
        unsortedList.removeAll(GlazedListsTests.stringToList("AEIO"));
        assertEquals(GlazedListsTests.stringToList("BCJKLMNHFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("BCHFGJKLMN"), sortedList);
        unsortedList.addAll(8, GlazedListsTests.stringToList("AEIO"));
        assertEquals(GlazedListsTests.stringToList("BCJKLMNHAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCEHFGIJKLMNO"), sortedList);
        unsortedList.set(0, "Z");
        assertEquals(GlazedListsTests.stringToList("ZCJKLMNHAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("AZCEHFGIJKLMNO"), sortedList);
        unsortedList.set(7, "F");
        assertEquals(GlazedListsTests.stringToList("ZCJKLMNFAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("AZCEFFGIJKLMNO"), sortedList);
        unsortedList.addAll(0, GlazedListsTests.stringToList("EEFF"));
        assertEquals(GlazedListsTests.stringToList("EEFFZCJKLMNFAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("AZCEEEFFFFGIJKLMNO"), sortedList);
        unsortedList.addAll(5, GlazedListsTests.stringToList("WXYZ"));
        assertEquals(GlazedListsTests.stringToList("EEFFZWXYZCJKLMNFAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("AZCEEEFFFFGIJKLMNOWXYZ"), sortedList);
        sortedList.set(1, "B");
        assertEquals(GlazedListsTests.stringToList("EEFFBWXYZCJKLMNFAEIOFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCEEEFFFFGIJKLMNOWXYZ"), sortedList);
        sortedList.clear();
        assertEquals(Collections.EMPTY_LIST, unsortedList);
        assertEquals(Collections.EMPTY_LIST, sortedList);
        sortedList.addAll(GlazedListsTests.stringToList("ABC"));
        assertEquals(GlazedListsTests.stringToList("ABC"), unsortedList);
        sortedList.set(0, "C");
        sortedList.set(2, "A");
        assertEquals(GlazedListsTests.stringToList("CBA"), sortedList);
        sortedList.add("A");
        assertEquals(GlazedListsTests.stringToList("ACBA"), sortedList);
        sortedList.add("C");
        assertEquals(GlazedListsTests.stringToList("ACBCA"), sortedList);
    }
    
    /**
     * Tests that elements are properly moved when value changes require that.
     */
    public void testSimpleMoves() {
        unsortedList = new BasicEventList();
        sortedList = new SortedList(unsortedList);
        ListConsistencyListener.install(sortedList);
        unsortedList.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), sortedList);
        unsortedList.set(3, "H");
        assertEquals(GlazedListsTests.stringToList("ABCHEFG"), unsortedList);
        assertEquals(GlazedListsTests.stringToList("ABCEFGH"), sortedList);
    }
    
    /**
     * Test that updates, inserts and deletes all in one even are handled succesfully.
     */
    public void testComplexEvents() {
        unsortedList = new BasicEventList();
        ExternalNestingEventList nestableList = new ExternalNestingEventList(unsortedList);
        sortedList = new SortedList(nestableList);
        ListConsistencyListener.install(sortedList);
        nestableList.beginEvent(true);
        nestableList.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        nestableList.commitEvent();
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), nestableList);
        assertEquals(GlazedListsTests.stringToList("ABCDEFG"), sortedList);
        nestableList.beginEvent(false);
        nestableList.set(3, "H");
        nestableList.add(0, "A");
        nestableList.commitEvent();
        assertEquals(GlazedListsTests.stringToList("AABCHEFG"), nestableList);
        assertEquals(GlazedListsTests.stringToList("AABCEFGH"), sortedList);
        nestableList.beginEvent(false);
        nestableList.add(0, "I");
        nestableList.add(1, "A");
        nestableList.set(5, "J");
        nestableList.set(9, "K");
        nestableList.commitEvent();
        assertEquals(GlazedListsTests.stringToList("IAAABJHEFK"), nestableList);
        assertEquals(GlazedListsTests.stringToList("AAABEFHIJK"), sortedList);
    }
    
    /**
     * Test that the indexOf() and lastIndexOf() methods work if the SortedList
     * is not actually sorted.
     *
     * @see <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=170">Bug 170</a>
     */
    public void testIndexOfUnsorted() {
        sortedList.setComparator(null);
        sortedList.add("Riders");
        sortedList.add("Stampeders");
        sortedList.add("Bombers");
        sortedList.add("Eskimos");
        sortedList.add("Argos");
        sortedList.add("Ti-Cats");
        sortedList.add("Riders");
        sortedList.add("Als");
        assertEquals(0, sortedList.indexOf("Riders"));
        assertEquals(6, sortedList.lastIndexOf("Riders"));
        assertEquals(8, sortedList.indexOfSimulated("Riders"));
    }
    
    /**
     * Test to verify that the sorted list is working correctly when it is
     * applied to a list that already has values.
     */
    public void testSortBeforeAndAfter() {
        for (int i = 0; i < 4000; i++) {
            unsortedList.add(new Integer(random.nextInt()));
        }
        final List controlList = new ArrayList();
        controlList.addAll(unsortedList);
        Collections.sort(controlList);
        assertEquals(controlList, sortedList);
        sortedList = new SortedList(unsortedList);
        assertEquals(controlList, sortedList);
    }
    
    /**
     * Test to verify that the SortedList is working correctly when the
     * list is changing by adds, removes and deletes.
     */
    public void testSortDynamic() {
        for (int i = 0; i < 4000; i++) {
            int operation = random.nextInt(4);
            int index = unsortedList.isEmpty() ? 0 : random.nextInt(unsortedList.size());
            if (operation <= 1 || unsortedList.isEmpty()) {
                unsortedList.add(index, new Integer(random.nextInt()));
            } else if (operation == 2) {
                unsortedList.remove(index);
            } else if (operation == 3) {
                unsortedList.set(index, new Integer(random.nextInt()));
            }
        }
        List controlList = new ArrayList();
        controlList.addAll(unsortedList);
        Collections.sort(controlList);
        assertEquals(controlList, sortedList);
    }
    
    /**
     * Tests to verify that the SortedList correctly handles modification.
     *
     * This performs a sequence of operations. Each operation is performed on
     * either the sorted list or the unsorted list. The list where the operation
     * is performed is selected at random.
     */
    public void testSortedListWritable() {
        for (int i = 0; i < 4000; i++) {
            List list;
            if (random.nextBoolean()) list = sortedList; else list = unsortedList;
            int operation = random.nextInt(4);
            int index = list.isEmpty() ? 0 : random.nextInt(list.size());
            if (operation <= 1 || list.isEmpty()) {
                list.add(index, new Integer(random.nextInt()));
            } else if (operation == 2) {
                list.remove(index);
            } else if (operation == 3) {
                list.set(index, new Integer(random.nextInt()));
            }
        }
        List controlList = new ArrayList();
        controlList.addAll(unsortedList);
        Collections.sort(controlList);
        assertEquals(controlList, sortedList);
    }
    
    /**
     * Tests that sorting works on a large set of filter changes.
     */
    public void testAgressiveFiltering() {
        BasicEventList source = new BasicEventList();
        IntegerArrayMatcherEditor matcherEditor = new IntegerArrayMatcherEditor(0, 0);
        FilterList filterList = new FilterList(source);
        SortedList sorted = new SortedList(filterList, GlazedListsTests.intArrayComparator(0));
        for (int i = 0; i < 1000; i++) {
            int value = random.nextInt(1000);
            int[] array = new int[]{value, random.nextInt(2), random.nextInt(2), random.nextInt(2)};
            source.add(array);
        }
        for (int i = 0; i < 10; i++) {
            int filterColumn = random.nextInt(3);
            matcherEditor.setFilter(filterColumn + 1, 1);
            List controlList = new ArrayList();
            controlList.addAll(filterList);
            Collections.sort(controlList, GlazedListsTests.intArrayComparator(0));
            assertEquals(sorted.size(), controlList.size());
            for (int j = 0; j < sorted.size(); j++) {
                assertEquals(((int[])(int[])sorted.get(j))[0], ((int[])(int[])controlList.get(j))[0]);
            }
        }
    }
    
    /**
     * Test indexOf() consistency
     */
    public void testIndexOf() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source);
        Integer ten = new Integer(10);
        int emptyTest = sorted.indexOf(ten);
        assertEquals(-1, emptyTest);
        Integer one = new Integer(1);
        for (int i = 0; i < 12; i++) {
            source.add(one);
        }
        Integer five = new Integer(5);
        for (int i = 0; i < 13; i++) {
            source.add(five);
        }
        Integer nine = new Integer(9);
        for (int i = 0; i < 10; i++) {
            source.add(nine);
        }
        int firstTestIndex = sorted.indexOf(one);
        assertEquals(0, firstTestIndex);
        int secondTestIndex = sorted.indexOf(five);
        assertEquals(12, secondTestIndex);
        int thirdTestIndex = sorted.indexOf(nine);
        assertEquals(25, thirdTestIndex);
        int fourthTest = sorted.indexOf(ten);
        assertEquals(-1, fourthTest);
    }
    
    /**
     * Test indexOf() consistency with a "weak" Comparator. A weak Comparator
     * is one that returns 0 to indicate two object compare as equal even when
     * .equals() would return false.
     */
    public void testIndexOfWithWeakComparator() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source, GlazedLists.comparableComparator());
        final Song enterSandman = new Song("Metallica", "Enter Sandman");
        final Song masterOfPuppets = new Song("Metallica", "Master of Puppets");
        final Song battery = new Song("Metallica", "Battery");
        sorted.add(enterSandman);
        sorted.add(masterOfPuppets);
        assertEquals(0, sorted.indexOf(enterSandman));
        assertEquals(1, sorted.indexOf(masterOfPuppets));
        assertEquals(-1, sorted.indexOf(battery));
        sorted.add(battery);
        assertEquals(2, sorted.indexOf(battery));
        assertEquals(-1, sorted.indexOf(null));
        sorted.add(null);
        assertEquals(0, sorted.indexOf(null));
    }
    
    /**
     * Test lastIndexOf() consistency
     */
    public void testLastIndexOf() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source);
        Integer ten = new Integer(10);
        int emptyTest = sorted.lastIndexOf(ten);
        assertEquals(-1, emptyTest);
        Integer one = new Integer(1);
        for (int i = 0; i < 12; i++) {
            source.add(one);
        }
        Integer five = new Integer(5);
        for (int i = 0; i < 13; i++) {
            source.add(five);
        }
        Integer nine = new Integer(9);
        for (int i = 0; i < 10; i++) {
            source.add(nine);
        }
        int firstTestIndex = sorted.lastIndexOf(one);
        assertEquals(11, firstTestIndex);
        int secondTestIndex = sorted.lastIndexOf(five);
        assertEquals(24, secondTestIndex);
        int thirdTestIndex = sorted.lastIndexOf(nine);
        assertEquals(34, thirdTestIndex);
        int fourthTest = sorted.lastIndexOf(ten);
        assertEquals(-1, fourthTest);
    }
    
    /**
     * Test lastIndexOf() consistency with a "weak" Comparator. A weak Comparator
     * is one that returns 0 to indicate two object compare as equal even when
     * .equals() would return false.
     */
    public void testLastIndexOfWithWeakComparator() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source, GlazedLists.comparableComparator());
        final Song enterSandman = new Song("Metallica", "Enter Sandman");
        final Song masterOfPuppets = new Song("Metallica", "Master of Puppets");
        final Song battery = new Song("Metallica", "Battery");
        sorted.add(enterSandman);
        sorted.add(masterOfPuppets);
        sorted.add(battery);
        assertEquals(2, sorted.lastIndexOf(battery));
        assertEquals(1, sorted.lastIndexOf(masterOfPuppets));
        assertEquals(0, sorted.lastIndexOf(enterSandman));
        sorted.add(enterSandman);
        sorted.add(masterOfPuppets);
        sorted.add(battery);
        assertEquals(5, sorted.lastIndexOf(battery));
        assertEquals(4, sorted.lastIndexOf(masterOfPuppets));
        assertEquals(3, sorted.lastIndexOf(enterSandman));
        assertEquals(-1, sorted.lastIndexOf(null));
        sorted.add(null);
        assertEquals(0, sorted.lastIndexOf(null));
        sorted.add(null);
        assertEquals(1, sorted.lastIndexOf(null));
    }
    
    /**
     * Test containment accuracy
     */
    public void testContains() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source);
        Integer ten = new Integer(10);
        boolean emptyTest = sorted.contains(ten);
        assertEquals(false, emptyTest);
        Integer one = new Integer(1);
        for (int i = 0; i < 12; i++) {
            source.add(one);
        }
        Integer five = new Integer(5);
        for (int i = 0; i < 13; i++) {
            source.add(five);
        }
        Integer nine = new Integer(9);
        for (int i = 0; i < 10; i++) {
            source.add(nine);
        }
        boolean firstTest = sorted.contains(one);
        assertEquals(true, firstTest);
        boolean secondTest = sorted.contains(five);
        assertEquals(true, secondTest);
        boolean thirdTest = sorted.contains(nine);
        assertEquals(true, thirdTest);
        boolean fourthTest = sorted.contains(ten);
        assertEquals(false, fourthTest);
    }
    
    /**
     * Test contains() consistency with a "weak" Comparator. A weak Comparator
     * is one that returns 0 to indicate two object compare as equal even when
     * .equals() would return false.
     */
    public void testContainsWithWeakComparator() {
        BasicEventList source = new BasicEventList();
        SortedList sorted = new SortedList(source, GlazedLists.comparableComparator());
        final Song enterSandman = new Song("Metallica", "Enter Sandman");
        final Song masterOfPuppets = new Song("Metallica", "Master of Puppets");
        final Song battery = new Song("Metallica", "Battery");
        sorted.add(enterSandman);
        sorted.add(masterOfPuppets);
        sorted.add(battery);
        assertTrue(sorted.contains(enterSandman));
        assertTrue(sorted.contains(masterOfPuppets));
        assertTrue(sorted.contains(battery));
        assertFalse(sorted.contains(new Song("Metallica", "One")));
        assertFalse(sorted.contains(null));
        sorted.add(null);
        assertTrue(sorted.contains(null));
    }
    
    /**
     * Tests that remove() works, removing the first instance of an element that
     * equals() the specified element.
     */
    public void testRemoveWithNoComparator() {
        EventList basic = new BasicEventList();
        SortedList sorted = new SortedList(basic, null);
        basic.addAll(GlazedListsTests.stringToList("JamesLemieux"));
        sorted.remove("e");
        assertEquals(GlazedListsTests.stringToList("JamsLemieux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JamsLemieux"), basic);
        sorted.remove("e");
        assertEquals(GlazedListsTests.stringToList("JamsLmieux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JamsLmieux"), basic);
        sorted.remove("e");
        assertEquals(GlazedListsTests.stringToList("JamsLmiux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JamsLmiux"), basic);
        sorted.remove("e");
        assertEquals(GlazedListsTests.stringToList("JamsLmiux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JamsLmiux"), basic);
        sorted.remove("m");
        assertEquals(GlazedListsTests.stringToList("JasLmiux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JasLmiux"), basic);
        sorted.remove("m");
        assertEquals(GlazedListsTests.stringToList("JasLiux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JasLiux"), basic);
        sorted.remove("m");
        assertEquals(GlazedListsTests.stringToList("JasLiux"), sorted);
        assertEquals(GlazedListsTests.stringToList("JasLiux"), basic);
    }
    
    /**
     * Tests that remove() works, removing the first instance of an element that
     * equals() the specified element.
     */
    public void testRemoveWithWeakComparator() {
        EventList basic = new BasicEventList();
        SortedList sorted = new SortedList(basic, GlazedLists.caseInsensitiveComparator());
        basic.addAll(GlazedListsTests.stringToList("aAaBbBcCC"));
        sorted.remove("A");
        assertEquals(GlazedListsTests.stringToList("aaBbBcCC"), sorted);
        assertEquals(GlazedListsTests.stringToList("aaBbBcCC"), basic);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("aabBcCC"), sorted);
        assertEquals(GlazedListsTests.stringToList("aabBcCC"), basic);
        sorted.remove("C");
        assertEquals(GlazedListsTests.stringToList("aabBcC"), sorted);
        assertEquals(GlazedListsTests.stringToList("aabBcC"), basic);
        sorted.remove("C");
        assertEquals(GlazedListsTests.stringToList("aabBc"), sorted);
        assertEquals(GlazedListsTests.stringToList("aabBc"), basic);
        sorted.remove("a");
        assertEquals(GlazedListsTests.stringToList("abBc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abBc"), basic);
        sorted.remove("d");
        assertEquals(GlazedListsTests.stringToList("abBc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abBc"), basic);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("abc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abc"), basic);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("abc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abc"), basic);
        sorted.remove("A");
        assertEquals(GlazedListsTests.stringToList("abc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abc"), basic);
        sorted.remove("C");
        assertEquals(GlazedListsTests.stringToList("abc"), sorted);
        assertEquals(GlazedListsTests.stringToList("abc"), basic);
        sorted.remove("a");
        assertEquals(GlazedListsTests.stringToList("bc"), sorted);
        assertEquals(GlazedListsTests.stringToList("bc"), basic);
        sorted.remove("c");
        assertEquals(GlazedListsTests.stringToList("b"), sorted);
        assertEquals(GlazedListsTests.stringToList("b"), basic);
        sorted.remove("c");
        assertEquals(GlazedListsTests.stringToList("b"), sorted);
        assertEquals(GlazedListsTests.stringToList("b"), basic);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("b"), sorted);
        assertEquals(GlazedListsTests.stringToList("b"), basic);
        sorted.remove("b");
        assertEquals(GlazedListsTests.stringToList(""), sorted);
        assertEquals(GlazedListsTests.stringToList(""), basic);
        sorted.remove("b");
        assertEquals(GlazedListsTests.stringToList(""), sorted);
        assertEquals(GlazedListsTests.stringToList(""), basic);
    }
    
    /**
     * Tests that remove() works, removing the first instance of an element that
     * equals() the specified element.
     */
    public void testRemoveWithComparator() {
        EventList basic = new BasicEventList();
        SortedList sorted = new SortedList(basic, GlazedLists.comparableComparator());
        basic.addAll(GlazedListsTests.stringToList("ABBCaabcc"));
        sorted.remove("a");
        assertEquals(GlazedListsTests.stringToList("ABBCabcc"), basic);
        assertEquals(GlazedListsTests.stringToList("ABBCabcc"), sorted);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("ABCabcc"), basic);
        assertEquals(GlazedListsTests.stringToList("ABCabcc"), sorted);
        sorted.remove("c");
        assertEquals(GlazedListsTests.stringToList("ABCabc"), basic);
        assertEquals(GlazedListsTests.stringToList("ABCabc"), sorted);
        sorted.remove("d");
        assertEquals(GlazedListsTests.stringToList("ABCabc"), basic);
        assertEquals(GlazedListsTests.stringToList("ABCabc"), sorted);
        sorted.remove("C");
        assertEquals(GlazedListsTests.stringToList("ABabc"), basic);
        assertEquals(GlazedListsTests.stringToList("ABabc"), sorted);
        sorted.remove("B");
        assertEquals(GlazedListsTests.stringToList("Aabc"), basic);
        assertEquals(GlazedListsTests.stringToList("Aabc"), sorted);
        sorted.remove("b");
        assertEquals(GlazedListsTests.stringToList("Aac"), basic);
        assertEquals(GlazedListsTests.stringToList("Aac"), sorted);
        sorted.remove("A");
        assertEquals(GlazedListsTests.stringToList("ac"), basic);
        assertEquals(GlazedListsTests.stringToList("ac"), sorted);
        sorted.remove("a");
        assertEquals(GlazedListsTests.stringToList("c"), basic);
        assertEquals(GlazedListsTests.stringToList("c"), sorted);
        sorted.remove("a");
        assertEquals(GlazedListsTests.stringToList("c"), basic);
        assertEquals(GlazedListsTests.stringToList("c"), sorted);
        sorted.remove("c");
        assertEquals(GlazedListsTests.stringToList(""), basic);
        assertEquals(GlazedListsTests.stringToList(""), sorted);
    }
    
    /**
     * Tests that the SortedList can handle reordering events.
     */
    public void testReorder() {
        SortedList source = new SortedList(new BasicEventList());
        source.add("CB");
        source.add("BC");
        source.add("DD");
        source.add("AA");
        SortedList sorted = new SortedList(source, GlazedLists.reverseComparator());
        List consistencyTestList = new ArrayList();
        consistencyTestList.addAll(sorted);
        source.setComparator(new ReverseStringComparator());
        assertEquals(consistencyTestList, sorted);
        source.setComparator(null);
        assertEquals(consistencyTestList, sorted);
    }
    
    /**
     * Verify that the sorted list works with no compatator.
     */
    public void testNoComparator() {
        List consistencyTestList = new ArrayList();
        consistencyTestList.add("A");
        consistencyTestList.add("C");
        consistencyTestList.add("B");
        SortedList sorted = new SortedList(new BasicEventList(), null);
        sorted.addAll(consistencyTestList);
        assertEquals(consistencyTestList, sorted);
        sorted.set(2, "A");
        sorted.clear();
        assertEquals(Collections.EMPTY_LIST, sorted);
    }
    
    /**
     * Test that values that are indistinguishable by the SortedList are ordered
     * by their index.
     */
    public void testEqualValuesOrderedByIndex() {
        Comparator intCompareAt0 = new StringLengthComparator();
        sortedList.dispose();
        sortedList = new SortedList(unsortedList, intCompareAt0);
        unsortedList.add(0, "chaos");
        unsortedList.add(1, "fiery");
        unsortedList.add(2, "gecko");
        unsortedList.add(0, "banjo");
        unsortedList.add(2, "dingo");
        unsortedList.add(5, "hippo");
        unsortedList.add(0, "album");
        unsortedList.add(4, "eerie");
        assertEquals(unsortedList, sortedList);
    }
    
    /**
     * Test that the SortedList doesn't get grumpy if everything is always equal.
     */
    public void testAlwaysEqualComparator() {
        Comparator alwaysEqualComparator = new AlwaysEqualComparator();
        sortedList.dispose();
        unsortedList.add(new Integer(4));
        unsortedList.add(new Integer(3));
        unsortedList.add(new Integer(1));
        sortedList = new SortedList(unsortedList, alwaysEqualComparator);
        unsortedList.add(new Integer(5));
        unsortedList.add(new Integer(3));
        unsortedList.add(new Integer(0));
        unsortedList.add(new Integer(9));
        assertEquals(unsortedList, sortedList);
    }
    
    /**
     * Test that the SortedList doesn't get grumpy if half the elements are null.
     */
    public void testHalfNullComparator() {
        Comparator halfNullComparator = new HalfNullComparator();
        sortedList.dispose();
        Position p = new Position(4);
        unsortedList.add(p);
        unsortedList.add(new Position(3));
        unsortedList.add(new Position(1));
        sortedList = new SortedList(unsortedList, halfNullComparator);
        p.setPosition(2);
        sortedList.set(2, p);
        assertEquals(unsortedList, sortedList);
    }
    
    /**
     * Tests an empty sorted list's iterator
     */
    public void testIteratorOnEmptySortedList() {
        Iterator i = sortedList.iterator();
        assertEquals(false, i.hasNext());
        try {
            i.next();
            fail("An expected Exception was not thrown.");
        } catch (NoSuchElementException e) {
        } catch (Exception e) {
            fail("The following Exception was not expected:\n" + e);
        }
        i = sortedList.iterator();
        try {
            i.next();
            fail("An expected Exception was not thrown.");
        } catch (NoSuchElementException e) {
        } catch (Exception e) {
            fail("The following Exception was not expected:\n" + e);
        }
    }
    
    /**
     * Tests a SortedList's iterator, read-only
     */
    public void testIteratorReadOnly() {
        sortedList.add("Riders");
        sortedList.add("Stampeders");
        sortedList.add("Bombers");
        sortedList.add("Eskimos");
        sortedList.add("Argos");
        sortedList.add("Ti-Cats");
        sortedList.add("Renegades");
        sortedList.add("Als");
        String[] expected = {"Als", "Argos", "Bombers", "Eskimos", "Renegades", "Riders", "Stampeders", "Ti-Cats"};
        int counter = 0;
        for (Iterator i = sortedList.iterator(); i.hasNext(); counter++) {
            assertEquals(expected[counter], i.next());
        }
        assertEquals(expected.length, counter);
    }
    
    /**
     * Tests a SortedList's iterator while removing
     */
    public void testIteratorRemoves() {
        sortedList.add("Riders");
        sortedList.add("Stampeders");
        sortedList.add("Bombers");
        sortedList.add("Eskimos");
        sortedList.add("Argos");
        sortedList.add("Ti-Cats");
        sortedList.add("Renegades");
        sortedList.add("Als");
        String[] expected = {"Als", "Argos", "Bombers", "Eskimos", "Renegades", "Riders", "Stampeders", "Ti-Cats"};
        Iterator i = sortedList.iterator();
        try {
            i.remove();
            fail("An expected Exception was not thrown.");
        } catch (NoSuchElementException e) {
        }
        int counter = 0;
        for (i = sortedList.iterator(); i.hasNext(); counter++) {
            assertEquals(expected[counter], i.next());
            i.remove();
            try {
                i.remove();
                fail("An expected Exception was not thrown.");
            } catch (NoSuchElementException e) {
            }
        }
        assertEquals(expected.length, counter);
        assertEquals(0, sortedList.size());
        try {
            i.remove();
            fail("An expected Exception was not thrown.");
        } catch (NoSuchElementException e) {
        }
    }
    
    public void testSortIndex() {
        sortedList.addAll(GlazedListsTests.stringToList("ac"));
        assertEquals(1, sortedList.sortIndex("b"));
        assertEquals(1, sortedList.lastSortIndex("b"));
        sortedList.clear();
        sortedList.addAll(GlazedListsTests.stringToList("abbbc"));
        assertEquals(1, sortedList.sortIndex("b"));
        assertEquals(3, sortedList.lastSortIndex("b"));
        assertEquals(0, sortedList.sortIndex("3"));
        assertEquals(0, sortedList.lastSortIndex("3"));
        assertEquals(5, sortedList.sortIndex("d"));
        assertEquals(5, sortedList.lastSortIndex("d"));
    }
    
    public void testComparatorAndEqualsMethodDontAgree() {
        sortedList.dispose();
        sortedList = new SortedList(unsortedList, String.CASE_INSENSITIVE_ORDER);
        sortedList.addAll(GlazedListsTests.stringToList("ac"));
        assertEquals(1, sortedList.sortIndex("b"));
        assertEquals(1, sortedList.lastSortIndex("b"));
        assertEquals(-1, sortedList.indexOf("b"));
        assertEquals(-1, sortedList.lastIndexOf("b"));
        sortedList.clear();
        sortedList.addAll(GlazedListsTests.stringToList("abbbc"));
        assertEquals(1, sortedList.sortIndex("b"));
        assertEquals(3, sortedList.lastSortIndex("b"));
        assertEquals(1, sortedList.indexOf("b"));
        assertEquals(3, sortedList.lastIndexOf("b"));
        assertEquals(1, sortedList.sortIndex("B"));
        assertEquals(3, sortedList.lastSortIndex("B"));
        assertEquals(-1, sortedList.indexOf("B"));
        assertEquals(-1, sortedList.lastIndexOf("B"));
    }
    
    public void testAddAtIndex() {
        final EventList source = new BasicEventList();
        final SortedList sortedList = new SortedList(source, String.CASE_INSENSITIVE_ORDER);
        source.addAll(GlazedListsTests.stringToList("babac"));
        assertEquals(GlazedListsTests.stringToList("babac"), source);
        assertEquals(GlazedListsTests.stringToList("aabbc"), sortedList);
        sortedList.add(2, "c");
        assertEquals(GlazedListsTests.stringToList("cbabac"), source);
        assertEquals(GlazedListsTests.stringToList("aabbcc"), sortedList);
        sortedList.add(3, "d");
        assertEquals(GlazedListsTests.stringToList("cbadbac"), source);
        assertEquals(GlazedListsTests.stringToList("aabbccd"), sortedList);
        sortedList.add(sortedList.size() - 1, "a");
        assertEquals(GlazedListsTests.stringToList("cbaadbac"), source);
        assertEquals(GlazedListsTests.stringToList("aaabbccd"), sortedList);
        sortedList.add(sortedList.size(), "e");
        assertEquals(GlazedListsTests.stringToList("cbaadbace"), source);
        assertEquals(GlazedListsTests.stringToList("aaabbccde"), sortedList);
    }
    
    /**
     * This test ensures that the SortedList sorts by its own
     * order, then by the order in the source list.
     */
    public void testSortedListHandlesSortEvents() {
        Comparator artistComparator = GlazedLists.beanPropertyComparator(Song.class, "artist");
        Comparator songComparator = GlazedLists.beanPropertyComparator(Song.class, "song");
        List expectedOrder;
        sortedList.setComparator(null);
        SortedList sortedAgain = new SortedList(sortedList, artistComparator);
        ListConsistencyListener.install(sortedAgain);
        unsortedList.add(new Song("Limp Bizkit", "Nookie"));
        unsortedList.add(new Song("Limp Bizkit", "Eat You Alive"));
        unsortedList.add(new Song("Limp Bizkit", "Rearranged"));
        unsortedList.add(new Song("Limp Bizkit", "The Unquestionable Truth"));
        unsortedList.add(new Song("Filter", "Welcome to the Fold"));
        unsortedList.add(new Song("Filter", "Take a Picture"));
        unsortedList.add(new Song("Filter", "Miss Blue"));
        unsortedList.add(new Song("Slipknot", "Wait and Bleed"));
        unsortedList.add(new Song("Slipknot", "Duality"));
        unsortedList.add(new Song("Godsmack", "Whatever"));
        unsortedList.add(new Song("Godsmack", "Running Blind"));
        expectedOrder = new ArrayList(unsortedList);
        Collections.sort(expectedOrder, artistComparator);
        assertEquals(expectedOrder, sortedAgain);
        sortedList.setComparator(songComparator);
        expectedOrder = new ArrayList(unsortedList);
        Collections.sort(expectedOrder, GlazedLists.chainComparators((List)Arrays.asList(new Comparator[]{artistComparator, songComparator})));
        assertEquals(expectedOrder, sortedAgain);
        sortedList.setComparator(null);
        expectedOrder = new ArrayList(unsortedList);
        Collections.sort(expectedOrder, artistComparator);
        assertEquals(expectedOrder, sortedAgain);
        unsortedList.clear();
        Random dice = new Random(0);
        List artists = GlazedListsTests.stringToList("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        List songs = GlazedListsTests.stringToList("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        for (int a = 0; a < 200; a++) {
            String randomArtist = (String)artists.get(dice.nextInt(artists.size()));
            String randomSong = (String)artists.get(dice.nextInt(artists.size()));
            unsortedList.add(new Song(randomArtist, randomSong));
        }
        sortedList.setComparator(songComparator);
        expectedOrder = new ArrayList(unsortedList);
        Collections.sort(expectedOrder, GlazedLists.chainComparators((List)Arrays.asList(new Comparator[]{artistComparator, songComparator})));
        assertEquals(expectedOrder, sortedAgain);
        sortedList.setComparator(null);
        expectedOrder = new ArrayList(unsortedList);
        Collections.sort(expectedOrder, artistComparator);
        assertEquals(expectedOrder, sortedAgain);
    }
    
    public void testSortedSource() {
        Comparator alphabetical = GlazedLists.comparableComparator();
        Comparator length = new StringLengthComparator();
        sortedList.setComparator(null);
        unsortedList.addAll(Arrays.asList(new String[]{"dddd", "aaa", "c", "bb"}));
        assertEquals(Arrays.asList(new String[]{"dddd", "aaa", "c", "bb"}), sortedList);
        SortedList resortedList = new SortedList(sortedList, length);
        ListConsistencyListener.install(resortedList);
        assertEquals(Arrays.asList(new String[]{"c", "bb", "aaa", "dddd"}), resortedList);
        sortedList.setComparator(alphabetical);
        assertSortedEquals(sortedList, resortedList);
        unsortedList.addAll(Arrays.asList(new String[]{"c", "dddd", "aaa", "bb"}));
        assertSortedEquals(sortedList, resortedList);
        sortedList.setComparator(alphabetical);
        assertSortedEquals(sortedList, resortedList);
    }
    
    public void testIteratorIsConsistent() {
        ListConsistencyListener.install(sortedList);
        unsortedList.addAll(Arrays.asList(new String[]{"d", "c", "a", "b"}));
        Iterator iterator = sortedList.iterator();
        assertEquals("a", iterator.next());
        assertEquals("a", sortedList.get(0));
        assertEquals("b", iterator.next());
        assertEquals("b", sortedList.get(1));
        assertEquals("c", iterator.next());
        assertEquals("c", sortedList.get(2));
        assertEquals("d", iterator.next());
        assertEquals("d", sortedList.get(3));
    }
    
    /**
     * This test ensures SortedList's generic arguments are correct.
     * Specifically, a SortedList<E> should be able to accept any Comparator<? super E>.
     * In other words:
     *
     * <p>SortedList<Number> can accept a Comparator<Number> or Comparator<Object>, but not
     * a Comparator<Integer>.
     */
    public void testCompilingWithGenerics() {
        SortedList integers = new SortedList(new BasicEventList());
        integers.setComparator(GlazedLists.comparableComparator());
        integers.setComparator(new AlwaysEqualComparator());
        new SortedList(new BasicEventList(), GlazedLists.comparableComparator());
        new SortedList(new BasicEventList(), new AlwaysEqualComparator());
    }
    
    public void testChangingSortMode() {
        SortedList names = new SortedList(new BasicEventList());
        names.setMode(SortedList.AVOID_MOVING_ELEMENTS);
        names.add("");
        names.add("");
        names.add("");
        names.add("");
        names.set(0, "abba");
        names.set(1, "foo fighters");
        names.set(2, "nirvana");
        names.set(3, "cardigans");
        assertEquals("abba", (String)names.get(0));
        assertEquals("foo fighters", (String)names.get(1));
        assertEquals("nirvana", (String)names.get(2));
        assertEquals("cardigans", (String)names.get(3));
        names.setMode(SortedList.STRICT_SORT_ORDER);
        assertEquals("abba", (String)names.get(0));
        assertEquals("cardigans", (String)names.get(1));
        assertEquals("foo fighters", (String)names.get(2));
        assertEquals("nirvana", (String)names.get(3));
        names.setMode(SortedList.AVOID_MOVING_ELEMENTS);
        names.add("bob marley");
        assertEquals("abba", (String)names.get(0));
        assertEquals("bob marley", (String)names.get(1));
        assertEquals("cardigans", (String)names.get(2));
        assertEquals("foo fighters", (String)names.get(3));
        assertEquals("nirvana", (String)names.get(4));
        names.set(1, "zamfir");
        assertEquals("abba", (String)names.get(0));
        assertEquals("zamfir", (String)names.get(1));
        assertEquals("cardigans", (String)names.get(2));
        assertEquals("foo fighters", (String)names.get(3));
        assertEquals("nirvana", (String)names.get(4));
    }
    
    /**
     * test a sorted list for equality 
     */
    public void assertSortedEquals(List unsorted, SortedList sorted) {
        unsorted = new ArrayList(unsorted);
        if (sorted.getComparator() != null) Collections.sort(unsorted, sorted.getComparator());
        assertEquals(unsorted, sorted);
    }
    
    /**
     * Compares two objects to be equal.
     */
    class AlwaysEqualComparator implements Comparator {
        
        AlwaysEqualComparator() {
            super();
        }
        
        public int compare(Object a, Object b) {
            return 0;
        }
    }
    
    /**
     * Compares two objects with the second one always null.
     */
    class HalfNullComparator implements Comparator {
        
        HalfNullComparator() {
            super();
        }
        Comparator target = GlazedLists.comparableComparator();
        
        public int compare(Object a, Object b) {
            return target.compare(b, null);
        }
    }
    
    /**
     * Simple class that sorts in the same order as its position value. Like an
     * {@link Integer}, but mutable.
     */
    static class Position implements Comparable {
        private int position;
        
        public Position(int position) {
            super();
            this.position = position;
        }
        
        public int getPosition() {
            return position;
        }
        
        public void setPosition(int position) {
            this.position = position;
        }
        
        public String toString() {
            return "P:" + position;
        }
        
        public int compareTo(Object o) {
            return position - ((Position)(SortedListTest.Position)o).position;
        }
    }
    
    /**
     * Compares Strings by their length.
     */
    class StringLengthComparator implements Comparator {
        
        StringLengthComparator() {
            super();
        }
        
        public int compare(Object x0, Object x1) {
            String a = (String)x0;
            String b = (String)x1;
            return a.length() - b.length();
        }
        /*missing*/
    }
    
    /**
     * A Comparator that compares strings from end to beginning rather than
     * normally.
     */
    private static class ReverseStringComparator implements Comparator {
        
        private ReverseStringComparator() {
            super();
        }
        public Comparator delegate = (Comparator)GlazedLists.comparableComparator();
        
        public int compare(Object x0, Object x1) {
            String a = (String)x0;
            String b = (String)x1;
            return delegate.compare(flip(a), flip(b));
        }
        
        public String flip(String original) {
            char[] originalAsChars = original.toCharArray();
            int length = originalAsChars.length;
            for (int i = 0; i < (length / 2); i++) {
                char temp = originalAsChars[i];
                originalAsChars[i] = originalAsChars[length - i - 1];
                originalAsChars[length - i - 1] = temp;
            }
            return new String(originalAsChars);
        }
        /*missing*/
    }
    
    public static class Song implements Comparable {
        String artist;
        String song;
        
        public Song(String artist, String song) {
            super();
            this.artist = artist;
            this.song = song;
        }
        
        public String getArtist() {
            return artist;
        }
        
        public String getSong() {
            return song;
        }
        
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            final Song song1 = (Song)(SortedListTest.Song)o;
            if (!artist.equals(song1.artist)) return false;
            if (!song.equals(song1.song)) return false;
            return true;
        }
        
        public int hashCode() {
            int result;
            result = artist.hashCode();
            result = 29 * result + song.hashCode();
            return result;
        }
        
        public int compareTo(Object o) {
            final Song song = (Song)(SortedListTest.Song)o;
            return this.getArtist().compareTo(song.getArtist());
        }
        
        public String toString() {
            return this.getArtist() + " - " + this.getSong();
        }
    }
}
