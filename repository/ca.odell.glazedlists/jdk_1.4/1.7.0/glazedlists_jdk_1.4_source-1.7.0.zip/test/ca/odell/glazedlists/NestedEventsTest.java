package ca.odell.glazedlists;

import junit.framework.*;
import java.util.*;

/**
 * Verifies that list events are nested properly.
 *
 * @see <a href="https://glazedlists.dev.java.net/issues/show_bug.cgi?id=165">Bug 165</a>
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class NestedEventsTest extends TestCase {
    
    public NestedEventsTest() {
        super();
    }
    private EventList source = null;
    private ExternalNestingEventList nestingList = null;
    private ListConsistencyListener counter = null;
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        source = new BasicEventList();
        nestingList = new ExternalNestingEventList(source);
        counter = ListConsistencyListener.install(nestingList);
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        counter = null;
        nestingList = null;
        source = null;
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testFullyDeletedInserts() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.add(2, "C");
        source.add(3, "D");
        source.add(4, "E");
        source.remove(1);
        source.remove(1);
        source.remove(1);
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("AEFG"));
        assertEquals(2, counter.getEventCount());
        assertEquals(2, counter.getChangeCount(1));
    }
    
    /**
     * Validates that complex contradicting events can be nested.
     */
    public void testDeletedInserts() {
        List jesse = GlazedListsTests.stringToList("JESSE");
        List wilson = GlazedListsTests.stringToList("WILSON");
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(contradictionsAllowed);
        source.addAll(jesse);
        source.removeAll(wilson);
        nestingList.commitEvent();
        assertEquals(3, nestingList.size());
        assertEquals(1, counter.getEventCount());
        assertEquals(3, counter.getChangeCount(0));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testFullyUpdatedInserts() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.add(2, "C");
        source.add(3, "D");
        source.add(4, "E");
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("ABcdeFG"));
        assertEquals(2, counter.getEventCount());
        assertEquals(3, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testUpdatedInserts() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.add(2, "C");
        source.add(3, "D");
        source.add(4, "E");
        source.set(1, "b");
        source.set(2, "c");
        source.set(3, "d");
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("AbcdEFG"));
        assertEquals(2, counter.getEventCount());
        assertEquals(4, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testFullyDeletedUpdates() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        source.remove(2);
        source.remove(2);
        source.remove(2);
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("ABFG"));
        assertEquals(2, counter.getEventCount());
        assertEquals(3, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testDeletedUpdates() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        source.remove(1);
        source.remove(1);
        source.remove(1);
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("AeFG"));
        assertEquals(2, counter.getEventCount());
        assertEquals(4, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testUpdatedUpdates() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        source.add("H");
        source.set(3, "d");
        source.set(4, "e");
        source.set(5, "f");
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("ABcdefGH"));
        assertEquals(2, counter.getEventCount());
        assertEquals(5, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events can be nested.
     */
    public void testFullyUpdatedUpdates() {
        boolean contradictionsAllowed = true;
        nestingList.beginEvent(false);
        source.addAll(GlazedListsTests.stringToList("ABCDEFG"));
        nestingList.commitEvent();
        nestingList.beginEvent(contradictionsAllowed);
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        source.add("H");
        source.set(2, "c");
        source.set(3, "d");
        source.set(4, "e");
        nestingList.commitEvent();
        assertEquals(nestingList, GlazedListsTests.stringToList("ABcdeFGH"));
        assertEquals(2, counter.getEventCount());
        assertEquals(4, counter.getChangeCount(1));
    }
    
    /**
     * Validates that simple contradicting events throw an exception if not allowed.
     */
    public void testSimpleContradictingEventsFail() {
        boolean contradictionsAllowed = false;
        try {
            nestingList.beginEvent(contradictionsAllowed);
            source.add("hello");
            source.remove(0);
            nestingList.commitEvent();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
        }
    }
    
    /**
     * Validates that complex contradicting events throw an exception if not allowed.
     */
    public void testComplexContradictingEventsFail() {
        List jesse = GlazedListsTests.stringToList("JESSE");
        List wilson = GlazedListsTests.stringToList("WILSON");
        boolean contradictionsAllowed = false;
        try {
            nestingList.beginEvent(contradictionsAllowed);
            source.addAll(jesse);
            source.removeAll(wilson);
            nestingList.commitEvent();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
        }
    }
}
