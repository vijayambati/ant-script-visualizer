package ca.odell.glazedlists.swing;

import junit.framework.TestCase;
import javax.swing.*;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.GlazedLists;

public class AutoCompleteSupportThreadingTest extends TestCase {
    
    public AutoCompleteSupportThreadingTest() {
        super();
    }
    
    public void testNonEDTAccess() throws Exception {
        try {
            AutoCompleteSupport.install(new JComboBox(), new BasicEventList());
            fail("failed to receive IllegalStateException installing AutoCompleteSupport from non-EDT");
        } catch (IllegalStateException e) {
        }
        try {
            AutoCompleteSupport.install(new JComboBox(), new BasicEventList(), GlazedLists.toStringTextFilterator());
            fail("failed to receive IllegalStateException installing AutoCompleteSupport from non-EDT");
        } catch (IllegalStateException e) {
        }
        final InstallAutoCompleteSupportRunnable installAutoCompleteSupportRunnable = new InstallAutoCompleteSupportRunnable();
        SwingUtilities.invokeAndWait(installAutoCompleteSupportRunnable);
        final AutoCompleteSupport support = installAutoCompleteSupportRunnable.getSupport();
        try {
            support.setStrict(true);
            fail("failed to receive IllegalStateException mutating AutoCompleteSupport from non-EDT");
        } catch (IllegalStateException e) {
        }
        try {
            support.setCorrectsCase(true);
            fail("failed to receive IllegalStateException mutating AutoCompleteSupport from non-EDT");
        } catch (IllegalStateException e) {
        }
        try {
            support.uninstall();
            fail("failed to receive IllegalStateException uninstalling AutoCompleteSupport from non-EDT");
        } catch (IllegalStateException e) {
        }
    }
    
    private static final class InstallAutoCompleteSupportRunnable implements Runnable {
        
        private InstallAutoCompleteSupportRunnable() {
            super();
        }
        private AutoCompleteSupport support;
        
        public void run() {
            support = AutoCompleteSupport.install(new JComboBox(), new BasicEventList());
        }
        
        public AutoCompleteSupport getSupport() {
            return support;
        }
    }
}
