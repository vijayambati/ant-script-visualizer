package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

interface SupportsTrailerHitch {
    
    public void setTowedVehicle(Automobile towedVehicle);
    
    public Automobile getTowedVehicle();
}
