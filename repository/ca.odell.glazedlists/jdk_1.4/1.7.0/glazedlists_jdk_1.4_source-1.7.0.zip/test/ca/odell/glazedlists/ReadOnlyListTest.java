package ca.odell.glazedlists;

import junit.framework.*;
import java.util.*;

/**
 * A ReadOnlyListTest tests the functionality of the ReadOnlyList
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ReadOnlyListTest extends TestCase {
    
    public ReadOnlyListTest() {
        super();
    }
    
    /**
     * attempt to modify this list 
     */
    private EventList readOnlyData = null;
    
    /**
     * attempt to modify this list 
     */
    private List readOnly = null;
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        readOnlyData = new BasicEventList();
        readOnlyData.add("A");
        readOnlyData.add("B");
        readOnlyData.add("C");
        readOnly = GlazedLists.readOnlyList(readOnlyData);
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        readOnlyData = null;
        readOnly = null;
    }
    
    /**
     * Verifies that the sublist is also read only.
     */
    public void testSubList() {
        try {
            readOnly.subList(0, 3).clear();
            fail();
        } catch (UnsupportedOperationException e) {
        }
        readOnlyData.subList(0, 3).clear();
    }
    
    /**
     * Verifies that the sublist is also read only.
     */
    public void testIterator() {
        try {
            Iterator i = readOnly.iterator();
            i.next();
            i.remove();
            fail();
        } catch (UnsupportedOperationException e) {
        }
        Iterator i = readOnlyData.iterator();
        i.next();
        i.remove();
    }
    
    public void testReadMethods() {
        readOnlyData.clear();
        readOnlyData.addAll(GlazedListsTests.stringToList("ABCDEFGB"));
        assertEquals("A", readOnly.get(0));
        assertTrue(readOnly.contains("E"));
        assertEquals(readOnly, Arrays.asList(readOnly.toArray()));
        assertEquals(readOnly, Arrays.asList(readOnly.toArray(new String[0])));
        assertTrue(readOnly.containsAll(Collections.singletonList("B")));
        assertEquals(3, readOnly.indexOf("D"));
        assertEquals(readOnly.size() - 1, readOnly.lastIndexOf("B"));
        assertEquals(GlazedListsTests.stringToList("CDE"), readOnly.subList(2, 5));
    }
    
    public void testWriteMethods() {
        try {
            readOnly.add(null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.add(0, null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.addAll(null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.addAll(0, null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.clear();
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.remove(null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.remove(0);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.removeAll(null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.retainAll(null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
        try {
            readOnly.set(0, null);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
}
