package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.*;
import ca.odell.glazedlists.matchers.Matchers;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.Collections;

/**
 * This test verifies that the EventSelectionModel works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class EventSelectionModelTest extends SwingTestCase {
    
    public EventSelectionModelTest() {
        super();
    }
    
    /**
     * Tests the user interface. This is a mandatory method in SwingTestCase classes.
     */
    public void testGui() {
        super.testGui();
    }
    
    /**
     * Tests that selection survives a sorting.
     */
    public void guiTestSort() {
        BasicEventList list = new BasicEventList();
        SortedList sorted = new SortedList(list, null);
        EventSelectionModel eventSelectionModel = new EventSelectionModel(sorted);
        list.addAll(GlazedListsTests.delimitedStringToList("E C F B A D"));
        assertEquals(Collections.EMPTY_LIST, eventSelectionModel.getSelected());
        eventSelectionModel.addSelectionInterval(0, 0);
        eventSelectionModel.addSelectionInterval(4, 4);
        assertEquals(GlazedListsTests.delimitedStringToList("E A"), eventSelectionModel.getSelected());
        sorted.setComparator(GlazedLists.comparableComparator());
        assertEquals(GlazedListsTests.delimitedStringToList("A E"), eventSelectionModel.getSelected());
        sorted.setComparator(GlazedLists.reverseComparator());
        assertEquals(GlazedListsTests.delimitedStringToList("E A"), eventSelectionModel.getSelected());
    }
    
    /**
     * Verifies that the selected index is cleared when the selection is cleared.
     */
    public void guiTestClear() {
        BasicEventList list = new BasicEventList();
        EventSelectionModel eventSelectionModel = new EventSelectionModel(list);
        list.addAll(GlazedListsTests.delimitedStringToList("A B C D E F"));
        eventSelectionModel.addSelectionInterval(1, 4);
        assertEquals(list.subList(1, 5), eventSelectionModel.getSelected());
        eventSelectionModel.clearSelection();
        assertEquals(Collections.EMPTY_LIST, eventSelectionModel.getSelected());
        assertEquals(-1, eventSelectionModel.getMinSelectionIndex());
        assertEquals(-1, eventSelectionModel.getMaxSelectionIndex());
        assertEquals(true, eventSelectionModel.isSelectionEmpty());
    }
    
    /**
     * Tests a problem where the {@link EventSelectionModel} fails to fire events
     *
     * This test was contributed by: Sergey Bogatyrjov
     */
    public void guiTestSelectionModel() {
        EventList source = new BasicEventList();
        source.addAll(GlazedListsTests.delimitedStringToList("one two three"));
        FilterList filtered = new FilterList(source, Matchers.trueMatcher());
        EventSelectionModel model = new EventSelectionModel(filtered);
        ListSelectionChangeCounter counter = new ListSelectionChangeCounter();
        model.addListSelectionListener(counter);
        model.setSelectionInterval(1, 1);
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.falseMatcher());
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.trueMatcher());
        assertEquals(0, counter.getCountAndReset());
        model.setSelectionInterval(0, 0);
        assertEquals(1, counter.getCountAndReset());
        filtered.setMatcher(Matchers.falseMatcher());
        assertEquals(1, counter.getCountAndReset());
    }
    
    public void guiTestConstructorLocking() throws InterruptedException {
        final ThreadRecorderEventList atomicList = new ThreadRecorderEventList(new BasicEventList());
        final Thread writerThread = new Thread(GlazedListsTests.createJerkyAddRunnable(atomicList, null, 2000, 50), "WriterThread");
        writerThread.start();
        Thread.sleep(200);
        final EventList delayList = GlazedListsTests.delayList(atomicList, 50);
        new EventSelectionModel(delayList);
        writerThread.join();
        assertEquals(3, atomicList.getReadWriteBlockCount());
    }
    
    public void guiTestDeleteSelectedRows() {
        EventList source = new BasicEventList();
        source.addAll(GlazedListsTests.delimitedStringToList("one two three"));
        EventSelectionModel model = new EventSelectionModel(source);
        ListSelectionChangeCounter counter = new ListSelectionChangeCounter();
        model.addListSelectionListener(counter);
        model.setSelectionInterval(0, 2);
        assertEquals(source, model.getSelected());
        assertEquals(1, counter.getCountAndReset());
        model.getSelected().clear();
        assertEquals(Collections.EMPTY_LIST, source);
        assertEquals(Collections.EMPTY_LIST, model.getSelected());
        assertEquals(1, counter.getCountAndReset());
    }
    
    /**
     * Counts the number of ListSelectionEvents fired.
     */
    private class ListSelectionChangeCounter implements ListSelectionListener {
        
        private ListSelectionChangeCounter() {
            super();
        }
        private int count = 0;
        
        public void valueChanged(ListSelectionEvent e) {
            count++;
        }
        
        public int getCountAndReset() {
            int result = count;
            count = 0;
            return result;
        }
    }
}
