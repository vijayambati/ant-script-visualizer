package ca.odell.glazedlists.io;

import ca.odell.glazedlists.EventList;
import java.util.Random;

/**
 * A helper class provided to simplify the included
 * tests contained in main.
 */
class CacheTestHelper {
    
    /**
     * The variables to allow the test to be changed easily 
     */
    private int requestWaitTime = 0;
    private int sourceListSize = 0;
    private int cacheSize = 0;
    private int interval = 0;
    
    /**
     * The CachingList to performance test 
     */
    private CachingList testCache = null;
    
    /**
     * The underlying EventList 
     */
    private EventList sourceList = null;
    
    /**
     * Creates a new CacheTestHelper to performance test the
     * CachingList.  This Constructor implicitly sizes the
     * CachingList to be one-half the size of the source list.
     *
     * @param sourceListSize The size of the underlying list
     * @param requestWaitTime The amount of time to delay when requesting
     *        information from the underlying list
     */
    protected CacheTestHelper(int sourceListSize, int requestWaitTime) {
        super();
        this.sourceListSize = sourceListSize;
        this.requestWaitTime = requestWaitTime;
        cacheSize = (int)Math.round(sourceListSize / 2.0);
        interval = (int)Math.round(cacheSize / 10.0);
    }
    
    /**
     * Creates a new CacheTestHelper to performance test the
     * CachingList.  This Constructor explicitly sizes the
     * CachingList
     *
     * @param sourceListSize The size of the underlying list
     * @param cacheSize The explicitly set size for the CachingList
     * @param requestWaitTime The amount of time to delay when requesting
     *        information from the underlying list
     */
    protected CacheTestHelper(int sourceListSize, int cacheSize, int requestWaitTime) {
        super();
        this.sourceListSize = sourceListSize;
        this.requestWaitTime = requestWaitTime;
        this.cacheSize = cacheSize;
        interval = (int)Math.round(cacheSize / 10.0);
    }
    
    /**
     * Convenience method to allow the running of all of the
     * tests defined in this helper class via a single method call
     */
    protected void runTests() {
        System.out.println("Beginning Performance Tests...");
        sourceList = new WaitEventList(requestWaitTime);
        for (int i = 0; i < sourceListSize; i++) {
            sourceList.add(new Integer(i));
        }
        long startTime = System.currentTimeMillis();
        testRetrievalFromCache();
        setUp();
        testRemoveOfCachedData();
        tearDown();
        setUp();
        testRemoveOfUncachedData();
        tearDown();
        setUp();
        testRandomInsertion();
        tearDown();
        setUp();
        testClearingFullCache();
        tearDown();
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - startTime;
        System.out.println("End of Tests");
        System.out.println("Total Test Time: " + totalTime + "ms.");
    }
    
    /**
     * The Particular Test Cases 
     */
    private void testRetrievalFromCache() {
        for (int i = 0; i <= 10; i++) {
            setUp();
            performNGets(i * interval);
            tearDown();
        }
    }
    
    private void testRemoveOfCachedData() {
        System.out.println("Testing the Expense of Removing " + cacheSize + " Cached Entries.");
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < cacheSize; i++) {
            sourceList.remove(0);
        }
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        System.out.println("Test completed in: " + timeTaken + "ms\n");
    }
    
    private void testRemoveOfUncachedData() {
        System.out.println("Testing the Expense of Removing " + cacheSize + " Uncached Entries.");
        long startTime = System.currentTimeMillis();
        for (int i = cacheSize; i < sourceListSize; i++) {
            sourceList.remove(cacheSize);
        }
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        System.out.println("Test completed in: " + timeTaken + "ms\n");
    }
    
    private void testRandomInsertion() {
        Random random = new Random();
        System.out.println("Testing the Expense of " + cacheSize + " Random Insertions.");
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < cacheSize; i++) {
            int index = random.nextInt(cacheSize);
            sourceList.add(index, new Integer(index));
        }
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        System.out.println("Test completed in: " + timeTaken + "ms\n");
    }
    
    private void testClearingFullCache() {
        System.out.println("Testing the Expense of Calling clear() on a Full Cache");
        long startTime = System.currentTimeMillis();
        testCache.clear();
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        System.out.println("Test completed in: " + timeTaken + "ms\n");
    }
    
    /**
     * Lookup from the cache starting at <code>start</code> and going
     * to the size of the cache
     *
     * @param start The index to start getting values from
     */
    private void performNGets(int start) {
        System.out.println("Running Test For A Cache Containing " + (100.0 * ((cacheSize - (float)start) / cacheSize)) + "% of the searched for values: ");
        long startTime = System.currentTimeMillis();
        for (int j = start; j < start + cacheSize; j++) {
            testCache.get(j);
        }
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        int uncachedExpense = (testCache.getCacheMisses() - cacheSize) * requestWaitTime;
        System.out.println("Percentage of cache used: " + (getCacheHitRatio() * 100.0) + "%");
        System.out.println("Test completed in: " + timeTaken + "ms");
        System.out.println("Cost of Uncached Information Retrieval: " + uncachedExpense + "ms");
        System.out.println("Net Expense of using CachingList: " + (int)Math.round(timeTaken - uncachedExpense) + "ms\n");
    }
    
    /**
     * Prepare for a test.
     */
    private void setUp() {
        testCache = new CachingList(sourceList, cacheSize);
        for (int i = 0; i < cacheSize; i++) {
            testCache.get(i);
        }
    }
    
    /**
     * Clean up after a test.
     */
    private void tearDown() {
        testCache = null;
    }
    
    /**
     * Gets the ratio of cache hits to cache misses. This is a number between
     * 0 and 1, where 0 means the cache is unused and 1 means the cache was
     * used exclusively.
     *
     * @return The ratio of cache hits ot cache misses
     */
    private float getCacheHitRatio() {
        int cacheHits = testCache.getCacheHits();
        int cacheMisses = testCache.getCacheMisses() - cacheSize;
        if (cacheHits + cacheMisses == 0) return 0.0F;
        return (float)cacheHits / (float)(cacheHits + cacheMisses);
    }
}
