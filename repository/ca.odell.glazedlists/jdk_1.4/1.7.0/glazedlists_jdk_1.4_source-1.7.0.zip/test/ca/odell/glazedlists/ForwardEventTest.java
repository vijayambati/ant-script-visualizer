package ca.odell.glazedlists;

import junit.framework.*;
import ca.odell.glazedlists.event.*;
import java.util.*;

/**
 * Ensures that ListEventAssembler.forwardEvent() works.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ForwardEventTest extends TestCase {
    
    public ForwardEventTest() {
        super();
    }
    
    /**
     * the origin of all events 
     */
    private EventList source;
    
    /**
     * gossipy list that forwards everything it hears 
     */
    private ForwardingList forwarding;
    
    /**
     * listens to anything the forwarding list will say, and validates it 
     */
    private ListConsistencyListener test;
    
    /**
     * Prepare for the test.
     */
    public void setUp() {
        source = new BasicEventList();
        forwarding = new ForwardingList(source);
        test = ListConsistencyListener.install(forwarding);
    }
    
    /**
     * Clean up after the test.
     */
    public void tearDown() {
        source = null;
        forwarding = null;
        test = null;
    }
    
    /**
     * Tests that forwardEvent works.
     */
    public void testForwarding() {
        source.add("Pepsi");
        source.add("Coke");
        source.add("RC");
        test.assertConsistent();
        source.addAll(Arrays.asList(new String[]{"7-up", "Dr. Pepper", "Sprite"}));
        source.retainAll(Arrays.asList(new String[]{"Pepsi", "7-up", "RC"}));
        test.assertConsistent();
    }
    
    /**
     * Tests that forwardEvent works.
     */
    public void testNestedForwarding() {
        forwarding.beginEvent();
        source.add("Pepsi");
        source.add("Coke");
        source.add("RC");
        forwarding.commitEvent();
        test.assertConsistent();
        forwarding.beginEvent();
        source.addAll(Arrays.asList(new String[]{"7-up", "Dr. Pepper", "Sprite"}));
        source.retainAll(Arrays.asList(new String[]{"Pepsi", "7-up", "RC"}));
        forwarding.commitEvent();
        test.assertConsistent();
    }
    
    public void testBadListEventHandler() {
        assertIllegalStateExceptionIsThrown(source, new GetTypeListener());
        assertIllegalStateExceptionIsThrown(source, new GetBlockStartIndexListener());
        assertIllegalStateExceptionIsThrown(source, new GetBlockEndIndexListener());
        assertIllegalStateExceptionIsThrown(source, new GetIndexListener());
        assertIllegalStateExceptionIsThrown(source, new GetTypeTooFarListener());
        assertIllegalStateExceptionIsThrown(source, new GetBlockStartIndexTooFarListener());
        assertIllegalStateExceptionIsThrown(source, new GetBlockEndIndexTooFarListener());
        assertIllegalStateExceptionIsThrown(source, new GetIndexTooFarListener());
    }
    
    private class GetTypeListener extends DoNotStartIteratingListEventListener {
        
        private GetTypeListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getType();
        }
    }
    
    private class GetBlockStartIndexListener extends DoNotStartIteratingListEventListener {
        
        private GetBlockStartIndexListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getBlockStartIndex();
        }
    }
    
    private class GetBlockEndIndexListener extends DoNotStartIteratingListEventListener {
        
        private GetBlockEndIndexListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getBlockEndIndex();
        }
    }
    
    private class GetIndexListener extends DoNotStartIteratingListEventListener {
        
        private GetIndexListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getIndex();
        }
    }
    
    private class GetTypeTooFarListener extends IterateTooFarListEventListener {
        
        private GetTypeTooFarListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getType();
        }
    }
    
    private class GetBlockStartIndexTooFarListener extends IterateTooFarListEventListener {
        
        private GetBlockStartIndexTooFarListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getBlockStartIndex();
        }
    }
    
    private class GetBlockEndIndexTooFarListener extends IterateTooFarListEventListener {
        
        private GetBlockEndIndexTooFarListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getBlockEndIndex();
        }
    }
    
    private class GetIndexTooFarListener extends IterateTooFarListEventListener {
        
        private GetIndexTooFarListener() {
            super();
        }
        
        protected void breakListEvent(ListEvent l) {
            l.getIndex();
        }
    }
    
    private static void assertIllegalStateExceptionIsThrown(EventList list, ListEventListener listener) {
        list.addListEventListener(listener);
        try {
            list.add("this should throw an IllegalStateException");
            fail("failed to throw an expected IllegalStateException for a bad ListEventListener implementation");
        } catch (IllegalStateException ise) {
        }
        list.removeListEventListener(listener);
    }
    
    static class DoNotStartIteratingListEventListener implements ListEventListener {
        
        DoNotStartIteratingListEventListener() {
            super();
        }
        
        public void listChanged(ListEvent listChanges) {
            breakListEvent(listChanges);
        }
        
        protected void breakListEvent(ListEvent l) {
        }
    }
    
    static class IterateTooFarListEventListener implements ListEventListener {
        
        IterateTooFarListEventListener() {
            super();
        }
        
        public void listChanged(ListEvent listChanges) {
            while (listChanges.next()) ;
            breakListEvent(listChanges);
        }
        
        protected void breakListEvent(ListEvent l) {
        }
    }
    
    /**
     * Simple TransformationList that forwards events.
     */
    static class ForwardingList extends TransformedList {
        
        public ForwardingList(EventList source) {
            super(source);
            source.addListEventListener(this);
        }
        
        public void listChanged(ListEvent e) {
            updates.forwardEvent(e);
        }
        
        public void beginEvent() {
            updates.beginEvent(true);
        }
        
        public void commitEvent() {
            updates.commitEvent();
        }
    }
}
