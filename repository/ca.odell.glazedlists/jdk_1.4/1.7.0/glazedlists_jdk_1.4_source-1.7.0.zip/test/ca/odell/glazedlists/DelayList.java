package ca.odell.glazedlists;

import ca.odell.glazedlists.event.ListEvent;

/**
 * This EventList simply delays each read and write operation by the given
 * delay (in milliseconds).
 *
 * @author James Lemieux
 */
public class DelayList extends TransformedList {
    private final long delay;
    
    public DelayList(EventList source, long delay) {
        super(source);
        if (delay < 1) throw new IllegalArgumentException("delay is not a non-negative number");
        this.delay = delay;
        source.addListEventListener(this);
    }
    
    private void delay() {
        try {
            Thread.sleep(this.delay);
        } catch (InterruptedException e) {
        }
    }
    
    public void listChanged(ListEvent listChanges) {
        this.delay();
        updates.forwardEvent(listChanges);
    }
    
    protected boolean isWritable() {
        return true;
    }
    
    public int size() {
        this.delay();
        return super.size();
    }
    
    public Object get(int index) {
        this.delay();
        return super.get(index);
    }
}
