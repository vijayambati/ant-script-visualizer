package ca.odell.glazedlists.swing;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.ListConsistencyListener;
import ca.odell.glazedlists.matchers.AbstractMatcherEditor;
import ca.odell.glazedlists.matchers.Matcher;
import junit.framework.TestCase;
import javax.swing.*;
import java.util.Random;

/**
 * Make sure we can handle multiple updates from different sources.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class SimultaneousUpdatesTest extends TestCase {
    
    public SimultaneousUpdatesTest() {
        super();
    }
    
    /**
     * This test verifies that we can have two threads changing the data and
     * everything will still be consistent as long as proper locks are held.
     */
    public synchronized void testCompetingWriters() {
        EventList list = new BasicEventList();
        EvenOrAllMatcherEditor matcherEditor = new EvenOrAllMatcherEditor();
        FilterList filterList = new FilterList(list, matcherEditor);
        EventList swingSafe = GlazedListsSwing.swingThreadProxyList(filterList);
        ListConsistencyListener.install(swingSafe);
        Thread backgroundThread = new Thread(new AddThenRemoveOnList(list));
        backgroundThread.start();
        try {
            for (int i = 0; i < 500; i++) {
                SwingUtilities.invokeLater(new FilterUnfilter(matcherEditor));
                wait(10);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            backgroundThread.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    private static class FilterUnfilter implements Runnable {
        private EvenOrAllMatcherEditor matcherEditor;
        
        public FilterUnfilter(EvenOrAllMatcherEditor matcherEditor) {
            super();
            this.matcherEditor = matcherEditor;
        }
        
        public synchronized void run() {
            matcherEditor.setEven();
            matcherEditor.setAll();
        }
    }
    
    /**
     * Add five values, then remove them.
     */
    private static class AddThenRemoveOnList implements Runnable {
        private final Random dice = new Random(15);
        private EventList list;
        
        public AddThenRemoveOnList(EventList list) {
            super();
            this.list = list;
        }
        
        public synchronized void run() {
            try {
                for (int j = 0; j < 500; ) {
                    list.getReadWriteLock().writeLock().lock();
                    try {
                        int i = j;
                        j += dice.nextInt(3);
                        for (; i < j; i++) {
                            list.add(new Integer(i));
                        }
                    } finally {
                        list.getReadWriteLock().writeLock().unlock();
                    }
                    wait(10);
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    /**
     * Match only odd or even values.
     */
    private static class EvenOrAllMatcherEditor extends AbstractMatcherEditor {
        
        private EvenOrAllMatcherEditor() {
            super();
        }
        
        public void setAll() {
            fireMatchAll();
        }
        
        public void setEven() {
            fireChanged(new EvenMatcherEditor());
        }
        
        private static class EvenMatcherEditor implements Matcher {
            
            private EvenMatcherEditor() {
                super();
            }
            
            public boolean matches(Object x0) {
                Integer item = (Integer)x0;
                return item.intValue() % 2 == 0;
            }
            /*missing*/
        }
    }
}
