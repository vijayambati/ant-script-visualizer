package ca.odell.glazedlists.impl.beans;

import junit.framework.*;
import java.awt.Color;
import ca.odell.glazedlists.*;
import ca.odell.glazedlists.gui.*;

/**
 * A test object.
 */
class FootballTeam {
    private String name;
    private String home;
    private Color primary;
    private Color secondary;
    private boolean yearWinner;
    private int matchCount;
    
    public FootballTeam(String name, String home, Color primary, Color secondary) {
        super();
        this.name = name;
        this.home = home;
        this.primary = primary;
        this.secondary = secondary;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    {
    }
    
    public String getHome() {
        return home;
    }
    
    public void setHome(String home) {
        this.home = home;
    }
    {
    }
    
    public Color getPrimary() {
        return primary;
    }
    
    public void setPrimary(Color primary) {
        this.primary = primary;
    }
    {
    }
    
    public Color getSecondary() {
        return secondary;
    }
    
    public void setSecondary(Color secondary) {
        this.secondary = secondary;
    }
    {
    }
    
    public int getMatchCount() {
        return matchCount;
    }
    
    public void setMatchCount(int matchCount) {
        this.matchCount = matchCount;
    }
    
    public boolean isYearWinner() {
        return yearWinner;
    }
    
    public void setYearWinner(boolean yearWinner) {
        this.yearWinner = yearWinner;
    }
}
