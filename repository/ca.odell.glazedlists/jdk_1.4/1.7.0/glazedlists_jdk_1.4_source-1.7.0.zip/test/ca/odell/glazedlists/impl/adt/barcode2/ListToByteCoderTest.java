package ca.odell.glazedlists.impl.adt.barcode2;

import junit.framework.TestCase;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import ca.odell.glazedlists.GlazedListsTests;

/**
 * Make sure we can encode to bytes and back consistently.
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class ListToByteCoderTest extends TestCase {
    
    public ListToByteCoderTest() {
        super();
    }
    
    public void testSymmetry() {
        List values = GlazedListsTests.stringToList("ABCDEFG");
        ListToByteCoder coder = new ListToByteCoder(values);
        byte a = coder.colorToByte("A");
        byte b = coder.colorToByte("B");
        byte c = coder.colorToByte("C");
        byte d = coder.colorToByte("D");
        byte e = coder.colorToByte("E");
        byte f = coder.colorToByte("F");
        byte g = coder.colorToByte("G");
        Set distinctValues = new HashSet();
        assertTrue(distinctValues.add(new Byte(a)));
        assertTrue(distinctValues.add(new Byte(b)));
        assertTrue(distinctValues.add(new Byte(c)));
        assertTrue(distinctValues.add(new Byte(d)));
        assertTrue(distinctValues.add(new Byte(e)));
        assertTrue(distinctValues.add(new Byte(f)));
        assertTrue(distinctValues.add(new Byte(g)));
        assertEquals(7, distinctValues.size());
        assertEquals("A", coder.byteToColor(a));
        assertEquals("B", coder.byteToColor(b));
        assertEquals("C", coder.byteToColor(c));
        assertEquals("D", coder.byteToColor(d));
        assertEquals("E", coder.byteToColor(e));
        assertEquals("F", coder.byteToColor(f));
        assertEquals("G", coder.byteToColor(g));
        byte abd = coder.colorsToByte(GlazedListsTests.stringToList("ABD"));
        byte abe = coder.colorsToByte(GlazedListsTests.stringToList("ABE"));
        byte abcde = coder.colorsToByte(GlazedListsTests.stringToList("ABCDE"));
        byte ae = coder.colorsToByte(GlazedListsTests.stringToList("AE"));
        byte fg = coder.colorsToByte(GlazedListsTests.stringToList("FG"));
        assertTrue(distinctValues.add(new Byte(abd)));
        assertTrue(distinctValues.add(new Byte(abe)));
        assertTrue(distinctValues.add(new Byte(abcde)));
        assertTrue(distinctValues.add(new Byte(ae)));
        assertTrue(distinctValues.add(new Byte(fg)));
        assertEquals(GlazedListsTests.stringToList("ABD"), coder.byteToColors(abd));
        assertEquals(GlazedListsTests.stringToList("ABE"), coder.byteToColors(abe));
        assertEquals(GlazedListsTests.stringToList("ABCDE"), coder.byteToColors(abcde));
        assertEquals(GlazedListsTests.stringToList("AE"), coder.byteToColors(ae));
    }
}
