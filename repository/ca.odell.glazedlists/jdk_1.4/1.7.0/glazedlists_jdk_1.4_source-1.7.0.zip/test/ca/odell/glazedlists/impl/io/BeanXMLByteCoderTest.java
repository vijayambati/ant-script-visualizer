package ca.odell.glazedlists.impl.io;

import javax.swing.JLabel;
import java.io.*;
import ca.odell.glazedlists.io.*;
import junit.framework.*;

/**
 * Tests the BeanXMLByteCoder..
 *
 * @author <a href="mailto:jesse@swank.ca">Jesse Wilson</a>
 */
public class BeanXMLByteCoderTest extends TestCase {
    
    public BeanXMLByteCoderTest() {
        super();
    }
    
    /**
     * Tests that the XML encoding works.
     */
    public void testCoding() throws IOException {
        Bufferlo data = new Bufferlo();
        JLabel bean = new JLabel();
        bean.setText("Limp Bizkit");
        bean.setToolTipText("Fred Durst");
        bean.setEnabled(false);
        ByteCoder beanXMLByteCoder = new BeanXMLByteCoder();
        beanXMLByteCoder.encode(bean, data.getOutputStream());
        JLabel beanCopy = (JLabel)(JLabel)beanXMLByteCoder.decode(data.getInputStream());
        assertEquals(bean.getText(), beanCopy.getText());
        assertEquals(bean.getToolTipText(), beanCopy.getToolTipText());
        assertEquals(bean.isEnabled(), beanCopy.isEnabled());
    }
}
