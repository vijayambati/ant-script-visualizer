package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

class TowingCompany {
    
    TowingCompany() {
        super();
    }
    
    public SupportsTrailerHitch getTowTruck() {
        return new Truck(3);
    }
}
