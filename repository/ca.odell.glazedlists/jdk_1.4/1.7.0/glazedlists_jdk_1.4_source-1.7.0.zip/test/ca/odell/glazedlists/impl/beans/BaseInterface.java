package ca.odell.glazedlists.impl.beans;

import junit.framework.*;

/**
 * Test interfaces.
 */
interface BaseInterface {
    
    public String getCode();
    
    public void setCode(String code);
}
