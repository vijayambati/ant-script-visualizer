
package mod.modA;

import mod.modB.ModuleB;

public class ModuleA
{
    private ModuleB moduleB;

};