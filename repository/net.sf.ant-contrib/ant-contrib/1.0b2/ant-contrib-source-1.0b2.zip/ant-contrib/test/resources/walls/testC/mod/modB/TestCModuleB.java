
package mod.modB;


public class TestCModuleB
{
};