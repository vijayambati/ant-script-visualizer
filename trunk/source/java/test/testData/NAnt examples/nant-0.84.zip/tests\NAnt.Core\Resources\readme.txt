All the files in these subdirs will be loaded and tested. 
Each file in Valid is expected to pass the test with success, 
while the Invalid files are expected to fail with an error.