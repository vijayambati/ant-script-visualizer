using NUnit.Framework;

namespace Tests.NAnt.VSNet.Tasks {
    [TestFixture]
    public class NoTestsYet {
    }
}
